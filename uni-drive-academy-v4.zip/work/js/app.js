// js/app.js — Uni-Drive Academy v2
// localStorage-based, no server required
'use strict';

// ══════════════════════════════════════════════════
//  DATABASE (localStorage)
// ══════════════════════════════════════════════════
const DB_KEY = 'unidrive_db_v2';

function getDB() {
  const raw = localStorage.getItem(DB_KEY);
  if (raw) return JSON.parse(raw);
  const seed = {
    users: [
      { id:'user_admin', first_name:'Admin', last_name:'UniDrive',
        email:'admin@unidrive.ac.za', password:'admin123',
        role:'admin', student_number:'', phone:'031 907 7111',
        is_active:true, profile_pic:'', created_at:'2026-01-01T08:00:00.000Z' },
      { id:'user_thabo', first_name:'Thabo', last_name:'Mokoena',
        email:'thabo@mut.ac.za', password:'student123',
        role:'student', student_number:'220123456', phone:'0821234567',
        is_active:true, profile_pic:'', created_at:'2026-01-15T09:00:00.000Z' },
      { id:'user_naledi', first_name:'Naledi', last_name:'Dlamini',
        email:'naledi@mut.ac.za', password:'staff123',
        role:'staff', student_number:'', phone:'0731234567',
        is_active:true, profile_pic:'', created_at:'2026-01-20T10:00:00.000Z' },
    ],
    bookings: [
      { id:'bk001', user_id:'user_thabo',
        student_name:'Thabo Mokoena', student_email:'thabo@mut.ac.za',
        course_id:'code8', course_name:'Code 8 — Light Motor Vehicle',
        booking_date:'2026-06-10', booking_time:'09:00',
        total_price:2300, status:'confirmed', notes:'', paid:true,
        created_at:'2026-05-20T08:00:00.000Z' },
    ],
    enquiries: [
      { id:'enq001', name:'Siphamandla Ngcobo', email:'sngcobo@mut.ac.za',
        phone:'0798765432',
        message:'I would like to know more about the Code 10 programme.',
        status:'new', created_at:'2026-05-25T14:00:00.000Z' },
    ],
    testimonials: [
      { id:'rev001', user_id:'user_thabo', name:'Thabo Mokoena',
        msg:'Passed my Code 8 first time! The instructors are patient and thorough.',
        rating:5, is_approved:true, created_at:'2026-04-10T12:00:00.000Z' },
      { id:'rev002', user_id:'user_naledi', name:'Naledi Dlamini',
        msg:'Affordable, convenient, and professional. Highly recommend!',
        rating:5, is_approved:true, created_at:'2026-04-15T14:00:00.000Z' },
    ],
    testBookings: [],
    payments: [],
  };
  saveDB(seed);
  return seed;
}
function saveDB(db) { localStorage.setItem(DB_KEY, JSON.stringify(db)); }

const COURSES = {
  learners: { id:'learners', name:"Learner's Licence Prep",    price_student:800,  price_staff:1000, icon:'📋' },
  code8:    { id:'code8',    name:'Code 8 — Light Motor Vehicle', price_student:2300, price_staff:2800, icon:'🚗' },
  codeA:    { id:'codeA',    name:'Code A — Motorcycle',       price_student:2000, price_staff:2400, icon:'🏍️' },
  code10:   { id:'code10',   name:'Code 10 — Heavy Vehicle',   price_student:2500, price_staff:3000, icon:'🚛' },
  code14:   { id:'code14',   name:'Code 14 — Extra Heavy',     price_student:3000, price_staff:3500, icon:'🚚' },
  adaptive: { id:'adaptive', name:'Adaptive Driving',          price_student:1500, price_staff:1800, icon:'♿' },
};

// ══════════════════════════════════════════════════
//  STATE
// ══════════════════════════════════════════════════
let currentUser       = null;
let selectedRating    = 5;
let priceMode         = 'student';
let adminBookingsCache = [];
let adminUsersCache   = [];
let pageHistory       = [];  // back-button stack

// Payment flow state
let pendingBookingData = null; // holds booking details before payment

const SESSION_KEY = 'unidrive_sess_v2';

// ══════════════════════════════════════════════════
//  INIT
// ══════════════════════════════════════════════════
document.addEventListener('DOMContentLoaded', () => {
  checkAuth();
  setMinDate();
  goto('home');
});

// ══════════════════════════════════════════════════
//  ROUTER + BACK BUTTON
// ══════════════════════════════════════════════════
function goto(page, skipHistory) {
  const current = document.querySelector('.pg.active');
  const currentId = current ? current.id.replace('pg-', '') : null;

  document.querySelectorAll('.pg').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nl[data-p]').forEach(l =>
    l.classList.toggle('active', l.dataset.p === page));

  const el = document.getElementById('pg-' + page);
  if (el) el.classList.add('active');
  window.scrollTo({ top:0, behavior:'smooth' });
  document.getElementById('navLinks')?.classList.remove('open');

  // Push to history (skip for back-navigation and non-content pages)
  if (!skipHistory && currentId && currentId !== page &&
      !['pay-success'].includes(currentId)) {
    pageHistory.push(currentId);
    if (pageHistory.length > 15) pageHistory.shift();
  }

  const loaders = {
    home:       loadHome,      courses:     loadCourses,
    instructors:loadInstructors, book:      loadBookPage,
    faq:        loadFaq,       dashboard:   loadDashboard,
    admin:      loadAdmin,     learn:       loadLearn,
    sessions:   loadSessions,  mocktest:    loadMocktest,
    testbooking:loadTestBooking,
  };
  if (loaders[page]) loaders[page]();
}

function goBack() {
  const prev = pageHistory.pop();
  if (prev) goto(prev, true);
  else goto('home', true);
}

function toggleNav() {
  document.getElementById('navLinks').classList.toggle('open');
}

// ══════════════════════════════════════════════════
//  AUTH
// ══════════════════════════════════════════════════
function checkAuth() {
  const sess = localStorage.getItem(SESSION_KEY);
  if (sess) { try { currentUser = JSON.parse(sess); } catch { currentUser = null; } }
  renderNav();
}

function renderNav() {
  const area = document.getElementById('authArea');
  if (!currentUser) {
    area.innerHTML = `<a class="nl nav-cta" onclick="goto('login')">Login</a>`;
    return;
  }
  // Show profile pic or initials
  const initials = (currentUser.first_name[0] + currentUser.last_name[0]).toUpperCase();
  const dash = currentUser.role === 'admin' ? 'admin' : 'dashboard';
  const picHtml = currentUser.profile_pic
    ? `<img src="${currentUser.profile_pic}" style="width:27px;height:27px;border-radius:50%;object-fit:cover;border:2px solid var(--gold)"/>`
    : `<span class="nav-avatar">${initials}</span>`;
  area.innerHTML = `
    <a class="nl" onclick="goto('${dash}')" style="display:flex;align-items:center;gap:.5rem">
      ${picHtml}
      <span>${currentUser.first_name}</span>
    </a>
    <a class="nl logout-link" onclick="doLogout()">Logout</a>`;
}

function doLogin(e) {
  e.preventDefault();
  const msgEl = document.getElementById('loginMsg');
  clearMsg(msgEl);
  const email = document.getElementById('loginEmail').value.trim().toLowerCase();
  const pw    = document.getElementById('loginPw').value;
  const db    = getDB();
  const user  = db.users.find(u => u.email.toLowerCase() === email && u.password === pw);
  if (!user) { showMsg(msgEl, 'Invalid email or password.', 'error'); return; }
  if (!user.is_active) { showMsg(msgEl, 'Account deactivated. Contact admin.', 'error'); return; }
  currentUser = { ...user }; delete currentUser.password;
  localStorage.setItem(SESSION_KEY, JSON.stringify(currentUser));
  renderNav();
  toast(`Welcome back, ${user.first_name}! 🚗`, 'success');
  goto(user.role === 'admin' ? 'admin' : 'dashboard');
}

function doRegister(e) {
  e.preventDefault();
  const msgEl = document.getElementById('regMsg');
  clearMsg(msgEl);
  const first = document.getElementById('regFirst').value.trim();
  const last  = document.getElementById('regLast').value.trim();
  const email = document.getElementById('regEmail').value.trim().toLowerCase();
  const pw    = document.getElementById('regPw').value;
  const role  = document.getElementById('regRole').value;
  const sn    = document.getElementById('regSn')?.value?.trim() || '';
  const phone = document.getElementById('regPhone')?.value?.trim() || '';
  if (!first||!last||!email||!pw) { showMsg(msgEl,'Fill in all required fields.','error'); return; }
  if (pw.length < 6) { showMsg(msgEl,'Password must be at least 6 characters.','error'); return; }
  const db = getDB();
  if (db.users.find(u => u.email.toLowerCase() === email)) {
    showMsg(msgEl,'An account with this email already exists.','error'); return;
  }
  const newUser = { id:'user_'+Date.now(), first_name:first, last_name:last,
    email, password:pw, role, student_number:sn, phone,
    is_active:true, profile_pic:'', created_at:new Date().toISOString() };
  db.users.push(newUser); saveDB(db);
  currentUser = { ...newUser }; delete currentUser.password;
  localStorage.setItem(SESSION_KEY, JSON.stringify(currentUser));
  renderNav();
  toast(`Account created! Welcome, ${first}! 🎉`, 'success');
  goto('dashboard');
}

function doLogout() {
  currentUser = null; pendingBookingData = null;
  localStorage.removeItem(SESSION_KEY);
  pageHistory = [];
  renderNav(); goto('home');
  toast('Logged out.', 'info');
}

function fillLogin(email, pw) {
  document.getElementById('loginEmail').value = email;
  document.getElementById('loginPw').value    = pw;
}
function togglePw(id, btn) {
  const inp = document.getElementById(id);
  inp.type = inp.type === 'text' ? 'password' : 'text';
  btn.textContent = inp.type === 'text' ? '🙈' : '👁';
}
function toggleStudentFields() {
  const role = document.getElementById('regRole').value;
  const g = document.getElementById('regSnGroup');
  if (g) g.style.display = role === 'student' ? 'flex' : 'none';
}

// ══════════════════════════════════════════════════
//  HOME
// ══════════════════════════════════════════════════
function loadHome() {
  const db = getDB();
  const approved = db.testimonials.filter(t => t.is_approved);
  const el = document.getElementById('homeTestimonials');
  if (el && approved.length) {
    el.innerHTML = approved.map(t => `
      <div class="test-card">
        <div class="test-stars">${'★'.repeat(t.rating)}</div>
        <p class="test-msg">"${t.msg}"</p>
        <div class="test-name">— ${t.name}</div>
      </div>`).join('');
  }
}

// ══════════════════════════════════════════════════
//  COURSES
// ══════════════════════════════════════════════════
function loadCourses() { /* pre-rendered */ }

function setPriceMode(mode) {
  priceMode = mode;
  document.getElementById('ptStudent').classList.toggle('active', mode==='student');
  document.getElementById('ptStaff').classList.toggle('active', mode==='staff');
  const map = {
    learners:{student:'R 800', staff:'R 1 000'},
    code8:   {student:'R 2 300', staff:'R 2 800'},
    codeA:   {student:'R 2 000', staff:'R 2 400'},
    code10:  {student:'R 2 500', staff:'R 3 000'},
    code14:  {student:'R 3 000', staff:'R 3 500'},
    adaptive:{student:'R 1 500', staff:'R 1 800'},
  };
  document.querySelectorAll('.price-row strong').forEach((el,i) => {
    const keys = Object.keys(map);
    const cIdx = Math.floor(i/2);
    const isStaff = i%2===1;
    const key = keys[cIdx];
    if (key && map[key]) el.textContent = isStaff ? map[key].staff : map[key][mode];
  });
}

// Called from "Book This Course" button on the Courses page
function startCourseBooking(courseId, courseName, priceS, priceP) {
  if (!currentUser) { goto('login'); return; }
  goto('book');
  // Pre-select the course
  setTimeout(() => {
    const sel = document.getElementById('bkCourse');
    if (sel) { sel.value = courseId; updateBookingPrice(); }
  }, 200);
}

// ══════════════════════════════════════════════════
//  INSTRUCTORS
// ══════════════════════════════════════════════════
function loadInstructors() { /* pre-rendered */ }

// ══════════════════════════════════════════════════
//  BOOK PAGE
// ══════════════════════════════════════════════════
function loadBookPage() {
  if (!currentUser) {
    document.getElementById('bookGate').classList.remove('hidden');
    document.getElementById('bookContent').classList.add('hidden');
    return;
  }
  document.getElementById('bookGate').classList.add('hidden');
  document.getElementById('bookContent').classList.remove('hidden');
  checkActiveCourseNotice();
  loadMyBookings();
  setMinDate();
}

// Check if user already has an active (pending/confirmed) booking
function getActiveCourse() {
  if (!currentUser) return null;
  const db = getDB();
  return db.bookings.find(b =>
    b.user_id === currentUser.id && ['pending','confirmed'].includes(b.status)
  ) || null;
}

function checkActiveCourseNotice() {
  const active = getActiveCourse();
  const notice = document.getElementById('activeCourseNotice');
  const form   = document.getElementById('bookFormWrap');
  if (!notice) return;
  if (active) {
    document.getElementById('activeCourseNameDisplay').textContent = active.course_name;
    notice.classList.remove('hidden');
    if (form) form.classList.add('hidden');
  } else {
    notice.classList.add('hidden');
    if (form) form.classList.remove('hidden');
  }
}

function updateBookingPrice() {
  const sel = document.getElementById('bkCourse');
  const opt = sel.options[sel.selectedIndex];
  const box = document.getElementById('bkPriceBox');
  if (!sel.value) { box.classList.add('hidden'); return; }
  const isStaff = currentUser?.role === 'staff';
  const price = isStaff ? parseFloat(opt.dataset.pp) : parseFloat(opt.dataset.ps);
  document.getElementById('bkPriceAmt').textContent = `R ${price.toLocaleString()}`;
  box.classList.remove('hidden');
}

function setMinDate() {
  const today = new Date().toISOString().split('T')[0];
  ['bkDate','dbkDate'].forEach(id => {
    const el = document.getElementById(id); if(el) el.min = today;
  });
}

function loadTimeSlots() { buildSlots('bkDate','slotsWrapper','slotsGrid','bkTime'); }
function loadDashSlots()  { buildSlots('dbkDate','dbkSlotsWrapper','dbkSlotsGrid','dbkTime'); }

function buildSlots(dateId, wrapperId, gridId, hiddenId) {
  const date = document.getElementById(dateId).value;
  const wrap = document.getElementById(wrapperId);
  const grid = document.getElementById(gridId);
  document.getElementById(hiddenId).value = '';
  if (!date) { wrap.style.display='none'; return; }
  const slots = [];
  for (let h=8; h<=17; h++) {
    slots.push(`${String(h).padStart(2,'0')}:00`);
    if (h<17) slots.push(`${String(h).padStart(2,'0')}:30`);
  }
  grid.innerHTML = slots.map(t =>
    `<button type="button" class="slot-btn" onclick="selectSlot('${t}',this,'${hiddenId}')">${t}</button>`
  ).join('');
  wrap.style.display = 'block';
}

function selectSlot(time, btn, hiddenId) {
  btn.closest('.slots-grid').querySelectorAll('.slot-btn').forEach(b=>b.classList.remove('selected'));
  btn.classList.add('selected');
  document.getElementById(hiddenId).value = time;
}

// ── Booking → Payment flow ─────────────────────
function submitBooking(e) {
  e.preventDefault();
  const msgEl = document.getElementById('bookMsg');
  clearMsg(msgEl);
  goToPayment('bkCourse','bkDate','bkTime','bkNotes','bookMsg');
}

function submitDashBooking(e) {
  e.preventDefault();
  const msgEl = document.getElementById('dbkMsg');
  clearMsg(msgEl);
  goToPayment('dbkCourse','dbkDate','dbkTime','dbkNotes','dbkMsg');
}

function goToPayment(courseId, dateId, timeId, notesId, msgId) {
  const msgEl  = document.getElementById(msgId);
  const course = document.getElementById(courseId).value;
  const date   = document.getElementById(dateId).value;
  const time   = document.getElementById(timeId).value;
  const notes  = document.getElementById(notesId).value;

  if (!course) { showMsg(msgEl,'Please select a course.','error'); return; }
  if (!date)   { showMsg(msgEl,'Please select a date.','error'); return; }
  if (!time)   { showMsg(msgEl,'Please select a time slot.','error'); return; }

  const today = new Date().toISOString().split('T')[0];
  if (date < today) { showMsg(msgEl,'Date cannot be in the past.','error'); return; }

  // ONE COURSE AT A TIME check
  const active = getActiveCourse();
  if (active) {
    showMsg(msgEl, `You are already enrolled in "${active.course_name}". Cancel it first to book a new course.`, 'error');
    return;
  }

  const courseObj = COURSES[course];
  const price = currentUser.role === 'staff' ? courseObj.price_staff : courseObj.price_student;

  // Store pending booking data
  pendingBookingData = { course, courseObj, date, time, notes, price };

  // Navigate to payment page and populate it
  setupPaymentPage(pendingBookingData);
  goto('payment');
}

function setupPaymentPage(data) {
  const vat      = Math.round(data.price * 0.15);
  const total    = data.price + vat;
  const ref      = 'UDA-' + Date.now().toString(36).toUpperCase().slice(-8);

  setText('payCourse',   data.courseObj.name);
  setText('payIcon',     data.courseObj.icon);
  setText('payMeta',     `📅 ${data.date}   🕐 ${data.time}`);
  setText('paySubtotal', `R ${data.price.toLocaleString()}`);
  setText('payVat',      `R ${vat.toLocaleString()}`);
  setText('payTotal',    `R ${total.toLocaleString()}`);
  setText('eftRef',      ref);
  setText('eftAmount',   `R ${total.toLocaleString()}`);

  pendingBookingData._vat   = vat;
  pendingBookingData._total = total;
  pendingBookingData._ref   = ref;

  clearMsg(document.getElementById('payMsg'));
  clearMsg(document.getElementById('eftMsg'));
  // Switch to card tab by default
  switchPayTab('card', document.querySelector('.pay-tab'));
}

function setText(id, val) {
  const el = document.getElementById(id); if(el) el.textContent = val;
}

function switchPayTab(name, btn) {
  document.querySelectorAll('.pay-tab').forEach(t=>t.classList.remove('active'));
  document.querySelectorAll('.pay-tab-content').forEach(t=>t.classList.add('hidden'));
  if(btn) btn.classList.add('active');
  const panel = document.getElementById('pay-'+name);
  if(panel) panel.classList.remove('hidden');
}

// Card number formatting
function formatCardNum(input) {
  let v = input.value.replace(/\D/g,'').slice(0,16);
  input.value = v.replace(/(.{4})/g,'$1 ').trim();
  const icon = document.getElementById('cardTypeIcon');
  if (icon) {
    if (v.startsWith('4')) icon.textContent = '💳';
    else if (v.startsWith('5')) icon.textContent = '💳';
    else if (v.startsWith('3')) icon.textContent = '💳';
    else icon.textContent = '💳';
  }
}
function formatExpiry(input) {
  let v = input.value.replace(/\D/g,'').slice(0,4);
  if (v.length > 2) v = v.slice(0,2)+'/'+v.slice(2);
  input.value = v;
}

// Process card payment
function processPayment(e) {
  e.preventDefault();
  if (!pendingBookingData) { goto('book'); return; }
  const msgEl  = document.getElementById('payMsg');
  const btn    = document.getElementById('paySubmitBtn');
  clearMsg(msgEl);

  const name   = document.getElementById('payCardName').value.trim();
  const num    = document.getElementById('payCardNum').value.replace(/\s/g,'');
  const expiry = document.getElementById('payExpiry').value.trim();
  const cvv    = document.getElementById('payCvv').value.trim();

  if (!name) { showMsg(msgEl,'Please enter the cardholder name.','error'); return; }
  if (num.length < 13) { showMsg(msgEl,'Please enter a valid card number.','error'); return; }
  if (!expiry.match(/^\d{2}\/\d{2}$/)) { showMsg(msgEl,'Enter expiry as MM/YY.','error'); return; }
  if (cvv.length < 3) { showMsg(msgEl,'Please enter your CVV code.','error'); return; }

  // Simulate processing
  btn.textContent = '⏳ Processing…';
  btn.classList.add('loading');
  setTimeout(() => {
    btn.textContent = '🔒 Pay & Confirm Booking';
    btn.classList.remove('loading');
    confirmBookingAfterPayment('card');
  }, 2000);
}

function submitEft() {
  if (!pendingBookingData) { goto('book'); return; }
  const msgEl = document.getElementById('eftMsg');
  clearMsg(msgEl);
  showMsg(msgEl, '⏳ Submitting your EFT booking request…', 'info');
  setTimeout(() => {
    confirmBookingAfterPayment('eft');
  }, 1200);
}

function confirmBookingAfterPayment(method) {
  const d  = pendingBookingData;
  if (!d) return;
  const db = getDB();

  // Final one-course check
  const active = db.bookings.find(b =>
    b.user_id === currentUser.id && ['pending','confirmed'].includes(b.status)
  );
  if (active) {
    toast(`You are already enrolled in "${active.course_name}".`, 'error'); return;
  }

  const booking = {
    id: 'bk_' + Date.now(),
    user_id: currentUser.id,
    student_name: `${currentUser.first_name} ${currentUser.last_name}`,
    student_email: currentUser.email,
    course_id: d.course, course_name: d.courseObj.name,
    booking_date: d.date, booking_time: d.time,
    total_price: d.price, status: method==='eft' ? 'pending' : 'confirmed',
    notes: d.notes, paid: method==='card',
    payment_method: method, payment_ref: d._ref,
    created_at: new Date().toISOString(),
  };
  db.bookings.push(booking);

  // Save payment record
  db.payments = db.payments || [];
  db.payments.push({
    id: 'pay_'+Date.now(), booking_id: booking.id,
    user_id: currentUser.id, amount: d._total,
    method, ref: d._ref, status: method==='card'?'paid':'pending_eft',
    created_at: new Date().toISOString(),
  });
  saveDB(db);

  pendingBookingData = null;
  showPaymentSuccess(booking, d, method);
}

function showPaymentSuccess(booking, d, method) {
  const el = document.getElementById('successDetails');
  if (el) {
    el.innerHTML = `
      <div class="sd-row"><span>Course</span><span>${booking.course_name}</span></div>
      <div class="sd-row"><span>Date</span><span>${booking.booking_date}</span></div>
      <div class="sd-row"><span>Time</span><span>${booking.booking_time}</span></div>
      <div class="sd-row"><span>Reference</span><span>${d._ref}</span></div>
      <div class="sd-row"><span>Payment Method</span><span>${method === 'card' ? '💳 Card' : '🏦 EFT'}</span></div>
      <div class="sd-row"><span>Status</span><span>${method==='card' ? '✅ Confirmed' : '⏳ Pending EFT confirmation'}</span></div>
      <div class="sd-row"><span>Total Paid</span><span>R ${(d._total).toLocaleString()}</span></div>`;
  }
  goto('pay-success');
  toast('🎉 Booking confirmed!', 'success');
}

function loadMyBookings() {
  const db = getDB();
  const bookings = db.bookings
    .filter(b => b.user_id === currentUser?.id)
    .sort((a,b) => new Date(b.created_at)-new Date(a.created_at));

  const html = bookings.length
    ? bookings.map(b => `
        <div class="bk-item">
          <div class="bk-hdr">
            <div class="bk-course">${b.course_name}</div>
            <span class="badge badge-${b.status}">${b.status}</span>
          </div>
          <div class="bk-meta">📅 ${b.booking_date} &nbsp; 🕐 ${b.booking_time} &nbsp; 💰 R${b.total_price.toLocaleString()}</div>
          ${b.payment_method ? `<div class="bk-meta">💳 ${b.payment_method==='card'?'Card payment':'EFT'} · ${b.payment_ref||''}</div>` : ''}
          ${b.notes ? `<div class="bk-meta">📝 ${b.notes}</div>` : ''}
          ${['pending','confirmed'].includes(b.status) ? `
            <div style="margin-top:.65rem">
              <button class="btn btn-sm btn-red" onclick="cancelBooking('${b.id}')">Cancel</button>
            </div>` : ''}
        </div>`).join('')
    : '<p class="text-muted">No bookings yet. <a onclick="goto(\'book\')" style="color:var(--green);font-weight:700;cursor:pointer">Book a lesson →</a></p>';

  ['myBookingsList','dashBookingsList'].forEach(id => {
    const el = document.getElementById(id); if(el) el.innerHTML = html;
  });
  updateDashStats();
}

function cancelBooking(id) {
  if (!confirm('Cancel this booking?')) return;
  const db = getDB();
  const bk = db.bookings.find(b=>b.id===id);
  if (bk) { bk.status='cancelled'; saveDB(db); }
  toast('Booking cancelled.','info');
  loadMyBookings();
  checkActiveCourseNotice();
  checkDashActiveNotice();
}

function updateDashStats() {
  if (!currentUser) return;
  const db = getDB();
  const mine = db.bookings.filter(b=>b.user_id===currentUser.id);
  const set = (id,val)=>{ const el=document.getElementById(id); if(el) el.textContent=val; };
  set('stat-total',     mine.length);
  set('stat-pending',   mine.filter(b=>b.status==='pending').length);
  set('stat-confirmed', mine.filter(b=>b.status==='confirmed').length);
  set('stat-completed', mine.filter(b=>b.status==='completed').length);
  const recent = document.getElementById('dashRecentBookings');
  if (!recent) return;
  const last3 = mine.slice(0,3);
  recent.innerHTML = last3.length
    ? last3.map(b=>`
        <div class="bk-item">
          <div class="bk-hdr"><div class="bk-course">${b.course_name}</div><span class="badge badge-${b.status}">${b.status}</span></div>
          <div class="bk-meta">📅 ${b.booking_date} &nbsp; 🕐 ${b.booking_time}</div>
        </div>`).join('')
    : '<p class="text-muted">No bookings yet.</p>';
}

// ══════════════════════════════════════════════════
//  FAQ
// ══════════════════════════════════════════════════
function loadFaq() { /* pre-rendered */ }
function toggleAcc(i,btn) {
  btn.classList.toggle('open');
  document.getElementById('acc-'+i).classList.toggle('show');
}
function searchFaq() {
  const q = document.getElementById('faqInput').value.trim().toLowerCase();
  const res = document.getElementById('faqResults');
  if (!q) { res.classList.add('hidden'); return; }
  res.classList.remove('hidden');
  const faqs = [
    { q:'How do I register for a course?', a:'Create an account, log in, then navigate to "Book a Lesson" and select your course.' },
    { q:'What documents do I need?', a:'Valid ID or passport, student card (if MUT student), and any existing licence if upgrading.' },
    { q:'Can I cancel a booking?', a:'Yes, up to 24 hours before your lesson from your dashboard without penalty.' },
    { q:'Do you offer payment plans?', a:'Yes! Contact us to arrange a flexible payment schedule.' },
    { q:'How long does it take to get a licence?', a:'Code 8 takes ~25 lessons (3–6 months) depending on your progress and availability.' },
    { q:'Are there classes for disabled students?', a:'Yes! Our Adaptive Driving programme caters for students with physical disabilities.' },
    { q:'How do online classes work?', a:'Book a session, receive a Microsoft Teams link by email, and join from your phone or laptop.' },
    { q:'How do I pay for lessons?', a:'After selecting your course and time slot, you can pay by card or EFT through our secure payment page.' },
  ];
  const results = faqs.filter(f=>f.q.toLowerCase().includes(q)||f.a.toLowerCase().includes(q));
  res.innerHTML = results.length
    ? results.map(r=>`<div class="faq-result-card"><div class="faq-rq">❓ ${r.q}</div><div class="faq-ra">✅ ${r.a}</div></div>`).join('')
    : `<div class="faq-no-result">No results for "<strong>${q}</strong>". Try: cancel, payment, online, documents.</div>`;
}

// ══════════════════════════════════════════════════
//  CONTACT
// ══════════════════════════════════════════════════
function submitEnquiry(e) {
  e.preventDefault();
  const msgEl = document.getElementById('contactMsg');
  clearMsg(msgEl);
  const db = getDB();
  db.enquiries.push({
    id: 'enq_'+Date.now(), name:document.getElementById('cName').value,
    email:document.getElementById('cEmail').value, phone:document.getElementById('cPhone').value,
    message:document.getElementById('cMsg').value, status:'new', created_at:new Date().toISOString()
  });
  saveDB(db);
  showMsg(msgEl,'✅ Message sent! We will respond within 1–2 business days.','success');
  e.target.reset(); toast('Message sent!','success');
}

// ══════════════════════════════════════════════════
//  CUSTOMER DASHBOARD
// ══════════════════════════════════════════════════
function loadDashboard() {
  if (!currentUser) { goto('login'); return; }
  const set = (id,v)=>{ const e=document.getElementById(id); if(e) e.textContent=v; };
  set('dashTitle', `Welcome, ${currentUser.first_name}!`);
  set('dashSub', `${currentUser.role==='staff'?'Staff':'Student'} Portal`);
  renderDashUserInfo();
  loadMyBookings();
  loadProfileForm();
  setMinDate();
  checkDashActiveNotice();
  // Quick actions
  const qa = document.getElementById('qaGrid');
  if (qa) qa.innerHTML = `
    <button class="qa-btn" onclick="goto('book')">📅 Book a Lesson</button>
    <button class="qa-btn" onclick="goto('courses')">📚 View Courses</button>
    <button class="qa-btn" onclick="goto('learn')">📖 Study Materials</button>
    <button class="qa-btn" onclick="goto('sessions')">🎓 Online Classes</button>
    <button class="qa-btn" onclick="goto('mocktest')">📝 Mock Test</button>
    <button class="qa-btn" onclick="goto('testbooking')">🏛️ Book Official Test</button>
    <button class="qa-btn" onclick="goto('faq')">❓ FAQ</button>
    <button class="qa-btn" onclick="goto('contact')">📞 Contact Us</button>`;
}

function renderDashUserInfo() {
  const dsUser = document.getElementById('dsUserInfo');
  if (!dsUser || !currentUser) return;
  const initials = (currentUser.first_name[0]+currentUser.last_name[0]).toUpperCase();
  const picHtml = currentUser.profile_pic
    ? `<img src="${currentUser.profile_pic}" style="width:36px;height:36px;border-radius:50%;object-fit:cover;border:2px solid rgba(255,255,255,.3)"/>`
    : `<div class="nav-avatar" style="width:36px;height:36px;font-size:.9rem">${initials}</div>`;
  dsUser.innerHTML = `
    <div style="display:flex;align-items:center;gap:.6rem;margin-bottom:.25rem">
      ${picHtml}
      <div>
        <div class="du-name">${currentUser.first_name} ${currentUser.last_name}</div>
        <div class="du-role">${currentUser.role}</div>
      </div>
    </div>
    ${currentUser.student_number?`<div style="font-size:.72rem;color:rgba(255,255,255,.35)">SN: ${currentUser.student_number}</div>`:''}`;
}

function checkDashActiveNotice() {
  const active  = getActiveCourse();
  const notice  = document.getElementById('dashActiveNotice');
  const form    = document.getElementById('dashBookFormWrap');
  if (!notice) return;
  if (active) {
    document.getElementById('dashActiveName').textContent = active.course_name;
    notice.classList.remove('hidden');
    if (form) form.classList.add('hidden');
  } else {
    notice.classList.add('hidden');
    if (form) form.classList.remove('hidden');
  }
}

function loadProfileForm() {
  if (!currentUser) return;
  const s = (id,v)=>{ const e=document.getElementById(id); if(e) e.value=v||''; };
  s('pFirst',currentUser.first_name); s('pLast',currentUser.last_name);
  s('pEmail',currentUser.email);      s('pPhone',currentUser.phone);
  s('pSn',currentUser.student_number);
  if (currentUser.role!=='student') {
    const g=document.getElementById('pSnGroup'); if(g) g.style.display='none';
  }
  // Profile picture
  updateProfilePicDisplay();
}

function updateProfilePicDisplay() {
  const display  = document.getElementById('profilePicDisplay');
  const img      = document.getElementById('profilePicImg');
  const initials = document.getElementById('profilePicInitials');
  const removeBtn= document.getElementById('removePicBtn');
  if (!display) return;
  const ini = (currentUser.first_name[0]+currentUser.last_name[0]).toUpperCase();
  if (currentUser.profile_pic) {
    if (img) { img.src=currentUser.profile_pic; img.style.display='block'; }
    if (initials) initials.style.display='none';
    if (removeBtn) removeBtn.style.display='inline-flex';
  } else {
    if (img) img.style.display='none';
    if (initials) { initials.textContent=ini; initials.style.display='block'; }
    if (removeBtn) removeBtn.style.display='none';
  }
}

function uploadProfilePic(input) {
  const file = input.files[0];
  if (!file) return;
  if (file.size > 2*1024*1024) { toast('Image too large. Max 2MB.','error'); return; }
  const reader = new FileReader();
  reader.onload = function(ev) {
    const dataUrl = ev.target.result;
    const db = getDB();
    const user = db.users.find(u=>u.id===currentUser.id);
    if (user) { user.profile_pic = dataUrl; saveDB(db); }
    currentUser.profile_pic = dataUrl;
    localStorage.setItem(SESSION_KEY, JSON.stringify(currentUser));
    updateProfilePicDisplay();
    renderNav();
    renderDashUserInfo();
    toast('Profile photo updated! 🎉','success');
  };
  reader.readAsDataURL(file);
}

function removeProfilePic() {
  const db = getDB();
  const user = db.users.find(u=>u.id===currentUser.id);
  if (user) { user.profile_pic=''; saveDB(db); }
  currentUser.profile_pic='';
  localStorage.setItem(SESSION_KEY, JSON.stringify(currentUser));
  updateProfilePicDisplay();
  renderNav();
  renderDashUserInfo();
  toast('Profile photo removed.','info');
  document.getElementById('profilePicInput').value='';
}

function updateProfile(e) {
  e.preventDefault();
  const msgEl = document.getElementById('profileMsg');
  clearMsg(msgEl);
  const db   = getDB();
  const user = db.users.find(u=>u.id===currentUser.id);
  if (!user) { showMsg(msgEl,'User not found.','error'); return; }
  user.first_name     = document.getElementById('pFirst').value.trim();
  user.last_name      = document.getElementById('pLast').value.trim();
  user.phone          = document.getElementById('pPhone').value.trim();
  user.student_number = document.getElementById('pSn').value.trim();
  saveDB(db);
  currentUser = { ...user }; delete currentUser.password;
  localStorage.setItem(SESSION_KEY, JSON.stringify(currentUser));
  renderNav(); renderDashUserInfo(); updateProfilePicDisplay();
  showMsg(msgEl,'✅ Profile updated!','success'); toast('Profile saved!','success');
}

function changePassword(e) {
  e.preventDefault();
  const msgEl = document.getElementById('pwMsg');
  clearMsg(msgEl);
  const cur  = document.getElementById('pwCur').value;
  const nw   = document.getElementById('pwNew').value;
  const conf = document.getElementById('pwConf').value;
  if (nw !== conf) { showMsg(msgEl,'Passwords do not match.','error'); return; }
  if (nw.length < 6) { showMsg(msgEl,'Min 6 characters.','error'); return; }
  const db   = getDB();
  const user = db.users.find(u=>u.id===currentUser.id);
  if (!user||user.password!==cur) { showMsg(msgEl,'Current password is incorrect.','error'); return; }
  user.password = nw; saveDB(db);
  showMsg(msgEl,'✅ Password updated!','success'); e.target.reset();
}

function dashTab(name, btn) {
  document.querySelectorAll('.dash-sidebar .dtab').forEach(b=>b.classList.remove('active'));
  document.querySelectorAll('#pg-dashboard .dtab-panel').forEach(p=>p.classList.add('hidden'));
  if(btn) btn.classList.add('active');
  const panel = document.getElementById('dtab-'+name);
  if(panel) panel.classList.remove('hidden');
  if (name==='bookings')  { loadMyBookings(); }
  if (name==='book-new')  { setMinDate(); checkDashActiveNotice(); }
  if (name==='profile')   { loadProfileForm(); }
  if (name==='readiness') { loadMyReadiness(); }
}

function setRating(r) {
  selectedRating = r;
  document.querySelectorAll('.star').forEach((s,i)=>s.classList.toggle('active',i<r));
}
function submitReview(e) {
  e.preventDefault();
  const msgEl = document.getElementById('reviewStatus');
  clearMsg(msgEl);
  const msg = document.getElementById('reviewMsg').value.trim();
  if (!msg) { showMsg(msgEl,'Please write something.','error'); return; }
  const db = getDB();
  db.testimonials.push({
    id:'rev_'+Date.now(), user_id:currentUser.id,
    name:`${currentUser.first_name} ${currentUser.last_name}`,
    msg, rating:selectedRating, is_approved:false, created_at:new Date().toISOString()
  });
  saveDB(db);
  showMsg(msgEl,'✅ Thank you! Review is pending approval.','success');
  e.target.reset(); setRating(5);
}

function updateDashPrice() {
  const sel = document.getElementById('dbkCourse');
  const opt = sel.options[sel.selectedIndex];
  const box = document.getElementById('dbkPriceBox');
  if (!sel.value) { box.classList.add('hidden'); return; }
  const isStaff = currentUser?.role==='staff';
  const price = isStaff ? parseFloat(opt.dataset.pp) : parseFloat(opt.dataset.ps);
  document.getElementById('dbkPriceAmt').textContent = `R ${price.toLocaleString()}`;
  box.classList.remove('hidden');
}

// ══════════════════════════════════════════════════
//  ADMIN DASHBOARD
// ══════════════════════════════════════════════════
function loadAdmin() {
  if (!currentUser || currentUser.role !== 'admin') { goto('login'); return; }
  const ai = document.getElementById('adminUserInfo');
  if (ai) ai.innerHTML = `<div class="du-name">${currentUser.first_name} ${currentUser.last_name}</div><div class="du-role">Administrator</div>`;
  loadAdminStats();
}

function loadAdminStats() {
  const db = getDB();
  const stats = {
    total_users:       db.users.length,
    total_students:    db.users.filter(u=>u.role==='student').length,
    total_staff:       db.users.filter(u=>u.role==='staff').length,
    total_bookings:    db.bookings.length,
    pending_bookings:  db.bookings.filter(b=>b.status==='pending').length,
    confirmed_bookings:db.bookings.filter(b=>b.status==='confirmed').length,
    new_enquiries:     db.enquiries.filter(e=>e.status==='new').length,
    total_revenue:     db.bookings.filter(b=>['confirmed','completed'].includes(b.status)).reduce((s,b)=>s+b.total_price,0),
  };
  document.getElementById('adminStats').innerHTML = [
    ['Total Users',    stats.total_users,             '#1a2744'],
    ['Students',       stats.total_students,           '#1a6b3a'],
    ['Staff',          stats.total_staff,              '#5a6b5a'],
    ['Pending',        stats.pending_bookings,         '#c8a030'],
    ['Confirmed',      stats.confirmed_bookings,       '#1a6b3a'],
    ['All Bookings',   stats.total_bookings,           '#1a2744'],
    ['New Enquiries',  stats.new_enquiries,            '#dc2626'],
    ['Revenue',        'R '+stats.total_revenue.toLocaleString(),'#1a6b3a'],
  ].map(([l,v,c])=>`<div class="ast"><div class="ast-label">${l}</div><div class="ast-val" style="color:${c}">${v}</div></div>`).join('');

  const recent = db.bookings.slice(-5).reverse();
  document.getElementById('adminRecentBk').innerHTML = recent.length
    ? `<div class="table-wrap"><table class="data-table">
        <thead><tr><th>Student</th><th>Course</th><th>Date</th><th>Status</th><th>Price</th></tr></thead>
        <tbody>${recent.map(b=>`<tr>
          <td><strong>${b.student_name}</strong></td>
          <td>${b.course_name}</td>
          <td>${b.booking_date}</td>
          <td><span class="badge badge-${b.status}">${b.status}</span></td>
          <td>R${b.total_price.toLocaleString()}</td>
        </tr>`).join('')}</tbody></table></div>`
    : '<p class="text-muted">No bookings yet.</p>';
}

function loadAdminBookings() {
  const db = getDB();
  adminBookingsCache = [...db.bookings].sort((a,b)=>new Date(b.created_at)-new Date(a.created_at));
  renderAdminBookings(adminBookingsCache);
}
function renderAdminBookings(bookings) {
  const tbody = document.getElementById('adminBkBody');
  if (!bookings.length) { tbody.innerHTML='<tr><td colspan="8" class="tbl-empty">No bookings.</td></tr>'; return; }
  tbody.innerHTML = bookings.map(b=>`
    <tr>
      <td style="font-family:monospace;font-size:.75rem">${b.id.slice(-6)}</td>
      <td><strong>${b.student_name}</strong><span class="tbl-sub">${b.student_email}</span></td>
      <td>${b.course_name}</td>
      <td>${b.booking_date}</td>
      <td>${b.booking_time}</td>
      <td>R${b.total_price.toLocaleString()}</td>
      <td><span class="badge badge-${b.status}">${b.status}</span></td>
      <td class="tbl-actions">
        ${b.status==='pending'?`<button class="btn btn-xs btn-green" onclick="adminBkStatus('${b.id}','confirmed')">✅</button>`:''}
        ${['pending','confirmed'].includes(b.status)?`<button class="btn btn-xs btn-red" onclick="adminBkStatus('${b.id}','cancelled')">❌</button>`:''}
        ${b.status==='confirmed'?`<button class="btn btn-xs btn-ghost" onclick="adminBkStatus('${b.id}','completed')">✔</button>`:''}
      </td>
    </tr>`).join('');
}
function filterAdminBookings() {
  const q = document.getElementById('bkSearch').value.toLowerCase();
  renderAdminBookings(adminBookingsCache.filter(b=>
    b.student_name.toLowerCase().includes(q)||b.course_name.toLowerCase().includes(q)||
    b.status.includes(q)||b.booking_date.includes(q)
  ));
}
function adminBkStatus(id, status) {
  const db=getDB(); const bk=db.bookings.find(b=>b.id===id);
  if(bk){bk.status=status;saveDB(db);}
  toast(`Booking ${status}.`,'success'); loadAdminBookings(); loadAdminStats();
}

function loadAdminUsers() {
  const db=getDB();
  adminUsersCache=[...db.users].sort((a,b)=>new Date(b.created_at)-new Date(a.created_at));
  renderAdminUsers(adminUsersCache);
}
function renderAdminUsers(users) {
  const tbody=document.getElementById('adminUsersBody');
  if(!users.length){tbody.innerHTML='<tr><td colspan="7" class="tbl-empty">No users.</td></tr>';return;}
  tbody.innerHTML = users.map(u=>`
    <tr>
      <td>
        <div style="display:flex;align-items:center;gap:.6rem">
          ${u.profile_pic ? `<img src="${u.profile_pic}" style="width:28px;height:28px;border-radius:50%;object-fit:cover"/>` :
            `<div style="width:28px;height:28px;border-radius:50%;background:var(--navy);color:#fff;font-size:.7rem;font-weight:800;display:flex;align-items:center;justify-content:center">${(u.first_name[0]+u.last_name[0]).toUpperCase()}</div>`}
          <strong>${u.first_name} ${u.last_name}</strong>
        </div>
      </td>
      <td>${u.email}</td>
      <td><span class="role-badge role-${u.role}">${u.role}</span></td>
      <td>${u.student_number||'—'}</td>
      <td class="tbl-sub">${(u.created_at||'').substring(0,10)}</td>
      <td>${u.is_active?'<span style="color:var(--green);font-weight:700">Active</span>':'<span style="color:var(--red);font-weight:700">Inactive</span>'}</td>
      <td>${u.role!=='admin'?`<button class="btn btn-xs btn-ghost" onclick="toggleUser('${u.id}')">${u.is_active?'Deactivate':'Activate'}</button>`:'—'}</td>
    </tr>`).join('');
}
function filterAdminUsers() {
  const q=document.getElementById('userSearch').value.toLowerCase();
  renderAdminUsers(adminUsersCache.filter(u=>
    `${u.first_name} ${u.last_name}`.toLowerCase().includes(q)||u.email.toLowerCase().includes(q)||u.role.includes(q)
  ));
}
function toggleUser(id) {
  const db=getDB(); const user=db.users.find(u=>u.id===id);
  if(user){user.is_active=!user.is_active;saveDB(db);}
  toast(`User ${user.is_active?'activated':'deactivated'}.`,'info'); loadAdminUsers();
}

function loadAdminEnquiries() {
  const db=getDB();
  const el=document.getElementById('adminEnqList');
  const enquiries=[...db.enquiries].sort((a,b)=>new Date(b.created_at)-new Date(a.created_at));
  if(!enquiries.length){el.innerHTML='<p class="text-muted">No enquiries yet.</p>';return;}
  el.innerHTML=enquiries.map(eq=>`
    <div class="enq-card">
      <div class="enq-hdr">
        <div><strong>${eq.name}</strong><span class="tbl-sub">${eq.email}${eq.phone?' · '+eq.phone:''}</span></div>
        <div style="display:flex;gap:.5rem;align-items:center">
          <span class="badge badge-${eq.status==='new'?'pending':'confirmed'}">${eq.status}</span>
          ${eq.status==='new'?`<button class="btn btn-xs btn-ghost" onclick="markEnquiry('${eq.id}','read')">Mark Read</button>`:''}
        </div>
      </div>
      <p style="font-size:.88rem;color:var(--muted);margin:.4rem 0">${eq.message}</p>
      <div class="tbl-sub">${(eq.created_at||'').substring(0,10)}</div>
    </div>`).join('');
}
function markEnquiry(id,status) {
  const db=getDB(); const eq=db.enquiries.find(e=>e.id===id);
  if(eq){eq.status=status;saveDB(db);} loadAdminEnquiries(); loadAdminStats();
}

function loadAdminReviews() {
  const db=getDB();
  const el=document.getElementById('adminRevList');
  const all=[...db.testimonials].sort((a,b)=>new Date(b.created_at)-new Date(a.created_at));
  if(!all.length){el.innerHTML='<p class="text-muted">No reviews yet.</p>';return;}
  el.innerHTML=all.map(t=>`
    <div class="bk-item">
      <div class="bk-hdr">
        <strong>${t.name}</strong>
        <div style="display:flex;align-items:center;gap:.75rem">
          <span style="color:var(--gold)">${'★'.repeat(t.rating)}</span>
          ${t.is_approved?`<span style="color:var(--green);font-size:.8rem;font-weight:700">✅ Approved</span>`:`<span style="background:#fef3c7;color:#92400e;padding:.15rem .5rem;border-radius:99px;font-size:.72rem;font-weight:700">Pending</span>`}
        </div>
      </div>
      <p style="font-size:.88rem;color:var(--muted);margin:.4rem 0">${t.msg}</p>
      <div style="display:flex;gap:.5rem;margin-top:.6rem">
        ${!t.is_approved?`<button class="btn btn-sm btn-primary" onclick="approveReview('${t.id}')">✅ Approve</button>`:''}
        <button class="btn btn-sm btn-red" onclick="deleteReview('${t.id}')">🗑 Delete</button>
      </div>
    </div>`).join('');
}
function approveReview(id) {
  const db=getDB(); const t=db.testimonials.find(r=>r.id===id);
  if(t){t.is_approved=true;saveDB(db);} toast('Approved!','success'); loadAdminReviews(); loadHome();
}
function deleteReview(id) {
  if(!confirm('Delete this review?')) return;
  const db=getDB(); db.testimonials=db.testimonials.filter(r=>r.id!==id); saveDB(db);
  toast('Deleted.','info'); loadAdminReviews();
}

function adminTab(name,btn) {
  document.querySelectorAll('.admin-sidebar .dtab').forEach(b=>b.classList.remove('active'));
  document.querySelectorAll('#pg-admin .dtab-panel').forEach(p=>p.classList.add('hidden'));
  if(btn) btn.classList.add('active');
  const panel=document.getElementById('atab-'+name);
  if(panel) panel.classList.remove('hidden');
  const loaders={stats:loadAdminStats,bookings:loadAdminBookings,users:loadAdminUsers,enquiries:loadAdminEnquiries,reviews:loadAdminReviews,vehicles:loadAdminVehicles,ai:loadAdminAI};
  if(loaders[name]) loaders[name]();
}

// ══════════════════════════════════════════════════
//  STUDY MATERIALS
// ══════════════════════════════════════════════════
function loadLearn() { learnTab('signs', document.querySelector('.ltab')); }
function learnTab(name,btn) {
  document.querySelectorAll('.ltab').forEach(b=>b.classList.remove('active'));
  document.querySelectorAll('.ltab-content').forEach(c=>c.classList.add('hidden'));
  if(btn) btn.classList.add('active');
  const el=document.getElementById('lc-'+name); if(el) el.classList.remove('hidden');
}

// ══════════════════════════════════════════════════
//  ONLINE SESSIONS (CLASSES PAGE)
// ══════════════════════════════════════════════════
function loadSessions() {
  const gate    = document.getElementById('sessionsGate');
  const content = document.getElementById('sessionsContent');
  if (!currentUser) { gate.classList.remove('hidden'); content.classList.add('hidden'); return; }
  gate.classList.add('hidden'); content.classList.remove('hidden');
  renderTodaySchedule();
  renderUpcomingList();
  renderRecordedSessions();
}

const LIVE_SESSIONS = [
  { time:'08:00', ampm:'AM', title:"K53 Theory — Road Signs & Rules", instructor:"Ms. Nompumelelo Zulu", status:'live',
    link:'https://teams.microsoft.com/l/meetup-join/DEMO_THEORY_001' },
  { time:'10:00', ampm:'AM', title:'Code 8 Pre-Lesson Briefing', instructor:'Mr. Sipho Mkhize', status:'upcoming',
    link:'https://teams.microsoft.com/l/meetup-join/DEMO_CODE8_001' },
  { time:'13:00', ampm:'PM', title:'Adaptive Driving Q&A Session', instructor:'Mr. Bongani Ndlela', status:'upcoming',
    link:'https://teams.microsoft.com/l/meetup-join/DEMO_ADAPTIVE_001' },
  { time:'15:30', ampm:'PM', title:'Mock Test Preparation & Tips', instructor:'Ms. Nompumelelo Zulu', status:'upcoming',
    link:'https://teams.microsoft.com/l/meetup-join/DEMO_MOCK_001' },
];

const UPCOMING_SESSIONS = [
  { dow:'Mon', day:'09', title:'K53 Road Signs Deep Dive', instructor:'Ms. N. Zulu', time:'09:00–10:30', link:'https://teams.microsoft.com/l/meetup-join/DEMO_SIGNS_002' },
  { dow:'Tue', day:'10', title:'Vehicle Controls & K53 Manoeuvres', instructor:'Mr. S. Mkhize', time:'10:00–11:30', link:'https://teams.microsoft.com/l/meetup-join/DEMO_CTRL_002' },
  { dow:'Wed', day:'11', title:'Rules of the Road — Intersections', instructor:'Mr. B. Ndlela', time:'14:00–15:30', link:'https://teams.microsoft.com/l/meetup-join/DEMO_RULES_002' },
  { dow:'Thu', day:'12', title:'Full Mock Test + Review Session', instructor:'Ms. N. Zulu', time:'09:00–11:00', link:'https://teams.microsoft.com/l/meetup-join/DEMO_FULL_002' },
  { dow:'Fri', day:'13', title:'Code 10 Heavy Vehicle Theory', instructor:'Mr. S. Mkhize', time:'13:00–14:30', link:'https://teams.microsoft.com/l/meetup-join/DEMO_C10_002' },
];

const RECORDED_SESSIONS_DATA = [
  { id:'rec1', title:'Introduction to K53 — What to Expect', icon:'🎬', color:'#dbeafe', sub:'45 min · Recorded Jun 1', instructor:'Ms. N. Zulu',
    desc:'Overview of the K53 learner\'s test format, what chapters are covered, and how to prepare.' },
  { id:'rec2', title:'Road Signs Masterclass — All 3 Categories', icon:'🚦', color:'#fee2e2', sub:'60 min · Recorded Jun 2', instructor:'Ms. N. Zulu',
    desc:'Complete walkthrough of regulatory, warning, and informatory signs with examples.' },
  { id:'rec3', title:'Rules of the Road — Right of Way', icon:'🛣️', color:'#dcfce7', sub:'40 min · Recorded Jun 3', instructor:'Mr. S. Mkhize',
    desc:'Right of way at uncontrolled intersections, 4-way stops, roundabouts, and emergency vehicles.' },
  { id:'rec4', title:'Vehicle Controls & MSM Routine', icon:'🎛️', color:'#ede9fe', sub:'55 min · Recorded Jun 4', instructor:'Mr. B. Ndlela',
    desc:'Mirror-Signal-Manoeuvre, blind spots, clutch control, hill starts, and K53 yard manoeuvres.' },
  { id:'rec5', title:'Code 8 Practical Demonstration', icon:'🚗', color:'#fef9c3', sub:'50 min · Recorded Jun 5', instructor:'Mr. S. Mkhize',
    desc:'On-road demonstration of K53 driving test route with commentary on scoring and common mistakes.' },
  { id:'rec6', title:'Adaptive Driving — Info Session', icon:'♿', color:'#f0fdf4', sub:'35 min · Recorded Jun 3', instructor:'Mr. B. Ndlela',
    desc:'Information for students requiring adaptive driving training: available vehicles, assessment, enrolment.' },
];

function renderTodaySchedule() {
  const grid = document.getElementById('todaySchedule');
  if (!grid) return;
  grid.innerHTML = LIVE_SESSIONS.map(s => `
    <div class="schedule-card">
      <div class="sc-time-badge">
        <div class="sc-time">${s.time}</div>
        <div class="sc-ampm">${s.ampm}</div>
      </div>
      <div class="sc-body">
        <h4>${s.title}</h4>
        <div class="sc-instructor">👩‍🏫 ${s.instructor}</div>
        <a class="sc-join-btn ${s.status}" href="${s.link}" target="_blank" onclick="return confirmJoin()">
          ${s.status==='live' ? '🔴 Join Live' : '🔗 Join Session'}
        </a>
      </div>
    </div>`).join('');
}

function renderUpcomingList() {
  const list = document.getElementById('upcomingList');
  if (!list) return;
  list.innerHTML = UPCOMING_SESSIONS.map(s => `
    <div class="upcoming-item">
      <div class="ui-left">
        <div class="ui-day">
          <div class="ud-day">${s.day}</div>
          <div class="ud-dow">${s.dow}</div>
        </div>
        <div class="ui-info">
          <h4>${s.title}</h4>
          <p>👩‍🏫 ${s.instructor} &nbsp; 🕐 ${s.time}</p>
        </div>
      </div>
      <a class="sc-join-btn upcoming" href="${s.link}" target="_blank" onclick="return confirmJoin()">Register / Join</a>
    </div>`).join('');
}

function renderRecordedSessions() {
  const prog = getSessionProgress();
  const grid = document.getElementById('sessionsGrid');
  if (!grid) return;
  grid.innerHTML = RECORDED_SESSIONS_DATA.map(s => {
    const done = prog[s.id];
    return `
      <div class="sess-card ${done?'completed':''}" onclick="openSession('${s.id}')">
        <div class="sess-hdr">
          <div class="sess-icon" style="background:${s.color}">${s.icon}</div>
          <div class="sess-meta">
            <div class="sess-title">${s.title}</div>
            <div class="sess-sub">${s.sub}</div>
          </div>
          <span class="sess-status ${done?'done':'todo'}">${done?'✅ Done':'▶ Watch'}</span>
        </div>
        <div class="sess-body">
          <div class="sess-progress"><div class="sess-pbar" style="width:${done?100:0}%"></div></div>
          <p class="sess-desc">${s.desc}</p>
          <button class="btn btn-primary sess-btn">${done?'🔄 Watch Again':'▶ Watch Recording'}</button>
        </div>
      </div>`;
  }).join('');
}

function confirmJoin() {
  toast('Opening Microsoft Teams meeting link…','info');
  return true;
}

function getSessionProgress() {
  const raw = localStorage.getItem('unidrive_sess_prog_'+(currentUser?.id||''));
  return raw ? JSON.parse(raw) : {};
}
function saveSessionProgress(p) {
  localStorage.setItem('unidrive_sess_prog_'+currentUser.id, JSON.stringify(p));
}

function openSession(id) {
  const s = RECORDED_SESSIONS_DATA.find(x=>x.id===id);
  if (!s) return;
  document.getElementById('sessionModalTitle').textContent = s.icon+' '+s.title;
  document.getElementById('sessionModalBody').innerHTML = `
    <div style="padding:1.4rem">
      <div style="background:${s.color};border-radius:var(--radius);padding:1.1rem 1.25rem;margin-bottom:1.25rem;display:flex;align-items:flex-start;gap:.85rem">
        <span style="font-size:2rem">${s.icon}</span>
        <div>
          <div style="font-weight:700;font-size:1rem;margin-bottom:.2rem">${s.title}</div>
          <div style="font-size:12.5px;color:var(--muted)">👩‍🏫 ${s.instructor} &nbsp; 🕐 ${s.sub}</div>
        </div>
      </div>
      <p style="font-size:13.5px;color:var(--muted);margin-bottom:1.5rem">${s.desc}</p>

      <div style="background:#0a1930;border-radius:var(--radius);padding:2.5rem;text-align:center;margin-bottom:1.25rem;border:1px solid rgba(255,255,255,.1)">
        <div style="font-size:3.5rem;margin-bottom:.75rem">▶</div>
        <div style="color:#fff;font-weight:700;margin-bottom:.4rem">Recorded Class Playback</div>
        <div style="color:rgba(255,255,255,.5);font-size:12.5px;margin-bottom:1.2rem">${s.sub}</div>
        <a href="https://teams.microsoft.com/l/meetup-join/DEMO_RECORDING_${id}" target="_blank"
           class="btn btn-gold" onclick="markSessionComplete('${id}');return true;">
          ▶ Watch via Microsoft Teams
        </a>
      </div>
      <div style="background:var(--off);border-radius:var(--radius);padding:.85rem 1rem;margin-bottom:1rem;font-size:13px;color:var(--muted)">
        📌 <strong>Note:</strong> This is a simulated demo link. In the live system, clicking this would open the actual Teams recording from your instructor's session.
      </div>
      <button class="btn btn-primary btn-full" onclick="markSessionComplete('${id}')">✅ Mark as Watched</button>
    </div>`;
  document.getElementById('sessionModal').classList.remove('hidden');
  document.body.style.overflow = 'hidden';
}

function markSessionComplete(id) {
  const prog = getSessionProgress(); prog[id]=true; saveSessionProgress(prog);
  renderRecordedSessions();
  toast('Session marked as watched! ✅','success');
}
function closeSessionModal() {
  document.getElementById('sessionModal').classList.add('hidden');
  document.body.style.overflow='';
}

// ══════════════════════════════════════════════════
//  MOCK TEST (full 68-question K53 engine)
// ══════════════════════════════════════════════════
function loadMocktest() {
  const gate=document.getElementById('mocktestGate');
  const content=document.getElementById('mocktestContent');
  if (!currentUser) { gate.classList.remove('hidden'); content.classList.add('hidden'); return; }
  gate.classList.add('hidden'); content.classList.remove('hidden');
  showMtHistory(); showSection('mt-start');
}

const MOCK_QUESTIONS = [
  {cat:'Road Signs',q:'A red octagonal STOP sign means:',opts:['Slow down and look both ways','Come to a complete stop and yield','Stop if other vehicles are present','Reduce speed to 20 km/h'],a:1},
  {cat:'Road Signs',q:'A red circle with a white horizontal bar means:',opts:['Max speed limit','No entry for vehicles','No stopping','Yield to oncoming traffic'],a:1},
  {cat:'Road Signs',q:'A yellow diamond-shaped sign indicates:',opts:['A mandatory instruction','A warning of hazard ahead','A speed limit','An information guide'],a:1},
  {cat:'Road Signs',q:'A round blue sign with a white arrow pointing right means:',opts:['You may turn right','You MUST turn right','No right turn','Right lane ends'],a:1},
  {cat:'Road Signs',q:'What colour are regulatory signs in South Africa?',opts:['Yellow and black','Blue and white','Red, white, and black','Green and white'],a:2},
  {cat:'Road Signs',q:'A triangular sign with a red border is a:',opts:['Regulatory sign','Warning sign','Yield sign','Information sign'],a:2},
  {cat:'Road Signs',q:'What does a sign with 80 inside a red circle mean?',opts:['Minimum speed 80','Maximum speed 80','Advisory 80','End of speed limit'],a:1},
  {cat:'Road Signs',q:'A broken white centre line means:',opts:['No overtaking','You may overtake if safe','Road ending','Pedestrian zone'],a:1},
  {cat:'Road Signs',q:'A solid yellow line on your side means:',opts:['Slow down','You may NOT cross or overtake','End of restriction','Bicycle lane'],a:1},
  {cat:'Road Signs',q:'An inverted triangle sign (point down) means:',opts:['Stop completely','Yield to all traffic','Warning of danger','One-way road'],a:1},
  {cat:'Road Signs',q:'What does a "No Stopping" sign mean?',opts:['Stop for 5 minutes only','No stopping at all','Stop to drop passengers','30 min parking'],a:1},
  {cat:'Road Signs',q:'What shape is a STOP sign?',opts:['Triangle','Circle','Octagon','Diamond'],a:2},
  {cat:'Road Signs',q:'A level crossing sign warns you of:',opts:['A steep hill','A railway crossing','A pedestrian crossing','A sharp bend'],a:1},
  {cat:'Road Signs',q:'Green direction signs indicate:',opts:['Major hazards','Mandatory turns','Routes on national roads','No-go zones'],a:2},
  {cat:'Road Signs',q:'A "No Overtaking" sign applies until:',opts:['You passed 5 vehicles','Next traffic light','End-of-restriction sign or road marking change','After 2 km'],a:2},
  {cat:'Road Signs',q:'A sign showing two opposing arrows on a narrow road means:',opts:['Overtaking permitted','Two-way traffic ahead','Road narrows','High speed zone'],a:1},
  {cat:'Road Signs',q:'A blue rectangular "P" sign means:',opts:['Parking prohibited','Parking permitted','Police ahead','Pedestrian zone'],a:1},
  {cat:'Road Signs',q:'When you see a "Slippery Road" sign you should:',opts:['Increase speed','Reduce speed and avoid harsh braking','Switch to neutral','Brake firmly'],a:1},
  {cat:'Road Signs',q:'A sign with children and a school building means:',opts:['40 km/h applies','Children may cross anywhere','School buses have priority','No under-18s'],a:0},
  {cat:'Road Signs',q:'What does a pedestrian crossing warning sign look like?',opts:['Blue rectangle with walking person','Yellow diamond with walking figure','Red octagon','Green rectangle'],a:1},
  {cat:'Road Signs',q:'A sign with a torch icon warns of:',opts:['Tunnel ahead','Low visibility zone','No lights zone','Emergency vehicles'],a:0},
  {cat:'Road Signs',q:'What does "NO ENTRY" mean?',opts:['Yield to oncoming traffic','You may not enter in this direction','One-way caution','Road closed temporarily'],a:1},
  {cat:'Rules of the Road',q:'At an uncontrolled intersection you must yield to:',opts:['Vehicles on your left','Vehicles on your right','Vehicles straight ahead','No one — first to arrive proceeds'],a:1},
  {cat:'Rules of the Road',q:'At a 4-way stop, two vehicles arrive simultaneously. Who goes first?',opts:['The heavier vehicle','Vehicle on left yields to vehicle on right','The faster vehicle','Vehicle going straight'],a:1},
  {cat:'Rules of the Road',q:'The general speed limit on a South African freeway is:',opts:['100 km/h','110 km/h','120 km/h','140 km/h'],a:2},
  {cat:'Rules of the Road',q:'Legal blood alcohol limit for a driver in South Africa:',opts:['0.02g/100ml','0.05g/100ml','0.08g/100ml','0.10g/100ml'],a:1},
  {cat:'Rules of the Road',q:'The 2-second rule is used to maintain:',opts:['Correct speed','Safe following distance','Lane position','Mirror check frequency'],a:1},
  {cat:'Rules of the Road',q:'When may you use a cell phone while driving?',opts:['At a red light','Only to make calls','Only with a hands-free system','Never while moving'],a:3},
  {cat:'Rules of the Road',q:'In wet conditions your following distance should be:',opts:['Same as dry','Halved','Doubled to at least 4 seconds','Tripled'],a:2},
  {cat:'Rules of the Road',q:'A yellow traffic light means:',opts:['Speed up to clear intersection','Stop if safe to do so','Always proceed','Flash lights'],a:1},
  {cat:'Rules of the Road',q:'When must headlights be used?',opts:['Only in fog','30 min after sunset to 30 min before sunrise','Only on freeways at night','Over 100 km/h'],a:1},
  {cat:'Rules of the Road',q:'On which side may you overtake in South Africa?',opts:['Left only','Right only','Either if safe','Only on freeways'],a:1},
  {cat:'Rules of the Road',q:'You must NOT overtake when:',opts:['On a straight with good visibility','Near the crest of a hill or blind rise','Vehicle in front is at 60 km/h','On a dual carriageway'],a:1},
  {cat:'Rules of the Road',q:'Are all occupants required to wear seat belts?',opts:['Only the driver','Driver and front passenger','All occupants','Only adults over 18'],a:2},
  {cat:'Rules of the Road',q:'Who is responsible for ensuring passengers under 14 are buckled?',opts:['The passenger','The parent','The driver','It is voluntary'],a:2},
  {cat:'Rules of the Road',q:'A learner licence holder blood alcohol limit is:',opts:['0.05g/100ml','0.02g/100ml','0.00g/100ml (zero)','0.08g/100ml'],a:2},
  {cat:'Rules of the Road',q:'When approaching an emergency vehicle with sirens, you must:',opts:['Speed up','Pull left and stop until it passes','Continue at same speed','Flash your lights'],a:1},
  {cat:'Rules of the Road',q:'Urban speed limit in South Africa:',opts:['50 km/h','60 km/h','70 km/h','80 km/h'],a:1},
  {cat:'Rules of the Road',q:'You must NOT use the hooter (horn):',opts:['To warn of danger on open road','Between 21:00 and 06:00 in built-up area','In an emergency','When pedestrian steps in road'],a:1},
  {cat:'Rules of the Road',q:'In a roundabout, who has right of way?',opts:['Vehicles entering','Vehicles already inside','The largest vehicle','Vehicles on the left'],a:1},
  {cat:'Rules of the Road',q:'A double solid centre line means:',opts:['Overtaking allowed for faster vehicles','No vehicle may cross or overtake','Road is ending','Speed doubles'],a:1},
  {cat:'Rules of the Road',q:'At a zebra crossing you must:',opts:['Hoot to warn pedestrians','Yield to pedestrians already on crossing','Stop only if in your lane','Flash lights and proceed slowly'],a:1},
  {cat:'Rules of the Road',q:'How far before a turn should you signal?',opts:['At least 20 m','At least 30 m','At least 50 m','At the turn itself'],a:1},
  {cat:'Rules of the Road',q:'You are in an accident. What to do FIRST?',opts:['Leave and report later','Stop, warn traffic, assist injured, report to police','Take photos and leave','Move all vehicles immediately'],a:1},
  {cat:'Rules of the Road',q:'Is a U-turn at a traffic light legal?',opts:['Yes, always','No, never','Yes, unless a sign prohibits it','Only on a green arrow'],a:2},
  {cat:'Rules of the Road',q:'A broken yellow line between lanes means:',opts:['You may NOT overtake','You may change lanes if safe','Road ending','Bus lane'],a:1},
  {cat:'Rules of the Road',q:'Minimum tread depth for vehicle tyres:',opts:['1 mm','1.6 mm','2.5 mm','3 mm'],a:1},
  {cat:'Rules of the Road',q:'When parking on a hill facing uphill, wheels should be turned:',opts:['Straight ahead','Toward the kerb (right)','Away from kerb (left)','Position does not matter'],a:2},
  {cat:'Vehicle Controls',q:'MSM routine stands for:',opts:['Move, Stop, Manoeuvre','Mirror, Signal, Manoeuvre','Monitor, Steer, Move','Mirror, Speed, Move'],a:1},
  {cat:'Vehicle Controls',q:'Before moving off, a blind spot check is done by:',opts:['Checking interior mirror only','Looking over your shoulder in direction of travel','Sounding the hooter','Checking door mirror only'],a:1},
  {cat:'Vehicle Controls',q:'The clutch pedal on a manual vehicle is on the:',opts:['Far right','Middle','Far left','Steering column'],a:2},
  {cat:'Vehicle Controls',q:'To prevent rolling back on a hill start, use:',opts:['Accelerator only','Handbrake method or left-foot clutch technique','High gear','Neutral with foot on brake'],a:1},
  {cat:'Vehicle Controls',q:'When should you check mirrors?',opts:['Only when turning','Only when changing lanes','Before every signal, speed change, or manoeuvre','Only when reversing'],a:2},
  {cat:'Vehicle Controls',q:'Coasting (neutral downhill) is dangerous because:',opts:['Increases tyre wear','You have no engine braking and less steering control','It improves fuel economy too much','It overheats the clutch'],a:1},
  {cat:'Vehicle Controls',q:'What is the "biting point" on a clutch?',opts:['When pedal is fully pressed','Point where clutch starts to engage and car moves','When gear is fully engaged','Only in first gear'],a:1},
  {cat:'Vehicle Controls',q:'Emergency stop WITHOUT ABS brakes:',opts:['Pump brakes rapidly','Apply steady firm pressure','Press as hard as possible and hold','Use handbrake first'],a:0},
  {cat:'Vehicle Controls',q:'Emergency stop WITH ABS brakes:',opts:['Pump brakes rapidly','Press hard and hold — ABS prevents lock','Use handbrake simultaneously','Apply clutch and brake at once'],a:1},
  {cat:'Vehicle Controls',q:'Low beams should be switched to high beams when:',opts:['In fog','Approaching oncoming vehicle within 150 m','On open dark road with no oncoming traffic','In heavy rain'],a:2},
  {cat:'Vehicle Controls',q:'You must NOT use the handbrake as primary stopping device:',opts:['When parking','When stopped on a hill','While vehicle is moving at speed','Before leaving the vehicle'],a:2},
  {cat:'Vehicle Controls',q:'Correct sequence when stopping:',opts:['Brake → Clutch → Handbrake → Neutral','Clutch → Brake → Neutral → Handbrake','Neutral → Brake → Clutch → Handbrake','Handbrake → Neutral → Clutch → Brake'],a:0},
  {cat:'Vehicle Controls',q:'Before a right turn, check mirrors in this order:',opts:['Right door mirror only','Interior mirror then right door mirror','Right door mirror then interior','Blind spot only'],a:1},
  {cat:'Vehicle Controls',q:'When parallel parking, your vehicle must end within __ of the kerb:',opts:['15 cm','30 cm','50 cm','1 metre'],a:1},
  {cat:'Vehicle Controls',q:'A three-point turn must be completed:',opts:['In exactly 3 moves','Without mounting kerb and only when safe','At speeds under 10 km/h','Only on painted centreline roads'],a:1},
  {cat:'Vehicle Controls',q:'The rear-view (interior) mirror shows:',opts:['Front of vehicle','Directly behind through rear window','Both side blind spots','Road ahead via camera'],a:1},
  {cat:'Vehicle Controls',q:'Before getting into a vehicle, a driver should:',opts:['Start engine immediately','Do a walk-around check for defects','Adjust seat first','Check fuel gauge on dash'],a:1},
  {cat:'Vehicle Controls',q:'Which dashboard light indicates low oil pressure?',opts:['Battery with lightning bolt','Engine outline','Oil can symbol','Thermometer'],a:2},
  {cat:'Vehicle Controls',q:'To signal a right turn you use:',opts:['Left turn signal lever','Right turn signal lever (indicator)','Flash headlights','Use hooter'],a:1},
];

let mtQuestions=[],mtCurrent=0,mtAnswers={},mtTimer=null,mtSecsLeft=1800;

function shuffle(arr){const a=[...arr];for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;}

function showMtHistory() {
  const key='unidrive_mt_'+(currentUser?.id||'');
  const raw=localStorage.getItem(key);
  const hist=raw?JSON.parse(raw):[];
  const el=document.getElementById('mt-history');
  if(!el||!hist.length) return;
  el.innerHTML=`
    <div class="mt-history-wrap">
      <div class="mt-history-title">📊 Your Previous Results (last 5)</div>
      ${hist.slice(-5).reverse().map(h=>`
        <div class="mt-hist-row">
          <span>${h.date}</span>
          <span>${h.score}/${h.total} (${Math.round(h.score/h.total*100)}%)</span>
          <span class="badge badge-${h.passed?'confirmed':'cancelled'}">${h.passed?'PASS':'FAIL'}</span>
        </div>`).join('')}
    </div>`;
}

function startMockTest() {
  const signs=shuffle(MOCK_QUESTIONS.filter(q=>q.cat==='Road Signs')).slice(0,22);
  const rules=shuffle(MOCK_QUESTIONS.filter(q=>q.cat==='Rules of the Road')).slice(0,26);
  const ctrls=shuffle(MOCK_QUESTIONS.filter(q=>q.cat==='Vehicle Controls')).slice(0,20);
  mtQuestions=shuffle([...signs,...rules,...ctrls]);
  mtCurrent=0; mtAnswers={}; mtSecsLeft=1800;
  showSection('mt-test'); renderMtQuestion(); startMtTimer();
}

function renderMtQuestion() {
  const q=mtQuestions[mtCurrent], total=mtQuestions.length;
  document.getElementById('mt-q-counter').textContent=`Question ${mtCurrent+1} of ${total}`;
  document.getElementById('mtPbarFill').style.width=((mtCurrent+1)/total*100)+'%';
  document.getElementById('mt-prev-btn').disabled=mtCurrent===0;
  document.getElementById('mt-next-btn').textContent=mtCurrent===total-1?'✅ Submit Test':'Next →';
  const letters=['A','B','C','D'], chosen=mtAnswers[mtCurrent];
  document.getElementById('mt-question-wrap').innerHTML=`
    <div class="mt-q-category">${q.cat}</div>
    <div class="mt-q-text">${q.q}</div>
    <div class="mt-options">
      ${q.opts.map((o,i)=>`
        <button class="mt-opt ${chosen===i?'selected':''}" onclick="selectMtAnswer(${i},this)">
          <span class="mt-opt-letter">${letters[i]}</span>${o}
        </button>`).join('')}
    </div>`;
}

function selectMtAnswer(idx,btn) {
  mtAnswers[mtCurrent]=idx;
  document.querySelectorAll('.mt-opt').forEach(b=>b.classList.remove('selected'));
  btn.classList.add('selected');
}
function mtNext() { mtCurrent===mtQuestions.length-1?submitMockTest():(mtCurrent++,renderMtQuestion()); }
function mtPrev() { if(mtCurrent>0){mtCurrent--;renderMtQuestion();} }

function startMtTimer() {
  clearInterval(mtTimer); updateMtTimerDisplay();
  mtTimer=setInterval(()=>{
    mtSecsLeft--; updateMtTimerDisplay();
    if(mtSecsLeft<=0){clearInterval(mtTimer);toast('⏱️ Time up! Submitting…','info');submitMockTest();}
  },1000);
}
function updateMtTimerDisplay() {
  const m=Math.floor(mtSecsLeft/60),s=mtSecsLeft%60;
  const el=document.getElementById('mt-timer'); if(!el) return;
  el.textContent=`${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
  el.classList.toggle('urgent',mtSecsLeft<=120);
}

function submitMockTest() {
  clearInterval(mtTimer);
  let correct=0;
  const total=mtQuestions.length;
  mtQuestions.forEach((q,i)=>{if(mtAnswers[i]===q.a)correct++;});
  const pct=Math.round(correct/total*100);
  const passed=correct>=Math.ceil(total*0.77);
  const key='unidrive_mt_'+currentUser.id;
  const raw=localStorage.getItem(key);
  const hist=raw?JSON.parse(raw):[];
  hist.push({date:new Date().toLocaleDateString('en-ZA'),score:correct,total,passed});
  localStorage.setItem(key,JSON.stringify(hist));
  const letters=['A','B','C','D'];
  document.getElementById('mtResultCard').innerHTML=`
    <div class="mt-result-score ${passed?'pass':'fail'}">${pct}%</div>
    <div class="mt-result-label">${passed?'🎉 PASS — Well Done!':'❌ FAIL — Keep Studying!'}</div>
    <div class="mt-result-sub">You scored ${correct} out of ${total}.
      ${passed?'You are ready for the official K53 test!':'You need 77% (≥'+Math.ceil(total*0.77)+' correct) to pass.'}</div>
    <div class="mt-result-breakdown">
      <div class="mt-rb-item"><div class="mt-rb-num" style="color:var(--green)">${correct}</div><div class="mt-rb-lbl">Correct</div></div>
      <div class="mt-rb-item"><div class="mt-rb-num" style="color:#ef4444">${total-correct}</div><div class="mt-rb-lbl">Wrong</div></div>
      <div class="mt-rb-item"><div class="mt-rb-num">${total}</div><div class="mt-rb-lbl">Total</div></div>
    </div>`;
  document.getElementById('mt-review').innerHTML=`
    <h3 style="font-family:'Syne',sans-serif;margin-bottom:1rem">📋 Answer Review</h3>
    ${mtQuestions.map((q,i)=>{
      const chosen=mtAnswers[i],isCorrect=chosen===q.a;
      return `<div class="mt-rv-item ${isCorrect?'rv-correct':'rv-wrong'}">
        <div class="mt-rv-q">${i+1}. ${q.q} <span class="mt-rv-badge ${isCorrect?'correct':'wrong'}">${isCorrect?'✅ Correct':'❌ Wrong'}</span></div>
        <div class="mt-rv-a">${!isCorrect?`Your answer: <em>${chosen!==undefined?letters[chosen]+'. '+q.opts[chosen]:'Not answered'}</em> · `:''} Correct: <strong>${letters[q.a]}. ${q.opts[q.a]}</strong></div>
      </div>`;
    }).join('')}`;
  showSection('mt-results');
}

function showSection(id) {
  ['mt-start','mt-test','mt-results'].forEach(s=>{
    const el=document.getElementById(s); if(el) el.classList.toggle('hidden',s!==id);
  });
}

// ══════════════════════════════════════════════════
//  OFFICIAL TEST BOOKING
// ══════════════════════════════════════════════════
function loadTestBooking() {
  const gate=document.getElementById('testbookGate');
  const content=document.getElementById('testbookContent');
  if (!currentUser) { gate.classList.remove('hidden'); content.classList.add('hidden'); return; }
  gate.classList.add('hidden'); content.classList.remove('hidden');
  loadMyTestBookings();
  const el=document.getElementById('tbDate');
  if(el){const d=new Date();d.setDate(d.getDate()+7);el.min=d.toISOString().split('T')[0];}
}
function updateTestInfo() {
  const val=document.getElementById('tbTestType').value;
  const box=document.getElementById('tbTestInfoBox');
  const info={
    learners_k53:'📋 K53 Theory Test — 68 questions, 30 min. Score 77% to pass. Bring ID + R70 fee.',
    driving_code8:'🚗 Code 8 Driving Test — Yard test + road test. Bring Learner\'s Licence, ID, R130 fee.',
    driving_codeA:'🏍️ Code A Motorcycle Test — Approved safety gear required. Bring Learner\'s Licence, ID, R130 fee.',
    driving_code10:'🚛 Code 10 — Must hold Code 8 first. Vehicle must be roadworthy. ID + Code 8 + R200 fee.',
    driving_code14:'🚚 Code 14 — Must hold Code 10. ID + Code 10 + R200 fee required.',
  };
  if(val&&info[val]){box.textContent=info[val];box.classList.remove('hidden');}else box.classList.add('hidden');
}
function loadTestSlots() {
  const date=document.getElementById('tbDate').value;
  const wrap=document.getElementById('tbSlotsWrapper');
  const grid=document.getElementById('tbSlotsGrid');
  document.getElementById('tbTime').value='';
  if(!date){wrap.style.display='none';return;}
  wrap.style.display='block';
  const slots=['07:00','07:30','08:00','08:30','09:00','09:30','10:00','10:30','11:00','11:30','12:00','12:30','13:00','13:30','14:00','14:30','15:00'];
  grid.innerHTML=slots.map(t=>`<button type="button" class="slot-btn" onclick="selectSlot('${t}',this,'tbTime')">${t}</button>`).join('');
}
function submitTestBooking(e) {
  e.preventDefault();
  const msgEl=document.getElementById('tbMsg'); clearMsg(msgEl);
  const testType=document.getElementById('tbTestType').value;
  const dltc=document.getElementById('tbDLTC').value;
  const date=document.getElementById('tbDate').value;
  const time=document.getElementById('tbTime').value;
  const idNum=document.getElementById('tbIdNumber').value.trim();
  const notes=document.getElementById('tbNotes').value.trim();
  if(!testType){showMsg(msgEl,'Select a test type.','error');return;}
  if(!dltc){showMsg(msgEl,'Select a DLTC centre.','error');return;}
  if(!date){showMsg(msgEl,'Select a date.','error');return;}
  if(!time){showMsg(msgEl,'Select a time slot.','error');return;}
  if(!idNum){showMsg(msgEl,'Enter your ID number.','error');return;}
  const db=getDB();
  const testNames={learners_k53:"Learner's Licence (K53 Theory)",driving_code8:'Driving Test — Code 8',
    driving_codeA:'Driving Test — Code A',driving_code10:'Driving Test — Code 10',driving_code14:'Driving Test — Code 14'};
  const dltcNames={pinetown:'Pinetown DLTC',durban_north:'Durban North DLTC',umlazi:'Umlazi DLTC'};
  if(!db.testBookings) db.testBookings=[];
  const booking={id:'tb_'+Date.now(),user_id:currentUser.id,
    student_name:`${currentUser.first_name} ${currentUser.last_name}`,student_email:currentUser.email,
    test_type:testType,test_name:testNames[testType]||testType,dltc,dltc_name:dltcNames[dltc]||dltc,
    test_date:date,test_time:time,id_number:idNum,notes,status:'pending',
    ref:'UDA-'+Date.now().toString(36).toUpperCase().slice(-8),created_at:new Date().toISOString()};
  db.testBookings.push(booking); saveDB(db);
  showMsg(msgEl,`✅ Reserved! Reference: ${booking.ref}. Confirmation within 2 business days.`,'success');
  e.target.reset();
  document.getElementById('tbSlotsWrapper').style.display='none';
  document.getElementById('tbTestInfoBox').classList.add('hidden');
  toast('Test booking submitted! 🏛️','success'); loadMyTestBookings();
}
function loadMyTestBookings() {
  const el=document.getElementById('myTestBookingsList'); if(!el) return;
  const db=getDB();
  const bookings=(db.testBookings||[]).filter(b=>b.user_id===currentUser?.id)
    .sort((a,b)=>new Date(b.created_at)-new Date(a.created_at));
  if(!bookings.length){el.innerHTML='<p class="text-muted">No official test bookings yet.</p>';return;}
  el.innerHTML=bookings.map(b=>`
    <div class="tbk-item">
      <div class="tbk-hdr"><div class="tbk-type">${b.test_name}</div>
        <span class="badge badge-${b.status==='confirmed'?'confirmed':b.status==='cancelled'?'cancelled':'pending'}">${b.status}</span>
      </div>
      <div class="tbk-meta"><span>🏛️ ${b.dltc_name}</span><span>📅 ${b.test_date} · 🕐 ${b.test_time}</span><span>🔖 ${b.ref}</span></div>
      ${['pending','confirmed'].includes(b.status)?`<div style="margin-top:.5rem"><button class="btn btn-sm btn-red" onclick="cancelTestBooking('${b.id}')">Cancel</button></div>`:''}
    </div>`).join('');
}
function cancelTestBooking(id) {
  if(!confirm('Cancel this test booking?')) return;
  const db=getDB(); if(!db.testBookings) return;
  const bk=db.testBookings.find(b=>b.id===id);
  if(bk){bk.status='cancelled';saveDB(db);} toast('Test booking cancelled.','info'); loadMyTestBookings();
}

// ══════════════════════════════════════════════════
//  UI HELPERS
// ══════════════════════════════════════════════════
function showMsg(el, msg, type) { if(!el) return; el.className=`msg-box msg-${type}`; el.textContent=msg; }
function clearMsg(el) { if(!el) return; el.className='msg-box hidden'; el.textContent=''; }
function toast(msg, type='success') {
  const wrap=document.getElementById('toastWrap');
  const el=document.createElement('div');
  el.className=`toast-item toast-${type}`; el.textContent=msg;
  wrap.appendChild(el); setTimeout(()=>el.remove(),4000);
}

/* ══════════════════════════════════════════════════════════════════
   SMART SEARCH
══════════════════════════════════════════════════════════════════ */

const SS_INDEX = [
  // Courses
  {icon:'📋', title:'Learner\'s Licence Prep', sub:'3 weeks · R 800 (student) / R 1 000 (staff)', tag:'Course', page:'courses', keywords:'learners licence prep k53 theory signs rules r800'},
  {icon:'🚗', title:'Code 8 — Light Motor Vehicle', sub:'25 lessons · R 2 300 (student)', tag:'Course', page:'courses', keywords:'code 8 light motor vehicle car r2300'},
  {icon:'🚛', title:'Code 10 — Heavy Motor Vehicle', sub:'30 lessons · R 2 500 (student)', tag:'Course', page:'courses', keywords:'code 10 heavy truck lorry r2500'},
  {icon:'🏍️', title:'Code A — Motorcycle', sub:'20 lessons · R 2 000 (student)', tag:'Course', page:'courses', keywords:'code a motorcycle bike r2000'},
  {icon:'♿', title:'Disabled Persons Programme', sub:'Specialised adaptive driving training', tag:'Course', page:'courses', keywords:'disabled adaptive special needs'},
  {icon:'🔄', title:'Refresher Course', sub:'10 lessons · R 1 200 (student)', tag:'Course', page:'courses', keywords:'refresher brush up r1200'},
  {icon:'🏢', title:'Corporate/Fleet Training', sub:'Group training for companies', tag:'Course', page:'courses', keywords:'corporate fleet group company'},
  // Pages
  {icon:'📅', title:'Book a Lesson', sub:'Schedule your driving lesson online', tag:'Page', page:'book', keywords:'book lesson schedule appointment'},
  {icon:'👨‍🏫', title:'Instructors', sub:'Meet our expert driving instructors', tag:'Page', page:'instructors', keywords:'instructor teacher trainer staff'},
  {icon:'📚', title:'Study Materials', sub:'K53 road signs, rules, mock tests', tag:'Page', page:'learn', keywords:'study materials signs rules learn k53'},
  {icon:'🖥️', title:'Online Sessions', sub:'Live and recorded learning sessions', tag:'Page', page:'sessions', keywords:'online sessions video live class'},
  {icon:'📝', title:'Mock Test', sub:'Practice your K53 theory test', tag:'Page', page:'mocktest', keywords:'mock test practice exam questions'},
  {icon:'🏛️', title:'Book Official Test', sub:'Schedule your official K53 test', tag:'Page', page:'testbooking', keywords:'official test dltc booking'},
  {icon:'❓', title:'FAQs', sub:'Frequently asked questions', tag:'Page', page:'faq', keywords:'faq help question answer'},
  {icon:'📞', title:'Contact Us', sub:'031 907 7111 · info@unidrive.ac.za', tag:'Page', page:'contact', keywords:'contact phone email address location'},
  // FAQs
  {icon:'💬', title:'What documents do I need to enrol?', sub:'Valid SA ID + student card (if applicable)', tag:'FAQ', page:'faq', keywords:'documents id enrol register'},
  {icon:'💬', title:'How long does it take to get my licence?', sub:'Typically 2–3 months from start to test', tag:'FAQ', page:'faq', keywords:'how long duration time months weeks'},
  {icon:'💬', title:'Do you offer payment plans?', sub:'Deposit + installment options available', tag:'FAQ', page:'faq', keywords:'payment plan installment deposit pay'},
  {icon:'💬', title:'What are your operating hours?', sub:'Mon–Fri 08:00–17:00 · Sat 08:00–13:00', tag:'FAQ', page:'faq', keywords:'hours open time operating'},
  {icon:'💬', title:'Can I reschedule a lesson?', sub:'Yes, 24h notice required via the portal', tag:'FAQ', page:'faq', keywords:'reschedule cancel change lesson'},
  // Pricing
  {icon:'💰', title:'Pricing Overview', sub:'Student & staff rates for all programmes', tag:'Info', page:'courses', keywords:'price cost pricing fee how much'},
  {icon:'📍', title:'Location', sub:'MUT Campus, Durban, 4000', tag:'Info', page:'contact', keywords:'location address where campus mut mangosuthu'},
];

let ssActive = -1;
let ssFiltered = [];

function openSmartSearch() {
  const overlay = document.getElementById('smartSearchOverlay');
  overlay.classList.remove('hidden');
  setTimeout(() => document.getElementById('ssInput').focus(), 50);
  ssActive = -1;
  document.getElementById('ssInput').value = '';
  renderSsResults('');
  document.addEventListener('keydown', ssGlobalKey);
}

function closeSmartSearch(e) {
  if (e && e.target !== document.getElementById('smartSearchOverlay')) return;
  document.getElementById('smartSearchOverlay').classList.add('hidden');
  document.removeEventListener('keydown', ssGlobalKey);
}

function ssGlobalKey(e) {
  if (e.key === 'Escape') { document.getElementById('smartSearchOverlay').classList.add('hidden'); document.removeEventListener('keydown', ssGlobalKey); }
}

function handleSmartSearch() {
  const q = document.getElementById('ssInput').value.trim();
  ssActive = -1;
  renderSsResults(q);
}

function renderSsResults(q) {
  const container = document.getElementById('ssResults');
  const lower = q.toLowerCase();
  if (!q) {
    // Show popular/quick links
    container.innerHTML = `<div class="ss-group-label">Quick Links</div>` +
      SS_INDEX.slice(0, 8).map((item, i) => ssItemHTML(item, i)).join('');
    ssFiltered = SS_INDEX.slice(0, 8);
    return;
  }
  ssFiltered = SS_INDEX.filter(item =>
    item.title.toLowerCase().includes(lower) ||
    item.keywords.includes(lower) ||
    item.sub.toLowerCase().includes(lower) ||
    item.tag.toLowerCase().includes(lower)
  );
  if (!ssFiltered.length) {
    container.innerHTML = `<div class="ss-empty">😕 No results for "<strong>${escHtml(q)}</strong>" — try different keywords</div>`;
    return;
  }
  // Group by tag
  const groups = {};
  ssFiltered.forEach((item, i) => {
    if (!groups[item.tag]) groups[item.tag] = [];
    groups[item.tag].push({item, i});
  });
  container.innerHTML = Object.entries(groups).map(([tag, items]) =>
    `<div class="ss-group-label">${tag}s</div>` +
    items.map(({item, i}) => ssItemHTML(item, i)).join('')
  ).join('');
}

function ssItemHTML(item, i) {
  return `<div class="ss-item" data-idx="${i}" onclick="ssSelect(${i})" onmouseover="ssHover(${i})">
    <div class="ss-item-icon">${item.icon}</div>
    <div class="ss-item-body">
      <div class="ss-item-title">${escHtml(item.title)}</div>
      <div class="ss-item-sub">${escHtml(item.sub)}</div>
    </div>
    <div class="ss-item-tag">${item.tag}</div>
  </div>`;
}

function ssHover(i) { ssActive = i; highlightSsItem(); }

function ssKeyNav(e) {
  if (e.key === 'ArrowDown') { e.preventDefault(); ssActive = Math.min(ssActive + 1, ssFiltered.length - 1); highlightSsItem(); }
  else if (e.key === 'ArrowUp') { e.preventDefault(); ssActive = Math.max(ssActive - 1, 0); highlightSsItem(); }
  else if (e.key === 'Enter' && ssActive >= 0) { ssSelect(ssActive); }
}

function highlightSsItem() {
  document.querySelectorAll('.ss-item').forEach(el => el.classList.remove('ss-active'));
  const el = document.querySelector(`.ss-item[data-idx="${ssActive}"]`);
  if (el) { el.classList.add('ss-active'); el.scrollIntoView({block:'nearest'}); }
}

function ssSelect(i) {
  const item = ssFiltered[i];
  if (!item) return;
  document.getElementById('smartSearchOverlay').classList.add('hidden');
  document.removeEventListener('keydown', ssGlobalKey);
  goto(item.page);
}

function escHtml(s) { return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }


/* ══════════════════════════════════════════════════════════════════
   AI CHATBOT
══════════════════════════════════════════════════════════════════ */

const BOT_KNOWLEDGE = {
  courses: [
    {name:'Learner\'s Licence Prep', duration:'3 weeks', priceStudent:'R 800', priceStaff:'R 1 000', description:'Full K53 theory covering road signs, rules of the road, and 3 practice exams.'},
    {name:'Code 8 — Light Motor', duration:'25 lessons', priceStudent:'R 2 300', priceStaff:'R 2 800', description:'Complete Code 8 licence for cars and light vehicles.'},
    {name:'Code 10 — Heavy Motor', duration:'30 lessons', priceStudent:'R 2 500', priceStaff:'R 3 000', description:'Heavy motor vehicle training for trucks.'},
    {name:'Code A — Motorcycle', duration:'20 lessons', priceStudent:'R 2 000', priceStaff:'R 2 500', description:'Motorcycle licence with full safety gear provided.'},
    {name:'Disabled Persons Programme', duration:'Custom', priceStudent:'Contact us', priceStaff:'Contact us', description:'Adaptive driving training for students with disabilities.'},
    {name:'Refresher Course', duration:'10 lessons', priceStudent:'R 1 200', priceStaff:'R 1 500', description:'Brush up your skills before your test or after a break.'},
    {name:'Corporate/Fleet Training', duration:'Custom', priceStudent:'Custom quote', priceStaff:'Custom quote', description:'Group training for companies and fleets.'},
  ],
  faqs: [
    {q:'What documents do I need?', a:'You need a valid South African ID or passport, and a student/staff card if claiming discounted rates.'},
    {q:'How long does it take?', a:'Typically 2–3 months from enrolment to test day, depending on your chosen programme and availability.'},
    {q:'Do you offer payment plans?', a:'Yes! We offer a deposit + installment structure. Contact us to arrange a plan that suits your budget.'},
    {q:'Can I cancel or reschedule?', a:'Yes, with 24 hours notice via the student portal. Cancellations with less notice may incur a fee.'},
    {q:'Where are you located?', a:'We are based at Mangosuthu University of Technology (MUT), Durban 4000. Lessons happen on and around campus.'},
    {q:'What are your hours?', a:'Monday–Friday 08:00–17:00 and Saturday 08:00–13:00.'},
    {q:'Do I need a learner\'s licence before driving lessons?', a:'Yes, for Code 8, 10 and A you need a valid learner\'s licence first. Our Learner\'s Prep course helps you get it.'},
    {q:'What is the pass rate?', a:'We are proud of our high pass rate thanks to our 25-lesson structured K53 curriculum.'},
  ],
  contact: 'Phone: 031 907 7111 | Email: info@unidrive.ac.za | Address: MUT Campus, Durban, 4000 | Hours: Mon–Fri 08:00–17:00, Sat 08:00–13:00'
};

const CHAT_QUICK_REPLIES = [
  'Course prices 💰',
  'How to book 📅',
  'Do I need a learner\'s? 📋',
  'Contact details 📞',
];

let chatHistory = [];
let chatOpen = false;
let chatTyping = false;
let chatGreeted = false;

function toggleChat() {
  chatOpen = !chatOpen;
  const panel = document.getElementById('chatPanel');
  const fab = document.getElementById('chatFab');
  const fabIcon = fab.querySelector('.chat-fab-icon');
  const fabClose = fab.querySelector('.chat-fab-close');
  const notif = document.getElementById('chatNotif');

  if (chatOpen) {
    panel.classList.remove('hidden');
    fabIcon.classList.add('hidden');
    fabClose.classList.remove('hidden');
    notif.classList.add('hidden');
    if (!chatGreeted) { chatGreeted = true; setTimeout(chatGreet, 300); }
    setTimeout(() => document.getElementById('chatInput').focus(), 200);
  } else {
    panel.classList.add('hidden');
    fabIcon.classList.remove('hidden');
    fabClose.classList.add('hidden');
  }
}

function chatGreet() {
  const db = getDB();
  const name = db.currentUser ? db.users[db.currentUser]?.name?.split(' ')[0] : null;
  const greeting = name ? `Hi ${name}! 👋` : 'Hi there! 👋';
  addBotMessage(`${greeting} I'm the **Uni-Drive Assistant**. I can help you with courses, pricing, booking, and more.\n\nWhat can I help you with today?`);
  showSuggestions(CHAT_QUICK_REPLIES);
}

function addBotMessage(text) {
  const msgs = document.getElementById('chatMessages');
  const div = document.createElement('div');
  div.className = 'chat-msg bot';
  div.innerHTML = `<div class="chat-avatar-sm">🚗</div><div class="chat-bubble">${formatChatText(text)}</div>`;
  msgs.appendChild(div);
  msgs.scrollTop = msgs.scrollHeight;
  chatHistory.push({role:'assistant', content: text});
}

function addUserMessage(text) {
  const msgs = document.getElementById('chatMessages');
  const div = document.createElement('div');
  div.className = 'chat-msg user';
  div.innerHTML = `<div class="chat-bubble">${escHtml(text)}</div>`;
  msgs.appendChild(div);
  msgs.scrollTop = msgs.scrollHeight;
  chatHistory.push({role:'user', content: text});
}

function formatChatText(text) {
  return text
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/\n/g, '<br>')
    .replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a onclick="goto(\'$2\')">$1</a>');
}

function showTyping() {
  const msgs = document.getElementById('chatMessages');
  const div = document.createElement('div');
  div.className = 'chat-msg bot';
  div.id = 'chatTypingBubble';
  div.innerHTML = `<div class="chat-avatar-sm">🚗</div><div class="chat-typing"><span></span><span></span><span></span></div>`;
  msgs.appendChild(div);
  msgs.scrollTop = msgs.scrollHeight;
}

function removeTyping() {
  const el = document.getElementById('chatTypingBubble');
  if (el) el.remove();
}

function showSuggestions(chips) {
  const wrap = document.getElementById('chatSuggestions');
  wrap.innerHTML = chips.map(c => `<button class="chat-chip" onclick="sendChatChip(this,'${escHtml(c)}')">${c}</button>`).join('');
}

function sendChatChip(btn, text) {
  document.getElementById('chatSuggestions').innerHTML = '';
  processChat(text);
}

function chatKeyDown(e) { if (e.key === 'Enter') sendChatMessage(); }

function sendChatMessage() {
  const input = document.getElementById('chatInput');
  const text = input.value.trim();
  if (!text || chatTyping) return;
  input.value = '';
  document.getElementById('chatSuggestions').innerHTML = '';
  processChat(text);
}

function processChat(text) {
  addUserMessage(text);
  chatTyping = true;
  document.getElementById('chatSendBtn').disabled = true;
  showTyping();

  const delay = 600 + Math.random() * 600;
  setTimeout(() => {
    removeTyping();
    chatTyping = false;
    document.getElementById('chatSendBtn').disabled = false;
    const {reply, suggestions} = getBotReply(text);
    addBotMessage(reply);
    if (suggestions && suggestions.length) showSuggestions(suggestions);
  }, delay);
}

function getBotReply(text) {
  const t = text.toLowerCase();

  // Greetings
  if (/^(hi|hello|hey|howzit|good (morning|afternoon|evening))/.test(t)) {
    return {reply: 'Hello! 😊 How can I help you today?', suggestions: CHAT_QUICK_REPLIES};
  }

  // Courses overview
  if (/course|programme|program|what do you offer|what can i learn/.test(t)) {
    const list = BOT_KNOWLEDGE.courses.map(c => `• **${c.name}** — ${c.duration}`).join('\n');
    return {reply: `We offer 7 programmes:\n\n${list}\n\nType a course name for pricing details, or [view all courses](courses).`, suggestions:['Code 8 price 🚗','Learner\'s Licence 📋','Book now 📅']};
  }

  // Price / cost queries
  if (/price|cost|fee|how much|r\d|rand/.test(t)) {
    if (/code\s*8|light motor|car/.test(t)) {
      const c = BOT_KNOWLEDGE.courses[1];
      return {reply:`**${c.name}**\n📅 ${c.duration}\n💰 Student: **${c.priceStudent}**\n💰 Staff: **${c.priceStaff}**\n\n${c.description}`, suggestions:['Book Code 8 📅','Code 10 price 🚛','Code A price 🏍️']};
    }
    if (/code\s*10|heavy|truck|lorry/.test(t)) {
      const c = BOT_KNOWLEDGE.courses[2];
      return {reply:`**${c.name}**\n📅 ${c.duration}\n💰 Student: **${c.priceStudent}**\n💰 Staff: **${c.priceStaff}**`, suggestions:['Book Code 10 📅','All courses 📚']};
    }
    if (/code\s*a|motor.?cycle|bike|motor bike/.test(t)) {
      const c = BOT_KNOWLEDGE.courses[3];
      return {reply:`**${c.name}**\n📅 ${c.duration}\n💰 Student: **${c.priceStudent}**\n💰 Staff: **${c.priceStaff}**`, suggestions:['Book Code A 📅','All courses 📚']};
    }
    if (/learner|k53|theory/.test(t)) {
      const c = BOT_KNOWLEDGE.courses[0];
      return {reply:`**${c.name}**\n📅 ${c.duration}\n💰 Student: **${c.priceStudent}**\n💰 Staff: **${c.priceStaff}**\n\n${c.description}`, suggestions:['Book Learner\'s 📅','Code 8 price 🚗']};
    }
    if (/refresh/.test(t)) {
      const c = BOT_KNOWLEDGE.courses[5];
      return {reply:`**${c.name}**\n📅 ${c.duration}\n💰 Student: **${c.priceStudent}**\n💰 Staff: **${c.priceStaff}**`, suggestions:['Book now 📅','All courses 📚']};
    }
    // Generic pricing list
    const list = BOT_KNOWLEDGE.courses.slice(0,6).map(c => `• **${c.name}**: ${c.priceStudent} (student)`).join('\n');
    return {reply:`Here are our student prices:\n\n${list}\n\nStaff rates are slightly higher. [View full pricing](courses)`, suggestions:['Code 8 price 🚗','Book now 📅']};
  }

  // Booking
  if (/book|schedule|appointment|reserve|enrol|enroll|sign up/.test(t)) {
    return {reply:`You can book a lesson directly through our portal! 📅\n\n1. Log in (or create an account)\n2. Go to **Book a Lesson**\n3. Choose your course, date & time\n4. Pay securely online\n\n[👉 Book a Lesson Now](book)`, suggestions:['Course prices 💰','Contact details 📞']};
  }

  // Location
  if (/where|location|address|campus|find you|directions/.test(t)) {
    return {reply:`📍 We are located at:\n\n**Mangosuthu University of Technology**\nDurban, 4000\n\nWe operate on-campus — no need to travel far! [Contact us](contact) for exact directions.`, suggestions:['Operating hours ⏰','Contact details 📞']};
  }

  // Hours
  if (/hour|time|open|when|operating|schedule/.test(t) && !/how long/.test(t)) {
    return {reply:`🕐 **Operating Hours:**\n• Monday–Friday: **08:00–17:00**\n• Saturday: **08:00–13:00**\n• Sunday: Closed\n\n[📞 Contact us](contact) if you need to arrange an out-of-hours lesson.`, suggestions:['Book a lesson 📅','Contact details 📞']};
  }

  // Contact
  if (/contact|phone|call|email|number|reach/.test(t)) {
    return {reply:`📞 **Contact Uni-Drive Academy:**\n• Phone: **031 907 7111**\n• Email: **info@unidrive.ac.za**\n• Hours: Mon–Fri 08:00–17:00 · Sat 08:00–13:00\n\n[Open Contact Page](contact)`, suggestions:['Location 📍','Book a lesson 📅']};
  }

  // Learner's licence requirement
  if (/learner.?s|k53|need.*licence|require/.test(t)) {
    return {reply:`📋 **Learner's Licence:**\n\nYes, you need a valid learner's licence before starting Code 8, 10, or A driving lessons.\n\nOur **Learner's Licence Prep** course (3 weeks, R 800) will prepare you for the K53 theory test. [Book it here](book).`, suggestions:['Learner\'s price 💰','Book Learner\'s 📅']};
  }

  // Documents
  if (/document|id|passport|what.*bring|need.*enrol/.test(t)) {
    const faq = BOT_KNOWLEDGE.faqs[0];
    return {reply:`📄 **Documents needed to enrol:**\n\n${faq.a}\n\nFor the test day, also bring your booking confirmation and proof of payment.`, suggestions:['Book now 📅','FAQs ❓']};
  }

  // Duration
  if (/how long|duration|time.*take|when.*finish/.test(t)) {
    return {reply:`⏱️ **Typical timelines:**\n• Learner's Prep: 3 weeks\n• Code 8 (car): ~2–3 months\n• Code 10 (truck): ~3 months\n• Code A (bike): ~2 months\n\nThis depends on lesson frequency and your personal progress.`, suggestions:['Course prices 💰','Book now 📅']};
  }

  // Payment plan
  if (/payment|installment|pay.*installment|deposit|plan/.test(t)) {
    return {reply:`💳 **Payment Options:**\n\nYes, we offer flexible payment plans! You can pay a deposit upfront and the remainder in installments.\n\n[📞 Contact us](contact) to arrange a plan that works for you.`, suggestions:['Contact details 📞','Course prices 💰']};
  }

  // Cancel/reschedule
  if (/cancel|reschedule|change.*lesson|postpone/.test(t)) {
    return {reply:`🔄 **Cancellation & Rescheduling:**\n\nYou can cancel or reschedule any lesson via the student portal with **24 hours notice**. Cancellations with less notice may incur a fee.\n\nLog in and go to **My Dashboard** to manage your bookings.`, suggestions:['Book a lesson 📅','Contact details 📞']};
  }

  // Instructors
  if (/instructor|teacher|trainer|who teach/.test(t)) {
    return {reply:`👨‍🏫 We have 3 certified instructors with years of K53 experience.\n\n[Meet our instructors](instructors) to see their profiles and specialisations.`, suggestions:['Book a lesson 📅','Course prices 💰']};
  }

  // Study materials / mock test
  if (/study|material|practice|mock|test|sign|road sign/.test(t)) {
    return {reply:`📚 **Study Resources:**\n\n• **Study Materials** — K53 road signs, rules, and guides\n• **Mock Tests** — timed practice K53 exams\n• **Online Sessions** — live and recorded classes\n\n[📖 Study Materials](learn) · [📝 Mock Test](mocktest)`, suggestions:['Book Learner\'s 📅','Online sessions 🖥️']};
  }

  // Disabled / accessibility
  if (/disabled|disability|adaptive|wheelchair|special need/.test(t)) {
    return {reply:`♿ **Disabled Persons Programme:**\n\nWe specifically cater for students with disabilities with our adaptive driving training. Everyone deserves the freedom of a driver's licence.\n\n[📞 Contact us](contact) to discuss your specific needs and arrange training.`, suggestions:['Contact details 📞','Book a lesson 📅']};
  }

  // Pass rate
  if (/pass rate|success|pass.*test/.test(t)) {
    return {reply:`🏆 Our students enjoy a **high first-time pass rate** thanks to our structured 25-lesson K53 curriculum and expert instructors.\n\nPreparation is key — our mock tests and study materials give you the best chance of success!`, suggestions:['Mock test 📝','Book now 📅']};
  }

  // Thanks / bye
  if (/thank|thanks|cheers|bye|goodbye|great|awesome/.test(t)) {
    return {reply:`You're welcome! 😊 Good luck with your driving journey — we look forward to seeing you on the road! 🚗`, suggestions: CHAT_QUICK_REPLIES};
  }

  // Fallback
  return {reply:`I'm not sure about that specific question, but I'm happy to help with:\n\n• **Courses & pricing**\n• **How to book a lesson**\n• **Learner's licence info**\n• **Contact & location**\n\nOr feel free to [visit our FAQ page](faq) for more detailed answers. 😊`, suggestions: CHAT_QUICK_REPLIES};
}

// Keyboard shortcut: Ctrl+K or Cmd+K to open search
document.addEventListener('keydown', function(e) {
  if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
    e.preventDefault();
    openSmartSearch();
  }
});

// ══════════════════════════════════════════════════
//  VEHICLES — Fleet Management (Admin)
// ══════════════════════════════════════════════════

const SEED_VEHICLES = [
  { id:'v1', make:'Hyundai', model:'i20', year:2023, reg:'GP 78 90 IJ', colour:'Red', transmission:'Automatic', licence:'Learners', status:'Available', km:12400, last_service:'2026-05-01', next_service:'2026-11-01', notes:'Used for learners theory + yard test prep.' },
  { id:'v2', make:'Nissan', model:'NP200', year:2019, reg:'GP 45 67 GH', colour:'Blue', transmission:'Manual', licence:'Code 10', status:'Available', km:98700, last_service:'2026-02-20', next_service:'2026-08-20', notes:'Backup heavy vehicle for Code 10.' },
  { id:'v3', make:'Toyota', model:'Corolla', year:2021, reg:'GP 12 34 AB', colour:'White', transmission:'Manual', licence:'Code 8', status:'Available', km:45200, last_service:'2026-03-01', next_service:'2026-09-01', notes:'Main Code 8 training vehicle. Good condition.' },
  { id:'v4', make:'Toyota', model:'Corolla', year:2020, reg:'GP 11 22 KL', colour:'Grey', transmission:'Automatic', licence:'Refresher', status:'Available', km:67500, last_service:'2026-01-10', next_service:'2026-07-10', notes:'Automatic for refresher and elderly students.' },
  { id:'v5', make:'Volkswagen', model:'Polo', year:2022, reg:'GP 56 78 CD', colour:'Silver', transmission:'Manual', licence:'Code 8', status:'Available', km:31000, last_service:'2026-04-15', next_service:'2026-10-15', notes:'Second Code 8 vehicle.' },
  { id:'v6', make:'Toyota', model:'Hilux', year:2020, reg:'GP 91 23 EF', colour:'White', transmission:'Manual', licence:'Code 10', status:'Maintenance', km:112000, last_service:'2025-12-01', next_service:'2026-06-01', notes:'Under scheduled maintenance.' },
];

const SEED_TRIPS = [
  { id:'t1', date:'2026-06-20', vehicle_id:'v3', instructor:'Mr. Dlamini', student:'Thabo Mokoena', distance:34, duration:60, notes:'Parallel parking practice' },
  { id:'t2', date:'2026-06-21', vehicle_id:'v1', instructor:'Ms. Naidoo', student:'Naledi Sithole', distance:12, duration:45, notes:'Yard manoeuvres' },
  { id:'t3', date:'2026-06-22', vehicle_id:'v5', instructor:'Mr. Dlamini', student:'Sipho Khumalo', distance:28, duration:55, notes:'Open road — N3 route' },
  { id:'t4', date:'2026-06-19', vehicle_id:'v4', instructor:'Ms. Naidoo', student:'Zanele Dube', distance:18, duration:50, notes:'Refresher — highway driving' },
];

function getVehicles() {
  const db = getDB();
  if (!db.vehicles || db.vehicles.length === 0) { db.vehicles = SEED_VEHICLES; saveDB(db); }
  if (!db.trips || db.trips.length === 0) { db.trips = SEED_TRIPS; saveDB(db); }
  return db;
}

let _allVehicles = [];
let _allTrips = [];

function loadAdminVehicles() {
  const db = getVehicles();
  _allVehicles = db.vehicles;
  _allTrips = db.trips;
  renderFleetKpis();
  renderFleet();
  renderLiveTracking();
  renderTripHistory();
}

function renderFleetKpis() {
  const total = _allVehicles.length;
  const avail = _allVehicles.filter(v=>v.status==='Available').length;
  const onRoad = _allVehicles.filter(v=>v.status==='On Road').length;
  const maint = _allVehicles.filter(v=>v.status==='Maintenance').length;
  const today = new Date();
  const serviceSoon = _allVehicles.filter(v=>{
    if(!v.next_service) return false;
    const d = new Date(v.next_service);
    const diff = (d - today) / 86400000;
    return diff >= 0 && diff <= 60;
  }).length;
  const el = document.getElementById('fleetKpis');
  if(!el) return;
  el.innerHTML = `
    <div class="stat-card sc-blue"><div class="sc-num">${total}</div><div class="sc-lbl">Total Fleet</div></div>
    <div class="stat-card sc-green"><div class="sc-num">${avail}</div><div class="sc-lbl">Available</div></div>
    <div class="stat-card sc-dark"><div class="sc-num">${onRoad}</div><div class="sc-lbl">Out on Road</div></div>
    <div class="stat-card sc-gold"><div class="sc-num">${maint}</div><div class="sc-lbl">Maintenance</div></div>
    <div class="stat-card" style="border-color:#dc2626;"><div class="sc-num" style="color:#dc2626;">${serviceSoon}</div><div class="sc-lbl">Service Due Soon</div></div>`;
}

function renderFleet() {
  const search = (document.getElementById('vehicleSearch')||{value:''}).value.toLowerCase();
  const statusF = (document.getElementById('vehicleStatusFilter')||{value:''}).value;
  const licenceF = (document.getElementById('vehicleLicenceFilter')||{value:''}).value;
  const grid = document.getElementById('fleetGrid');
  if(!grid) return;
  const today = new Date();
  let filtered = _allVehicles.filter(v=>{
    const text = `${v.make} ${v.model} ${v.reg} ${v.colour}`.toLowerCase();
    if(search && !text.includes(search)) return false;
    if(statusF && v.status !== statusF) return false;
    if(licenceF && v.licence !== licenceF) return false;
    return true;
  });
  if(!filtered.length){ grid.innerHTML='<p style="color:#888;padding:2rem;">No vehicles match the filter.</p>'; return; }
  grid.innerHTML = filtered.map(v=>{
    const daysToService = v.next_service ? Math.round((new Date(v.next_service)-today)/86400000) : null;
    const serviceWarn = daysToService !== null && daysToService <= 60;
    const statusColor = v.status==='Available'?'#16a34a':v.status==='On Road'?'#2563eb':'#d97706';
    const statusBg = v.status==='Available'?'#dcfce7':v.status==='On Road'?'#dbeafe':'#fef9c3';
    return `
    <div class="card" style="position:relative;overflow:hidden;">
      <div style="position:absolute;top:.7rem;right:.7rem;background:${statusBg};color:${statusColor};font-size:11px;font-weight:600;padding:2px 10px;border-radius:20px;">${v.status}</div>
      <div class="card-body">
        <div style="text-align:center;padding:.5rem 0 1rem;font-size:2.5rem;">🚗</div>
        <strong style="font-size:1rem;">${v.year} ${v.make} ${v.model}</strong>
        <div style="font-size:12px;color:#888;margin:.2rem 0 .7rem;">⚡ ${v.reg} · ${v.colour}</div>
        <span style="background:#e0e7ff;color:#3730a3;font-size:11px;font-weight:600;padding:2px 9px;border-radius:20px;">${v.licence}</span>
        ${serviceWarn?`<div style="background:#fef9c3;border:1px solid #fde68a;border-radius:6px;padding:.4rem .7rem;margin:.7rem 0;font-size:12px;color:#92400e;">⚠️ Service in ${daysToService} days</div>`:''}
        <div style="margin-top:.7rem;font-size:12.5px;color:#555;display:flex;flex-wrap:wrap;gap:.3rem .8rem;">
          <span>⚙ ${v.transmission}</span>
          <span>📍 ${v.km.toLocaleString()} km</span>
          ${v.last_service?`<span>🔧 Last: ${v.last_service}</span>`:''}
          ${v.next_service?`<span>📅 Next: ${v.next_service}</span>`:''}
        </div>
        ${v.notes?`<p style="font-size:12px;color:#888;margin:.6rem 0 .8rem;line-height:1.5;">${v.notes}</p>`:''}
        <div style="display:flex;gap:.5rem;margin-top:.5rem;">
          <button class="btn btn-primary" style="flex:1;font-size:13px;" onclick="dispatchVehicle('${v.id}')">🛣️ Dispatch</button>
          <button class="btn btn-ghost btn-sm" onclick="editVehicle('${v.id}')">✏️</button>
          <button class="btn btn-ghost btn-sm" onclick="deleteVehicle('${v.id}')" style="color:#dc2626;">🗑</button>
        </div>
      </div>
    </div>`;
  }).join('');
}

function renderLiveTracking() {
  const el = document.getElementById('liveTrackingList');
  if(!el) return;
  const onRoad = _allVehicles.filter(v=>v.status==='On Road');
  if(!onRoad.length){
    el.innerHTML = `<div style="text-align:center;padding:3rem;color:#888;">
      <div style="font-size:3rem;margin-bottom:1rem;">🗺️</div>
      <h3>No vehicles currently on road</h3>
      <p>Dispatch a vehicle from the Fleet tab to see live tracking here.</p>
    </div>`;
    return;
  }
  el.innerHTML = onRoad.map(v=>`
    <div class="card" style="margin-bottom:1rem;">
      <div class="card-body" style="display:flex;align-items:center;gap:1.5rem;flex-wrap:wrap;">
        <div style="font-size:2.5rem;">🚗</div>
        <div style="flex:1;min-width:200px;">
          <strong>${v.year} ${v.make} ${v.model}</strong>
          <div style="color:#888;font-size:12.5px;">${v.reg} · ${v.licence}</div>
        </div>
        <div style="text-align:center;">
          <div style="font-size:1.5rem;">📍</div>
          <div style="font-size:12px;color:#2563eb;font-weight:600;">Live · Durban, KZN</div>
        </div>
        <button class="btn btn-ghost btn-sm" onclick="returnVehicle('${v.id}')">✅ Return to Base</button>
      </div>
    </div>`).join('');
}

function renderTripHistory() {
  const tbody = document.getElementById('tripHistoryBody');
  if(!tbody) return;
  const sorted = [..._allTrips].sort((a,b)=>b.date.localeCompare(a.date));
  tbody.innerHTML = sorted.map(t=>{
    const v = _allVehicles.find(x=>x.id===t.vehicle_id)||{};
    return `<tr>
      <td>${t.date}</td>
      <td>${v.year||''} ${v.make||''} ${v.model||''}<br><small style="color:#888;">${v.reg||''}</small></td>
      <td>${t.instructor}</td>
      <td>${t.student}</td>
      <td>${t.distance} km</td>
      <td>${t.duration} min</td>
      <td style="font-size:12px;color:#888;">${t.notes||''}</td>
    </tr>`;
  }).join('');
}

function vehicleSubTab(name, btn) {
  document.querySelectorAll('.vtab-btn').forEach(b=>{
    b.style.color='#888';b.style.borderBottom='none';b.style.background='none';
  });
  btn.style.color='var(--primary,#1a3557)';btn.style.borderBottom='2px solid var(--primary,#1a3557)';
  ['fleet','tracking','trips'].forEach(t=>{
    const el=document.getElementById('vtab-'+t);
    if(el) el.style.display = t===name?'block':'none';
  });
}

function dispatchVehicle(id) {
  const db = getDB();
  const v = db.vehicles.find(x=>x.id===id);
  if(v){ v.status='On Road'; saveDB(db); _allVehicles=db.vehicles; renderFleet(); renderFleetKpis(); renderLiveTracking(); toast(`${v.make} ${v.model} dispatched.`,'success'); }
}

function returnVehicle(id) {
  const db = getDB();
  const v = db.vehicles.find(x=>x.id===id);
  if(v){ v.status='Available'; saveDB(db); _allVehicles=db.vehicles; renderFleet(); renderFleetKpis(); renderLiveTracking(); toast(`${v.make} ${v.model} returned.`,'success'); }
}

function deleteVehicle(id) {
  if(!confirm('Delete this vehicle?')) return;
  const db = getDB();
  db.vehicles = db.vehicles.filter(v=>v.id!==id);
  saveDB(db); _allVehicles=db.vehicles; renderFleet(); renderFleetKpis(); toast('Vehicle removed.','info');
}

function editVehicle(id) {
  const db = getDB();
  const v = db.vehicles.find(x=>x.id===id);
  if(!v) return;
  const notes = prompt('Edit notes for ' + v.make + ' ' + v.model + ':', v.notes||'');
  if(notes===null) return;
  v.notes=notes; saveDB(db); _allVehicles=db.vehicles; renderFleet(); toast('Updated.','success');
}

function openAddVehicleModal() {
  const make  = prompt('Make (e.g. Toyota):');  if(!make) return;
  const model = prompt('Model (e.g. Corolla):'); if(!model) return;
  const year  = prompt('Year (e.g. 2024):');
  const reg   = prompt('Registration (e.g. GP 00 00 AA):');
  const licence = prompt('Licence type (Learners / Code 8 / Code 10 / Code A / Refresher):') || 'Code 8';
  const db = getDB();
  const newV = {
    id:'v'+Date.now(), make, model, year:parseInt(year)||2024, reg:reg||'', colour:'White',
    transmission:'Manual', licence, status:'Available', km:0,
    last_service:'', next_service:'', notes:''
  };
  db.vehicles.push(newV); saveDB(db); _allVehicles=db.vehicles;
  renderFleet(); renderFleetKpis(); toast(`${make} ${model} added to fleet!`,'success');
}

// ══════════════════════════════════════════════════
//  AI INSIGHTS (Admin)
// ══════════════════════════════════════════════════

let _aiPredictions = [];

function loadAdminAI() {
  const db = getDB();
  const bookings = db.bookings || [];
  const users = db.users || [];

  // Build per-student stats from bookings
  const studentUsers = users.filter(u=>u.role==='student');
  _aiPredictions = studentUsers.map(u=>{
    const mine = bookings.filter(b=>b.user_id===u.id);
    const completed = mine.filter(b=>b.status==='completed').length;
    const pending = mine.filter(b=>b.status==='pending').length;
    const confirmed = mine.filter(b=>b.status==='confirmed').length;
    const total = mine.length;
    const lastBk = mine.sort((a,b)=>b.created_at?.localeCompare(a.created_at||'')||0)[0];
    const daysSince = lastBk ? Math.floor((Date.now()-new Date(lastBk.created_at||Date.now()).getTime())/86400000) : 999;

    // Readiness score
    const courseTargets = {'learners':5,'code8':10,'codeA':10,'code10':15,'code14':15,'adaptive':8};
    const target = courseTargets[lastBk?.course_id] || 10;
    const progress = Math.min(1, completed/target);
    const attRate = total>0 ? (completed/total) : 0;
    const recency = daysSince<=7?1:daysSince<=21?0.6:daysSince<=45?0.3:0.1;
    const readiness = Math.round(Math.max(0,Math.min(100,(progress*0.6+attRate*0.3+recency*0.1)*100)));
    const passProb = Math.round(Math.min(95,Math.max(5,readiness*0.9+(attRate*100*0.1))));

    let status,statusColor;
    if(readiness>=80){status='Ready';statusColor='#16a34a';}
    else if(readiness>=55){status='Nearly Ready';statusColor='#2563eb';}
    else if(readiness>=30){status='In Progress';statusColor='#d97706';}
    else{status='Needs More Training';statusColor='#dc2626';}

    // Risk score
    let risk=0;
    if(daysSince>30) risk+=40; else if(daysSince>14) risk+=20; else if(daysSince>7) risk+=8;
    if(total>0&&attRate<0.6) risk+=25; else if(total>0&&attRate<0.8) risk+=10;
    if(pending>0) risk+=15;
    if(total===0) risk+=25;
    risk=Math.min(100,risk);
    let riskLevel,riskColor;
    if(risk>=50){riskLevel='High Risk';riskColor='#dc2626';}
    else if(risk>=20){riskLevel='Medium Risk';riskColor='#d97706';}
    else{riskLevel='Low Risk';riskColor='#16a34a';}

    // Recommendation
    let rec = '';
    if(daysSince>21&&total>0) rec=`Hasn't booked in ${daysSince} days — reach out.`;
    else if(risk>=50) rec='High dropout risk — proactive outreach recommended.';
    else if(readiness>=80) rec='Test-ready — suggest official test booking.';
    else if(readiness>=55) rec='Good progress — a few more lessons recommended.';
    else if(total===0) rec='No bookings yet — schedule introductory lesson.';
    else rec='Steady progress — continue current lesson plan.';

    return { u, total, completed, pending, confirmed, readiness, status, statusColor, passProb, risk, riskLevel, riskColor, rec, daysSince, attRate:Math.round(attRate*100) };
  });

  renderAIInsightBox();
  renderAIBiLayers();
  renderAIKpis();
  renderAIRevenueChart();
  renderAIAttendanceChart();
  renderAIReadinessDist();
  renderAIRiskDist();
  renderAITable();
}

function renderAIInsightBox() {
  const db = getDB();
  const bookings = db.bookings||[];
  const payments = db.payments||[];
  const lines = [];
  const confirmed = bookings.filter(b=>b.status==='confirmed'||b.status==='completed').length;
  const pending = bookings.filter(b=>b.status==='pending').length;
  const highRisk = _aiPredictions.filter(p=>p.riskLevel==='High Risk').length;
  const ready = _aiPredictions.filter(p=>p.status==='Ready').length;
  lines.push(`${confirmed} confirmed/completed bookings across ${db.users?.filter(u=>u.role==='student').length||0} students.`);
  if(pending>0) lines.push(`${pending} booking(s) are awaiting confirmation — review in the Bookings tab.`);
  if(highRisk>0) lines.push(`${highRisk} student(s) flagged as High Dropout Risk — proactive outreach recommended.`);
  if(ready>0) lines.push(`${ready} student(s) are test-ready — consider scheduling official tests.`);
  const inactive = _aiPredictions.filter(p=>p.daysSince>14&&p.total>0).length;
  if(inactive>0) lines.push(`${inactive} student(s) have not booked a lesson in over 14 days.`);
  const ul = document.getElementById('aiInsightList');
  if(ul) ul.innerHTML = lines.map(l=>`<li>${l}</li>`).join('');
}

function renderAIBiLayers() {
  const el = document.getElementById('aiBiLayers');
  if(!el) return;
  const db = getDB();
  const bookings = db.bookings||[];
  const ready = _aiPredictions.filter(p=>p.status==='Ready').length;
  const nearly = _aiPredictions.filter(p=>p.status==='Nearly Ready').length;
  const highRisk = _aiPredictions.filter(p=>p.riskLevel==='High Risk').length;
  const total = bookings.length;
  const comp = bookings.filter(b=>b.status==='completed').length;
  const pend = bookings.filter(b=>b.status==='pending').length;
  el.innerHTML = `
    <div class="card" style="border-top:4px solid #2563eb;">
      <div class="card-body">
        <div style="font-size:11px;font-weight:700;letter-spacing:.5px;color:#2563eb;margin-bottom:.6rem;">📊 WHAT HAPPENED — Historical</div>
        <div style="font-size:13px;line-height:1.8;">
          <strong>Total bookings:</strong> ${total}<br>
          <strong>Completed lessons:</strong> ${comp}<br>
          <strong>Pending bookings:</strong> ${pend}<br>
          <strong>Students analysed:</strong> ${_aiPredictions.length}
        </div>
      </div>
    </div>
    <div class="card" style="border-top:4px solid #d97706;">
      <div class="card-body">
        <div style="font-size:11px;font-weight:700;letter-spacing:.5px;color:#d97706;margin-bottom:.6rem;">🔍 WHY IT HAPPENED — Analytical</div>
        <div style="font-size:13px;line-height:1.8;">
          ${highRisk>0?`<strong>${highRisk} high-risk student(s)</strong> — extended gaps or pending payments driving dropout risk.<br>`:''}
          ${pend>0?`<strong>${pend} pending booking(s)</strong> — may need admin confirmation to avoid student frustration.<br>`:''}
          ${comp<total?`<strong>${total-comp} bookings</strong> not yet completed — track progress to maximise completion rate.`:'All bookings completed — excellent!'}
        </div>
      </div>
    </div>
    <div class="card" style="border-top:4px solid #16a34a;">
      <div class="card-body">
        <div style="font-size:11px;font-weight:700;letter-spacing:.5px;color:#16a34a;margin-bottom:.6rem;">🔮 WHAT IS LIKELY NEXT — Predictive</div>
        <div style="font-size:13px;line-height:1.8;">
          ${ready>0?`<strong>${ready} student(s) are test-ready</strong> — expect official test bookings soon.<br>`:''}
          ${nearly>0?`<strong>${nearly} student(s) nearly ready</strong> — likely to be test-ready within 2-4 weeks.<br>`:''}
          ${highRisk>0?`<strong>${highRisk} at dropout risk</strong> — outreach in next 7 days recommended.`:'Dropout risk is low — keep up the good work!'}
        </div>
      </div>
    </div>`;
}

function renderAIKpis() {
  const el = document.getElementById('aiKpis');
  if(!el) return;
  const ready  = _aiPredictions.filter(p=>p.status==='Ready').length;
  const nearly = _aiPredictions.filter(p=>p.status==='Nearly Ready').length;
  const highR  = _aiPredictions.filter(p=>p.riskLevel==='High Risk').length;
  el.innerHTML = `
    <div class="stat-card sc-green"><div class="sc-num">${ready}</div><div class="sc-lbl">✅ Ready for Test</div></div>
    <div class="stat-card sc-blue"><div class="sc-num">${nearly}</div><div class="sc-lbl">⏱️ Nearly Ready</div></div>
    <div class="stat-card" style="border-color:#dc2626;"><div class="sc-num" style="color:#dc2626;">${highR}</div><div class="sc-lbl">⚠️ High Dropout Risk</div></div>
    <div class="stat-card sc-dark"><div class="sc-num">${_aiPredictions.length}</div><div class="sc-lbl">🤖 Analysed</div></div>`;
}

function renderAIRevenueChart() {
  const el = document.getElementById('aiRevenueChart');
  if(!el) return;
  const db = getDB();
  const bookings = db.bookings||[];
  // Count bookings per month (last 6)
  const months = [];
  for(let i=5;i>=0;i--){
    const d = new Date(); d.setMonth(d.getMonth()-i);
    const label = d.toLocaleString('default',{month:'short'});
    const yr = d.getFullYear(); const mo = String(d.getMonth()+1).padStart(2,'0');
    const count = bookings.filter(b=>(b.created_at||'').startsWith(`${yr}-${mo}`)).length;
    months.push({label,count});
  }
  const maxC = Math.max(1,...months.map(m=>m.count));
  el.innerHTML = `<div style="font-weight:600;font-size:13.5px;margin-bottom:1rem;">📊 Bookings per Month</div>
    <div style="display:flex;align-items:flex-end;gap:.8rem;height:120px;padding:0 .5rem;">
      ${months.map((m,i)=>{
        const h=Math.max(6,Math.round((m.count/maxC)*100));
        return `<div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:.3rem;">
          <span style="font-size:11px;font-weight:600;color:${i===5?'var(--primary,#1a3557)':'#888'};">${m.count}</span>
          <div style="width:100%;height:${h}px;border-radius:4px 4px 0 0;background:${i===5?'linear-gradient(180deg,#38bdf8,#0ea5e9)':'#e2e8f0'};"></div>
          <span style="font-size:11px;color:#888;">${m.label}</span>
        </div>`;
      }).join('')}
    </div>`;
}

function renderAIAttendanceChart() {
  const el = document.getElementById('aiAttendanceChart');
  if(!el) return;
  // Completion rate breakdown
  const db = getDB();
  const bookings = db.bookings||[];
  const groups = {Completed:0,Confirmed:0,Pending:0,Cancelled:0};
  bookings.forEach(b=>{ const k=b.status.charAt(0).toUpperCase()+b.status.slice(1); if(k in groups) groups[k]++; });
  const total = bookings.length||1;
  const colors = {Completed:'#16a34a',Confirmed:'#2563eb',Pending:'#d97706',Cancelled:'#dc2626'};
  el.innerHTML = `<div style="font-weight:600;font-size:13.5px;margin-bottom:1rem;">📈 Booking Status Breakdown</div>
    ${Object.entries(groups).map(([k,v])=>`
      <div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:.3rem;"><span>${k}</span><strong>${v}</strong></div>
      <div style="background:#f1f5f9;border-radius:6px;height:8px;margin-bottom:.8rem;overflow:hidden;">
        <div style="height:100%;width:${Math.round(v/total*100)}%;background:${colors[k]};border-radius:6px;"></div>
      </div>`).join('')}`;
}

function renderAIReadinessDist() {
  const el = document.getElementById('aiReadinessDist');
  if(!el) return;
  const counts = {'Ready':0,'Nearly Ready':0,'In Progress':0,'Needs More Training':0};
  _aiPredictions.forEach(p=>{if(p.status in counts) counts[p.status]++;});
  const colors = {'Ready':'#16a34a','Nearly Ready':'#2563eb','In Progress':'#d97706','Needs More Training':'#dc2626'};
  const max = Math.max(1,...Object.values(counts));
  el.innerHTML = `<div style="font-weight:600;font-size:13.5px;margin-bottom:1rem;">📋 Test Readiness Distribution</div>
    ${Object.entries(counts).map(([k,v])=>`
      <div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:.3rem;"><span>${k}</span><strong>${v}</strong></div>
      <div style="background:#f1f5f9;border-radius:6px;height:8px;margin-bottom:.8rem;overflow:hidden;">
        <div style="height:100%;width:${Math.round(v/max*100)}%;background:${colors[k]};border-radius:6px;"></div>
      </div>`).join('')}`;
}

function renderAIRiskDist() {
  const el = document.getElementById('aiRiskDist');
  if(!el) return;
  const counts = {'Low Risk':0,'Medium Risk':0,'High Risk':0};
  _aiPredictions.forEach(p=>{if(p.riskLevel in counts) counts[p.riskLevel]++;});
  const colors = {'Low Risk':'#16a34a','Medium Risk':'#d97706','High Risk':'#dc2626'};
  const max = Math.max(1,...Object.values(counts));
  el.innerHTML = `<div style="font-weight:600;font-size:13.5px;margin-bottom:1rem;">⚠️ Dropout Risk Distribution</div>
    ${Object.entries(counts).map(([k,v])=>`
      <div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:.3rem;"><span>${k}</span><strong>${v}</strong></div>
      <div style="background:#f1f5f9;border-radius:6px;height:8px;margin-bottom:.8rem;overflow:hidden;">
        <div style="height:100%;width:${Math.round(v/max*100)}%;background:${colors[k]};border-radius:6px;"></div>
      </div>`).join('')}`;
}

function renderAITable() {
  const tbody = document.getElementById('aiStudentBody');
  if(!tbody) return;
  const search = (document.getElementById('aiStudentSearch')||{value:''}).value.toLowerCase();
  const rf = (document.getElementById('aiReadinessFilter')||{value:''}).value;
  const rkf = (document.getElementById('aiRiskFilter')||{value:''}).value;
  const filtered = _aiPredictions.filter(p=>{
    const name = `${p.u.first_name} ${p.u.last_name}`.toLowerCase();
    if(search && !name.includes(search)) return false;
    if(rf && p.status!==rf) return false;
    if(rkf && p.riskLevel!==rkf) return false;
    return true;
  });
  if(!filtered.length){ tbody.innerHTML='<tr><td colspan="7" style="text-align:center;padding:2rem;color:#888;">No students match the selected filters.</td></tr>'; return; }
  tbody.innerHTML = filtered.map(p=>{
    const initials = (p.u.first_name[0]+p.u.last_name[0]).toUpperCase();
    const readPillBg = {'#16a34a':'#dcfce7','#2563eb':'#dbeafe','#d97706':'#fef9c3','#dc2626':'#fee2e2'}[p.statusColor]||'#f1f5f9';
    const riskPillBg = {'#16a34a':'#dcfce7','#d97706':'#fef9c3','#dc2626':'#fee2e2'}[p.riskColor]||'#f1f5f9';
    return `<tr>
      <td>
        <div style="display:flex;align-items:center;gap:.5rem;">
          <div style="width:30px;height:30px;border-radius:50%;background:var(--primary,#1a3557);color:#fff;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;flex-shrink:0;">${initials}</div>
          <span>${p.u.first_name} ${p.u.last_name}</span>
        </div>
      </td>
      <td style="font-size:12px;color:#888;">${p.u.student_number||'—'}</td>
      <td>
        <strong style="color:${p.statusColor};">${p.readiness}%</strong>
        <div style="background:#f1f5f9;border-radius:4px;height:5px;width:70px;margin-top:3px;overflow:hidden;display:inline-block;vertical-align:middle;margin-left:5px;">
          <div style="height:100%;width:${p.readiness}%;background:${p.statusColor};border-radius:4px;"></div>
        </div>
      </td>
      <td><span style="background:${readPillBg};color:${p.statusColor};font-size:11.5px;font-weight:500;padding:2px 10px;border-radius:20px;">● ${p.status}</span></td>
      <td>${p.passProb}%</td>
      <td><span style="background:${riskPillBg};color:${p.riskColor};font-size:11.5px;font-weight:500;padding:2px 10px;border-radius:20px;">${p.riskLevel}</span></td>
      <td style="font-size:12px;color:#888;max-width:200px;">${p.rec}</td>
    </tr>`;
  }).join('');
}

// ══════════════════════════════════════════════════
//  MY READINESS (Customer Dashboard)
// ══════════════════════════════════════════════════

function loadMyReadiness() {
  if(!currentUser) return;
  const db = getDB();
  const mine = (db.bookings||[]).filter(b=>b.user_id===currentUser.id);
  const completed = mine.filter(b=>b.status==='completed').length;
  const total = mine.length;
  const lastBk = mine.sort((a,b)=>(b.created_at||'').localeCompare(a.created_at||''))[0];
  const courseTargets = {'learners':5,'code8':10,'codeA':10,'code10':15,'code14':15,'adaptive':8};
  const target = courseTargets[lastBk?.course_id] || 10;
  const progress = Math.min(1, completed/target);
  const attRate = total>0 ? completed/total : 0;
  const daysSince = lastBk ? Math.floor((Date.now()-new Date(lastBk.created_at||Date.now()).getTime())/86400000) : null;
  const recency = daysSince===null?0.1:daysSince<=7?1:daysSince<=21?0.6:daysSince<=45?0.3:0.1;
  const readiness = Math.round(Math.max(0,Math.min(100,(progress*0.6+attRate*0.3+recency*0.1)*100)));
  const passProb = Math.round(Math.min(95,Math.max(5,readiness*0.9+(attRate*100*0.1))));
  const lessonsLeft = Math.max(0,target-completed);

  let status,color,emoji;
  if(readiness>=80){status='Ready for Test';color='#16a34a';emoji='🎉';}
  else if(readiness>=55){status='Nearly Ready';color='#2563eb';emoji='💪';}
  else if(readiness>=30){status='In Progress';color='#d97706';emoji='📈';}
  else{status='Needs More Training';color='#dc2626';emoji='🚦';}

  // Pace estimate
  let predictedDate = null;
  if(lessonsLeft===0){ predictedDate='You\'ve hit your target!'; }
  else if(total>0) {
    const pace = Math.max(0.5, completed/Math.max(1,(Date.now()-new Date(lastBk?.created_at||Date.now()).getTime())/604800000));
    const weeksNeeded = Math.ceil(lessonsLeft/pace);
    const d = new Date(); d.setDate(d.getDate()+weeksNeeded*7);
    predictedDate = d.toLocaleDateString('en-ZA',{day:'numeric',month:'short',year:'numeric'});
  }

  // Study plan
  const studyPlan = [];
  if(daysSince!==null&&daysSince>14) studyPlan.push({icon:'📜',title:'Refresh Rules of the Road',reason:`It's been ${daysSince} days since your last booking — a quick refresher on right-of-way will help.`,tab:'signs'});
  if(completed<target) studyPlan.push({icon:'🚦',title:'Road Signs Practice',reason:`Complete ${lessonsLeft} more lesson(s) to reach your ${target}-lesson target for your current course.`,tab:'learn'});
  if(readiness>=80) studyPlan.push({icon:'✅',title:'Final Pre-Test Review',reason:'You\'re test-ready! Do one final review before booking your official test.',tab:'learn'});
  if(studyPlan.length===0) studyPlan.push({icon:'📚',title:'Study Materials',reason:'Keep your knowledge sharp — review study materials regularly.',tab:'learn'});

  // Tips
  const tips = [];
  if(readiness<30){ tips.push('Aim for at least 1-2 bookings per week to build momentum.'); tips.push('Review study materials before each lesson to make practical time count.'); }
  else if(readiness<55){ tips.push('Keep your lesson pace consistent to reach test-readiness sooner.'); tips.push('Ask your instructor for feedback on areas you find challenging.'); }
  else if(readiness<80){ tips.push('You\'re close! A few more lessons will push you to test-ready.'); tips.push('Practice mock K53 questions from the Study Materials section.'); }
  else { tips.push('You\'re test-ready! Talk to admin about booking your official test.'); tips.push('Do a final review of road signs and rules the night before your test.'); }

  // Circumference for gauge
  const circ = 2*Math.PI*90;
  const offset = circ*(1-readiness/100);

  const el = document.getElementById('readinessContent');
  if(!el) return;
  el.innerHTML = `
    <div style="display:grid;grid-template-columns:1fr 1.5fr;gap:1.5rem;align-items:start;" class="readiness-main-grid">
      <!-- Gauge -->
      <div class="card">
        <div class="card-body" style="text-align:center;">
          <div style="font-weight:600;font-size:14px;margin-bottom:.5rem;">Test Readiness Score</div>
          <div style="position:relative;width:200px;height:200px;margin:0 auto 1rem;">
            <svg width="200" height="200" viewBox="0 0 200 200" style="transform:rotate(-90deg)">
              <circle cx="100" cy="100" r="90" fill="none" stroke="#f1f5f9" stroke-width="13"/>
              <circle cx="100" cy="100" r="90" fill="none" stroke="${color}" stroke-width="13" stroke-linecap="round"
                stroke-dasharray="${circ}" stroke-dashoffset="${offset}"/>
            </svg>
            <div style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;">
              <div style="font-size:2.8rem;font-weight:800;color:${color};line-height:1;">${readiness}%</div>
              <div style="font-size:11px;color:#888;letter-spacing:.4px;margin-top:.2rem;">READINESS</div>
            </div>
          </div>
          <div style="display:inline-flex;align-items:center;gap:6px;padding:5px 16px;border-radius:20px;font-size:13px;font-weight:600;background:${color}22;color:${color};margin-bottom:1rem;">${emoji} ${status}</div>
          <div style="text-align:left;margin-top:.5rem;">
            <div style="display:flex;justify-content:space-between;padding:.55rem 0;border-bottom:1px solid #f1f5f9;font-size:13.5px;"><span>Pass Probability</span><strong>${passProb}%</strong></div>
            <div style="display:flex;justify-content:space-between;padding:.55rem 0;border-bottom:1px solid #f1f5f9;font-size:13.5px;"><span>Lessons Completed</span><strong>${completed} / ${target}</strong></div>
            <div style="display:flex;justify-content:space-between;padding:.55rem 0;border-bottom:1px solid #f1f5f9;font-size:13.5px;"><span>Completion Rate</span><strong>${Math.round(attRate*100)}%</strong></div>
            <div style="display:flex;justify-content:space-between;padding:.55rem 0;font-size:13.5px;"><span>Last Booking</span><strong>${daysSince===null?'No bookings yet':daysSince===0?'Today':daysSince+' days ago'}</strong></div>
          </div>
        </div>
      </div>

      <div>
        <!-- Test Day Predictor -->
        <div style="background:linear-gradient(135deg,#1a3557,#1a2636);color:#fff;border-radius:12px;padding:1.5rem;text-align:center;margin-bottom:1.2rem;">
          <div style="font-size:11px;color:rgba(255,255,255,.5);letter-spacing:.4px;margin-bottom:.4rem;">🔮 TEST DAY PREDICTOR</div>
          ${lessonsLeft===0
            ? `<div style="font-size:1.3rem;font-weight:700;color:#fbbf24;">You've hit your lesson target!</div>
               <div style="font-size:12px;color:rgba(255,255,255,.6);margin-top:.4rem;">Talk to admin about booking your official test.</div>`
            : predictedDate
              ? `<div style="font-size:1.6rem;font-weight:700;color:#fbbf24;">~${predictedDate}</div>
                 <div style="font-size:12px;color:rgba(255,255,255,.6);margin-top:.4rem;">Estimated based on your booking pace — ${lessonsLeft} lesson(s) remaining.</div>`
              : `<div style="font-size:1.2rem;font-weight:700;color:#fbbf24;">Not enough data yet</div>
                 <div style="font-size:12px;color:rgba(255,255,255,.6);margin-top:.4rem;">Book ${lessonsLeft} more lesson(s) to reach the ${target}-lesson target.</div>`}
        </div>

        <!-- Study Plan -->
        <div class="card" style="margin-bottom:1.2rem;">
          <div class="card-body">
            <div style="font-weight:600;font-size:13.5px;margin-bottom:1rem;">📚 Smart Study Plan — Personalized for You</div>
            ${studyPlan.slice(0,3).map(item=>`
              <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:1rem;margin-bottom:.8rem;display:flex;gap:.9rem;align-items:flex-start;transition:border-color .2s;" onmouseover="this.style.borderColor='#dc2626'" onmouseout="this.style.borderColor='#e2e8f0'">
                <div style="width:40px;height:40px;border-radius:10px;background:#fff;border:1px solid #e2e8f0;display:flex;align-items:center;justify-content:center;font-size:1.2rem;flex-shrink:0;">${item.icon}</div>
                <div>
                  <div style="font-weight:600;font-size:13.5px;margin-bottom:.25rem;">${item.title}</div>
                  <div style="font-size:12.5px;color:#888;line-height:1.5;margin-bottom:.5rem;">${item.reason}</div>
                  <button class="btn btn-primary btn-sm" style="font-size:12px;" onclick="goto('${item.tab}')">Open →</button>
                </div>
              </div>`).join('')}
          </div>
        </div>

        <!-- Tips -->
        <div class="card">
          <div class="card-body">
            <div style="font-weight:600;font-size:13.5px;margin-bottom:.8rem;">💡 Personalized Tips</div>
            <ul style="list-style:none;padding:0;margin:0;">
              ${tips.map(t=>`<li style="display:flex;gap:.6rem;padding:.6rem 0;border-bottom:1px solid #f1f5f9;font-size:13px;align-items:flex-start;"><span style="color:#16a34a;flex-shrink:0;">✓</span><span>${t}</span></li>`).join('')}
            </ul>
          </div>
        </div>
      </div>
    </div>
    <style>@media(max-width:700px){.readiness-main-grid{grid-template-columns:1fr!important;}}</style>`;
}
