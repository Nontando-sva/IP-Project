# 🚗 Uni-Drive Academy — Standalone Website

A fully functional, standalone frontend for the Uni-Drive Academy driving school web app.
No server or Node.js required to preview — open directly in a browser.

---

## 📁 File Structure

```
uni-drive-academy/
├── index.html          ← Main SPA (Single Page Application)
├── css/
│   └── style.css       ← All styles (responsive, modern)
└── js/
    └── app.js          ← All JavaScript logic + localStorage database
```

---

## 🚀 How to Open in VS Code

### Option 1 — Live Server (Recommended)
1. Install the **Live Server** extension in VS Code
2. Right-click `index.html` → **"Open with Live Server"**
3. Browser opens automatically at `http://127.0.0.1:5500`

### Option 2 — Direct Browser
1. Double-click `index.html` to open in your default browser

---

## 🔑 Demo Login Accounts

| Role    | Email                    | Password    |
|---------|--------------------------|-------------|
| Admin   | admin@unidrive.ac.za     | admin123    |
| Student | thabo@mut.ac.za          | student123  |
| Staff   | naledi@mut.ac.za         | staff123    |

> **Tip:** Click any demo account row on the login page to auto-fill credentials.

---

## 📄 Pages

| Page          | URL / Route  | Description                          |
|---------------|-------------|--------------------------------------|
| Home          | `#home`      | Landing page with hero, courses, testimonials |
| Courses       | `#courses`   | All 6 programmes with pricing        |
| Instructors   | `#instructors` | Instructor profiles                |
| Book a Lesson | `#book`      | Booking form (login required)        |
| FAQ           | `#faq`       | Accordion + live search              |
| Contact       | `#contact`   | Enquiry form                         |
| Login         | `#login`     | Authentication                       |
| Register      | `#register`  | Account creation                     |
| Dashboard     | `#dashboard` | Customer portal (student/staff)      |
| Admin         | `#admin`     | Admin panel                          |

---

## 🎛️ Dashboard Features

### Customer Dashboard (Student / Staff)
- **Overview** — Stats cards + recent bookings + quick actions
- **My Bookings** — View and cancel bookings
- **New Booking** — Book a lesson with time slot picker
- **Profile** — Edit personal info + change password
- **Write Review** — Star rating + review submission

### Admin Dashboard
- **Dashboard** — System stats (users, bookings, revenue) + recent activity table
- **Bookings** — Full booking table with confirm / cancel / complete actions + search
- **Users** — All registered users with activate/deactivate controls + search
- **Enquiries** — Contact form submissions with mark-as-read
- **Reviews** — Approve or delete student testimonials

---

## 💾 Data Storage

All data is stored in your browser's **localStorage** under the key `unidrive_db`.
Data persists between page refreshes. To reset to default seed data:
```javascript
localStorage.removeItem('unidrive_db');
// Then refresh the page
```

---

## 🔗 Connecting to Your Node.js Backend

When your Express server is running, replace the localStorage functions in `js/app.js`
with the existing `api()` fetch calls from the original `app.js` (included in your ZIP).

The API endpoints expected are:
- `POST /api/auth/login` — Login
- `POST /api/auth/register` — Register
- `GET  /api/auth/me` — Current user
- `POST /api/auth/logout` — Logout
- `GET  /api/bookings` — List bookings
- `POST /api/bookings` — Create booking
- `DELETE /api/bookings/:id` — Cancel booking
- `GET  /api/admin/stats` — Admin statistics
- `GET  /api/admin/users` — All users
- etc.

---

## 🎓 Academic Context

**Subject:** Internet Programming 2 (ITNP300/ITPR300)  
**Institution:** Mangosuthu University of Technology  
**Lecturer:** Mr X Piyose  
**Due Date:** 2 June 2026
