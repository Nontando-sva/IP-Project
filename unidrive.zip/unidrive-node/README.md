# 🚗 Uni-Drive Academy — Node.js / Express / JSON

MUT Campus Driving School Management Portal

## Tech Stack

| Layer    | Technology |
|----------|------------|
| Backend  | Node.js + Express |
| Database | JSON file (`data/db.json`) |
| Auth     | JWT (jsonwebtoken) + bcryptjs |
| Frontend | Plain HTML + CSS + Vanilla JS |
| Editor   | Visual Studio Code |

---

## Project Structure

```
unidrive-academy/
├── server/
│   ├── index.js              ← Express app entry point
│   ├── db.js                 ← JSON database read/write helper
│   ├── middleware.js         ← JWT auth middleware
│   └── routes/
│       ├── auth.js           ← POST /api/auth/login, /register
│       ├── users.js          ← GET/PATCH /api/users
│       ├── courses.js        ← GET /api/courses
│       ├── bookings.js       ← CRUD /api/bookings
│       ├── payments.js       ← CRUD /api/payments
│       ├── enquiries.js      ← CRUD /api/enquiries
│       ├── testimonials.js   ← CRUD /api/testimonials
│       ├── vehicles.js       ← CRUD /api/vehicles + /trips
│       ├── mocktest.js       ← /api/mocktest results
│       ├── sessions.js       ← /api/sessions/progress
│       ├── test_bookings.js  ← /api/test-bookings
│       └── admin.js          ← /api/admin/stats
├── data/
│   └── db.json               ← JSON database (all data stored here)
├── public/
│   ├── index.html            ← Home page (root)
│   ├── css/
│   │   └── style.css
│   ├── js/
│   │   ├── api.js            ← Frontend API client
│   │   ├── shared.js         ← Navbar, auth state, toasts, helpers
│   │   └── vehicles-ai.js    ← Fleet & AI Insights logic
│   └── pages/
│       ├── login.html
│       ├── register.html
│       ├── courses.html
│       ├── book.html
│       ├── payment.html
│       ├── pay-success.html
│       ├── dashboard.html
│       ├── admin.html
│       ├── contact.html
│       ├── faq.html
│       ├── learn.html
│       ├── sessions.html
│       ├── mocktest.html
│       ├── testbooking.html
│       └── instructors.html
└── package.json
```

---

## Setup & Run

### 1. Install dependencies
```bash
npm install
```

### 2. Start the server
```bash
# Normal start
npm start

# Development (auto-restarts on file change)
npm run dev
```

### 3. Open in browser
```
http://localhost:3000
```

---

## Demo Accounts

| Role    | Email                    | Password     |
|---------|--------------------------|--------------|
| Admin   | admin@unidrive.ac.za     | Admin@1234   |
| Student | thabo@mut.ac.za          | Student@1234 |
| Staff   | naledi@mut.ac.za         | Staff@1234   |

> Passwords are hashed with bcryptjs. The seed hash above matches `password`.

---

## API Endpoints

| Method | Endpoint                        | Auth     | Description |
|--------|---------------------------------|----------|-------------|
| POST   | `/api/auth/register`            | Public   | Create account |
| POST   | `/api/auth/login`               | Public   | Login, get JWT |
| PATCH  | `/api/auth/password`            | User     | Change password |
| GET    | `/api/users/me`                 | User     | Get own profile |
| GET    | `/api/users`                    | Admin    | All users |
| PATCH  | `/api/users/me`                 | User     | Update profile |
| PATCH  | `/api/users/:id/status`         | Admin    | Activate/deactivate |
| GET    | `/api/courses`                  | Public   | All courses |
| GET    | `/api/courses/:id`              | Public   | Single course |
| GET    | `/api/bookings/mine`            | User     | My bookings |
| GET    | `/api/bookings`                 | Admin    | All bookings |
| POST   | `/api/bookings`                 | User     | New booking |
| PATCH  | `/api/bookings/:id/status`      | User/Admin | Update status |
| POST   | `/api/payments`                 | User     | Pay for booking |
| GET    | `/api/payments/mine`            | User     | My payment history |
| POST   | `/api/enquiries`                | Public   | Submit contact form |
| GET    | `/api/enquiries`                | Admin    | All enquiries |
| PATCH  | `/api/enquiries/:id/status`     | Admin    | Resolve enquiry |
| GET    | `/api/testimonials`             | Public   | Approved reviews |
| POST   | `/api/testimonials`             | User     | Submit review |
| PATCH  | `/api/testimonials/:id/approve` | Admin    | Approve/reject |
| GET    | `/api/vehicles`                 | User     | Fleet list |
| POST   | `/api/vehicles`                 | Admin    | Add vehicle |
| PATCH  | `/api/vehicles/:id`             | Admin    | Update vehicle |
| DELETE | `/api/vehicles/:id`             | Admin    | Remove vehicle |
| GET    | `/api/vehicles/trips`           | Admin    | Trip history |
| POST   | `/api/vehicles/trips`           | Admin    | Log trip |
| GET    | `/api/mocktest/mine`            | User     | My test results |
| POST   | `/api/mocktest`                 | User     | Save test result |
| GET    | `/api/sessions/progress`        | User     | Watched sessions |
| POST   | `/api/sessions/progress`        | User     | Mark session watched |
| GET    | `/api/test-bookings/mine`       | User     | My DLTC bookings |
| POST   | `/api/test-bookings`            | User     | Book DLTC test |
| GET    | `/api/admin/stats`              | Admin    | Dashboard stats |

---

## VS Code Tips

- Install the **REST Client** extension to test API endpoints directly in VS Code
- Install **Nodemon** globally for auto-reload: `npm install -g nodemon`
- The database file `data/db.json` updates in real-time — you can watch it change as you use the app
