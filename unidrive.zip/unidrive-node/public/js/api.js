// public/js/api.js — Uni-Drive Academy API Client
// Talks to the Express/JSON backend instead of Supabase
'use strict';

const BASE = '/api';

// ── Token helpers ──────────────────────────────────────────────────────────
function getToken() { return localStorage.getItem('uda_token'); }
function setToken(t) { localStorage.setItem('uda_token', t); }
function clearToken() { localStorage.removeItem('uda_token'); localStorage.removeItem('uda_user'); }

function authHeaders() {
  const t = getToken();
  return { 'Content-Type': 'application/json', ...(t ? { Authorization: 'Bearer ' + t } : {}) };
}

async function apiFetch(method, path, body) {
  const res = await fetch(BASE + path, {
    method,
    headers: authHeaders(),
    ...(body !== undefined ? { body: JSON.stringify(body) } : {})
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

// ══════════════════════════════════════════════════
//  AUTH
// ══════════════════════════════════════════════════
async function api_register(payload) {
  const data = await apiFetch('POST', '/auth/register', payload);
  return data.user;
}

async function api_login({ email, password }) {
  const data = await apiFetch('POST', '/auth/login', { email, password });
  setToken(data.token);
  localStorage.setItem('uda_user', JSON.stringify(data.user));
  return data;
}

function api_logout() {
  clearToken();
}

function api_getSession() {
  const raw = localStorage.getItem('uda_user');
  return raw ? JSON.parse(raw) : null;
}

async function api_updatePassword(newPassword) {
  return apiFetch('PATCH', '/auth/password', { new_password: newPassword });
}

// ══════════════════════════════════════════════════
//  PROFILES
// ══════════════════════════════════════════════════
async function api_getProfile() {
  const user = await apiFetch('GET', '/users/me');
  localStorage.setItem('uda_user', JSON.stringify(user));
  return user;
}

async function api_getAllProfiles() {
  return apiFetch('GET', '/users');
}

async function api_updateProfile(updates) {
  const user = await apiFetch('PATCH', '/users/me', updates);
  localStorage.setItem('uda_user', JSON.stringify(user));
  return user;
}

async function api_toggleUserActive(userId, isActive) {
  return apiFetch('PATCH', `/users/${userId}/status`, { is_active: isActive });
}

// ══════════════════════════════════════════════════
//  COURSES
// ══════════════════════════════════════════════════
async function api_getCourses() { return apiFetch('GET', '/courses'); }
async function api_getCourse(id) { return apiFetch('GET', `/courses/${id}`); }

// ══════════════════════════════════════════════════
//  BOOKINGS
// ══════════════════════════════════════════════════
async function api_getMyBookings()    { return apiFetch('GET', '/bookings/mine'); }
async function api_getAllBookings()   { return apiFetch('GET', '/bookings'); }
async function api_createBooking(b)  { return apiFetch('POST', '/bookings', b); }
async function api_updateBookingStatus(id, status) {
  return apiFetch('PATCH', `/bookings/${id}/status`, { status });
}

// ══════════════════════════════════════════════════
//  PAYMENTS
// ══════════════════════════════════════════════════
async function api_createPayment(p) { return apiFetch('POST', '/payments', p); }
async function api_getMyPayments()  { return apiFetch('GET', '/payments/mine'); }

// ══════════════════════════════════════════════════
//  ENQUIRIES
// ══════════════════════════════════════════════════
async function api_submitEnquiry(e)      { return apiFetch('POST', '/enquiries', e); }
async function api_getAllEnquiries()     { return apiFetch('GET', '/enquiries'); }
async function api_updateEnquiryStatus(id, status) {
  return apiFetch('PATCH', `/enquiries/${id}/status`, { status });
}

// ══════════════════════════════════════════════════
//  TESTIMONIALS
// ══════════════════════════════════════════════════
async function api_getApprovedTestimonials() { return apiFetch('GET', '/testimonials'); }
async function api_getAllTestimonials()      { return apiFetch('GET', '/testimonials/all'); }
async function api_submitTestimonial(t)      { return apiFetch('POST', '/testimonials', t); }
async function api_approveTestimonial(id, is_approved) {
  return apiFetch('PATCH', `/testimonials/${id}/approve`, { is_approved });
}

// ══════════════════════════════════════════════════
//  VEHICLES + TRIPS
// ══════════════════════════════════════════════════
async function api_getVehicles()    { return apiFetch('GET',  '/vehicles'); }
async function api_addVehicle(v)    { return apiFetch('POST', '/vehicles', v); }
async function api_updateVehicle(id, updates) { return apiFetch('PATCH', `/vehicles/${id}`, updates); }
async function api_deleteVehicle(id){ return apiFetch('DELETE', `/vehicles/${id}`); }
async function api_getTrips()       { return apiFetch('GET',  '/vehicles/trips'); }
async function api_logTrip(t)       { return apiFetch('POST', '/vehicles/trips', t); }

// ══════════════════════════════════════════════════
//  MOCK TEST
// ══════════════════════════════════════════════════
async function api_getMyTestResults()  { return apiFetch('GET', '/mocktest/mine'); }
async function api_saveTestResult(r)   { return apiFetch('POST', '/mocktest', r); }
async function api_getAllTestResults() { return apiFetch('GET', '/mocktest/all'); }

// ══════════════════════════════════════════════════
//  SESSION PROGRESS
// ══════════════════════════════════════════════════
async function api_getSessionProgress()  { return apiFetch('GET', '/sessions/progress'); }
async function api_markSessionWatched(session_id, session_title) {
  return apiFetch('POST', '/sessions/progress', { session_id, session_title });
}

// ══════════════════════════════════════════════════
//  OFFICIAL TEST BOOKINGS
// ══════════════════════════════════════════════════
async function api_createTestBooking(t) { return apiFetch('POST', '/test-bookings', t); }
async function api_getMyTestBookings()  { return apiFetch('GET', '/test-bookings/mine'); }

// ══════════════════════════════════════════════════
//  ADMIN STATS
// ══════════════════════════════════════════════════
async function api_getAdminStats() { return apiFetch('GET', '/admin/stats'); }

// ══════════════════════════════════════════════════
//  EXPORT
// ══════════════════════════════════════════════════
window.UniDriveAPI = {
  // Auth
  register:             api_register,
  login:                api_login,
  logout:               api_logout,
  getSession:           api_getSession,
  updatePassword:       api_updatePassword,
  // Profiles
  getProfile:           api_getProfile,
  getAllProfiles:        api_getAllProfiles,
  updateProfile:        api_updateProfile,
  toggleUserActive:     api_toggleUserActive,
  // Courses
  getCourses:           api_getCourses,
  getCourse:            api_getCourse,
  // Bookings
  getMyBookings:        api_getMyBookings,
  getAllBookings:        api_getAllBookings,
  createBooking:        api_createBooking,
  updateBookingStatus:  api_updateBookingStatus,
  // Payments
  createPayment:        api_createPayment,
  getMyPayments:        api_getMyPayments,
  // Enquiries
  submitEnquiry:        api_submitEnquiry,
  getAllEnquiries:       api_getAllEnquiries,
  updateEnquiryStatus:  api_updateEnquiryStatus,
  // Testimonials
  getApprovedTestimonials: api_getApprovedTestimonials,
  getAllTestimonials:       api_getAllTestimonials,
  submitTestimonial:       api_submitTestimonial,
  approveTestimonial:      api_approveTestimonial,
  // Vehicles
  getVehicles:          api_getVehicles,
  addVehicle:           api_addVehicle,
  updateVehicle:        api_updateVehicle,
  deleteVehicle:        api_deleteVehicle,
  getTrips:             api_getTrips,
  logTrip:              api_logTrip,
  // Mock Test
  getMyTestResults:     api_getMyTestResults,
  saveTestResult:       api_saveTestResult,
  getAllTestResults:     api_getAllTestResults,
  // Sessions
  getSessionProgress:   api_getSessionProgress,
  markSessionWatched:   api_markSessionWatched,
  // Test Bookings
  createTestBooking:    api_createTestBooking,
  getMyTestBookings:    api_getMyTestBookings,
  // Admin
  getAdminStats:        api_getAdminStats,
};
