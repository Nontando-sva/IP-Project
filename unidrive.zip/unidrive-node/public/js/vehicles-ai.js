// js/vehicles-ai.js — Fleet Management + AI Insights + My Readiness
// Included on dashboard.html and admin.html
'use strict';

// ══════════════════════════════════════════════════
//  FLEET MANAGEMENT (Admin)
// ══════════════════════════════════════════════════
const SEED_VEHICLES = [
  { id:'v1', make:'Hyundai', model:'i20', year:2023, reg:'GP 78 90 IJ', colour:'Red', transmission:'Automatic', licence:'Learners', status:'Available', km:12400, last_service:'2026-05-01', next_service:'2026-11-01', notes:'Used for learners theory + yard test prep.' },
  { id:'v2', make:'Nissan', model:'NP200', year:2019, reg:'GP 45 67 GH', colour:'Blue', transmission:'Manual', licence:'Code 10', status:'Available', km:98700, last_service:'2026-02-20', next_service:'2026-08-20', notes:'Backup heavy vehicle for Code 10.' },
  { id:'v3', make:'Toyota', model:'Corolla', year:2021, reg:'GP 12 34 AB', colour:'White', transmission:'Manual', licence:'Code 8', status:'Available', km:45200, last_service:'2026-03-01', next_service:'2026-09-01', notes:'Main Code 8 training vehicle. Good condition.' },
  { id:'v4', make:'Toyota', model:'Corolla', year:2020, reg:'GP 11 22 KL', colour:'Grey', transmission:'Automatic', licence:'Refresher', status:'Available', km:67500, last_service:'2026-01-10', next_service:'2026-07-10', notes:'Automatic for refresher and elderly students.' },
  { id:'v5', make:'Volkswagen', model:'Polo', year:2022, reg:'GP 56 78 CD', colour:'Silver', transmission:'Manual', licence:'Code 8', status:'Available', km:31000, last_service:'2026-04-15', next_service:'2026-10-15', notes:'Second Code 8 vehicle.' },
  { id:'v6', make:'Toyota', model:'Hilux', year:2020, reg:'GP 91 23 EF', colour:'White', transmission:'Manual', licence:'Code 10', status:'Maintenance', km:112000, last_service:'2025-12-01', next_service:'2026-06-01', notes:'Under scheduled maintenance.' },
];
const SEED_TRIPS = [
  { id:'t1', date:'2026-06-20', vehicle_id:'v3', instructor:'Mr. Mkhize', student:'Thabo Mokoena', distance:34, duration:60, notes:'Parallel parking practice' },
  { id:'t2', date:'2026-06-21', vehicle_id:'v1', instructor:'Ms. Zulu', student:'Naledi Sithole', distance:12, duration:45, notes:'Yard manoeuvres' },
  { id:'t3', date:'2026-06-22', vehicle_id:'v5', instructor:'Mr. Mkhize', student:'Sipho Khumalo', distance:28, duration:55, notes:'Open road — N3 route' },
  { id:'t4', date:'2026-06-19', vehicle_id:'v4', instructor:'Ms. Zulu', student:'Zanele Dube', distance:18, duration:50, notes:'Refresher — highway driving' },
];

let _allVehicles = [];
let _allTrips    = [];

async function loadAdminVehicles() {
  _allVehicles = SEED_VEHICLES;
  _allTrips = SEED_TRIPS.map(t => ({ ...t, vehicles: SEED_VEHICLES.find(v => v.id === t.vehicle_id) }));
  renderFleetKpis();
  renderFleet();
  renderLiveTracking();
  renderTripHistory();
}

function renderFleetKpis() {
  const el = document.getElementById('fleetKpis'); if(!el) return;
  const today = new Date();
  const avail  = _allVehicles.filter(v=>v.status==='Available').length;
  const onRoad = _allVehicles.filter(v=>v.status==='On Road').length;
  const maint  = _allVehicles.filter(v=>v.status==='Maintenance').length;
  const soon   = _allVehicles.filter(v=>{ if(!v.next_service) return false; const diff=(new Date(v.next_service)-today)/86400000; return diff>=0&&diff<=60; }).length;
  el.innerHTML = `
    <div class="stat-card sc-blue"><div class="sc-num">${_allVehicles.length}</div><div class="sc-lbl">Total Fleet</div></div>
    <div class="stat-card sc-green"><div class="sc-num">${avail}</div><div class="sc-lbl">Available</div></div>
    <div class="stat-card sc-dark"><div class="sc-num">${onRoad}</div><div class="sc-lbl">Out on Road</div></div>
    <div class="stat-card sc-gold"><div class="sc-num">${maint}</div><div class="sc-lbl">Maintenance</div></div>
    <div class="stat-card" style="border-color:#dc2626"><div class="sc-num" style="color:#dc2626">${soon}</div><div class="sc-lbl">Service Due Soon</div></div>`;
}

function renderFleet() {
  const search  = (document.getElementById('vehicleSearch')||{value:''}).value.toLowerCase();
  const statusF = (document.getElementById('vehicleStatusFilter')||{value:''}).value;
  const licF    = (document.getElementById('vehicleLicenceFilter')||{value:''}).value;
  const grid    = document.getElementById('fleetGrid'); if(!grid) return;
  const today   = new Date();
  const filtered = _allVehicles.filter(v=>{
    const text = `${v.make} ${v.model} ${v.reg} ${v.colour}`.toLowerCase();
    if(search && !text.includes(search)) return false;
    if(statusF && v.status!==statusF) return false;
    if(licF   && v.licence!==licF)    return false;
    return true;
  });
  if(!filtered.length){ grid.innerHTML='<p class="text-muted" style="padding:2rem">No vehicles match the filter.</p>'; return; }
  grid.innerHTML = filtered.map(v=>{
    const days = v.next_service ? Math.round((new Date(v.next_service)-today)/86400000) : null;
    const warn = days!==null && days<=60;
    const sc = v.status==='Available'?'#16a34a':v.status==='On Road'?'#2563eb':'#d97706';
    const sb = v.status==='Available'?'#dcfce7':v.status==='On Road'?'#dbeafe':'#fef9c3';
    return `
      <div class="card" style="position:relative;overflow:hidden">
        <div style="position:absolute;top:.7rem;right:.7rem;background:${sb};color:${sc};font-size:11px;font-weight:600;padding:2px 10px;border-radius:20px">${v.status}</div>
        <div class="card-body">
          <div style="text-align:center;padding:.5rem 0 1rem;font-size:2.5rem">🚗</div>
          <strong>${v.year} ${v.make} ${v.model}</strong>
          <div style="font-size:12px;color:#888;margin:.2rem 0 .7rem">⚡ ${v.reg} · ${v.colour}</div>
          <span style="background:#e0e7ff;color:#3730a3;font-size:11px;font-weight:600;padding:2px 9px;border-radius:20px">${v.licence}</span>
          ${warn?`<div style="background:#fef9c3;border:1px solid #fde68a;border-radius:6px;padding:.4rem .7rem;margin:.7rem 0;font-size:12px;color:#92400e">⚠️ Service in ${days} days</div>`:''}
          <div style="margin-top:.7rem;font-size:12.5px;color:#555;display:flex;flex-wrap:wrap;gap:.3rem .8rem">
            <span>⚙ ${v.transmission}</span>
            <span>📍 ${v.km.toLocaleString()} km</span>
            ${v.next_service?`<span>📅 Next: ${v.next_service}</span>`:''}
          </div>
          ${v.notes?`<p style="font-size:12px;color:#888;margin:.6rem 0 .8rem;line-height:1.5">${v.notes}</p>`:''}
          <div style="display:flex;gap:.5rem;margin-top:.5rem">
            <button class="btn btn-primary" style="flex:1;font-size:13px" onclick="dispatchVehicle('${v.id}')">🛣️ Dispatch</button>
            <button class="btn btn-ghost btn-sm" onclick="editVehicleNotes('${v.id}')">✏️</button>
            <button class="btn btn-ghost btn-sm" onclick="deleteVehicle('${v.id}')" style="color:#dc2626">🗑</button>
          </div>
        </div>
      </div>`;
  }).join('');
}

function renderLiveTracking() {
  const el = document.getElementById('liveTrackingList'); if(!el) return;
  const onRoad = _allVehicles.filter(v=>v.status==='On Road');
  if(!onRoad.length){
    el.innerHTML=`<div style="text-align:center;padding:3rem;color:#888"><div style="font-size:3rem;margin-bottom:1rem">🗺️</div><h3>No vehicles currently on road</h3><p>Dispatch a vehicle from the Fleet tab.</p></div>`;
    return;
  }
  el.innerHTML = onRoad.map(v=>`
    <div class="card" style="margin-bottom:1rem">
      <div class="card-body" style="display:flex;align-items:center;gap:1.5rem;flex-wrap:wrap">
        <div style="font-size:2.5rem">🚗</div>
        <div style="flex:1;min-width:200px">
          <strong>${v.year} ${v.make} ${v.model}</strong>
          <div style="color:#888;font-size:12.5px">${v.reg} · ${v.licence}</div>
        </div>
        <div style="text-align:center">
          <div style="font-size:1.5rem">📍</div>
          <div style="font-size:12px;color:#2563eb;font-weight:600">Live · Durban, KZN</div>
        </div>
        <button class="btn btn-ghost btn-sm" onclick="returnVehicle('${v.id}')">✅ Return to Base</button>
      </div>
    </div>`).join('');
}

function renderTripHistory() {
  const tbody = document.getElementById('tripHistoryBody'); if(!tbody) return;
  const sorted = [..._allTrips].sort((a,b)=>(b.trip_date||'').localeCompare(a.trip_date||''));
  tbody.innerHTML = sorted.map(t=>{
    const v = t.vehicles || _allVehicles.find(x=>x.id===t.vehicle_id) || {};
    return `<tr>
      <td>${t.trip_date}</td>
      <td>${v.year||''} ${v.make||''} ${v.model||''}<br><small style="color:#888">${v.reg||''}</small></td>
      <td>${t.instructor_name||'—'}</td>
      <td>${t.student_name||'—'}</td>
      <td>${t.distance_km} km</td>
      <td>${t.duration_min} min</td>
      <td style="font-size:12px;color:#888">${t.notes||''}</td>
    </tr>`;
  }).join('');
}

function vehicleSubTab(name, btn) {
  document.querySelectorAll('.vtab-btn').forEach(b=>{ b.style.color='#888'; b.style.borderBottom='none'; });
  btn.style.color='var(--primary,#1a3557)'; btn.style.borderBottom='2px solid var(--primary,#1a3557)';
  ['fleet','tracking','trips'].forEach(t=>{ const el=document.getElementById('vtab-'+t); if(el) el.style.display=t===name?'block':'none'; });
}

async function dispatchVehicle(id) {
  const v = _allVehicles.find(x => x.id === id); if (!v) return;
  v.status = 'On Road';
  toast('Vehicle dispatched.','success');
  loadAdminVehicles();
}
async function returnVehicle(id) {
  const v = _allVehicles.find(x => x.id === id); if (!v) return;
  v.status = 'Available';
  toast('Vehicle returned to base.','success');
  loadAdminVehicles();
}
async function deleteVehicle(id) {
  if (!confirm('Delete this vehicle?')) return;
  _allVehicles = _allVehicles.filter(x => x.id !== id);
  _allTrips = _allTrips.filter(t => t.vehicle_id !== id);
  toast('Vehicle removed.','info');
  loadAdminVehicles();
}
async function editVehicleNotes(id) {
  const v = _allVehicles.find(x=>x.id===id); if(!v) return;
  const notes = prompt('Notes for '+v.make+' '+v.model+':', v.notes||''); if(notes===null) return;
  v.notes = notes;
  toast('Notes updated.','success');
  loadAdminVehicles();
}
async function openAddVehicleModal() {
  const make  = prompt('Make (e.g. Toyota):');          if(!make)  return;
  const model = prompt('Model (e.g. Corolla):');        if(!model) return;
  const year  = parseInt(prompt('Year (e.g. 2024):')||'2024');
  const reg   = prompt('Registration (e.g. GP 00 00 AA):'); if(!reg) return;
  const licence = prompt('Licence type (Learners / Code 8 / Code 10 / Code A / Refresher):')||'Code 8';
  const transmission = prompt('Transmission (Manual / Automatic):')||'Manual';
  const colour = prompt('Colour:')||'White';
  _allVehicles.unshift({
    id: 'v' + Date.now(), make, model, year, reg, colour, transmission, licence, status:'Available', km:0, notes:'Added from admin panel.'
  });
  toast(`${make} ${model} added!`,'success');
  loadAdminVehicles();
}

// ══════════════════════════════════════════════════
//  AI INSIGHTS (Admin)
// ══════════════════════════════════════════════════
let _aiPredictions = [];

async function loadAdminAI() {
  try {
    const [bookings, users] = await Promise.all([
      UniDriveAPI.getAllBookings(),
      UniDriveAPI.getAllProfiles(),
    ]);
    const students = users.filter(u=>u.role==='student');
    _aiPredictions = students.map(u => buildPrediction(u, bookings.filter(b=>b.user_id===u.id)));
    renderAIInsightBox();
    renderAIBiLayers(bookings);
    renderAIKpis();
    renderAIRevenueChart(bookings);
    renderAIAttendanceChart(bookings);
    renderAIReadinessDist();
    renderAIRiskDist();
    renderAITable();
  } catch(err) { toast('Could not load AI data: '+err.message,'error'); }
}

function buildPrediction(u, mine) {
  const completed = mine.filter(b=>b.status==='completed').length;
  const pending   = mine.filter(b=>b.status==='pending').length;
  const total     = mine.length;
  const lastBk    = mine.sort((a,b)=>(b.created_at||'').localeCompare(a.created_at||''))[0];
  const daysSince = lastBk ? Math.floor((Date.now()-new Date(lastBk.created_at||Date.now()))/86400000) : 999;
  const target    = {'learners':5,'code8':10,'codeA':10,'code10':15,'code14':15,'adaptive':8}[lastBk?.course_id]||10;
  const progress  = Math.min(1, completed/target);
  const attRate   = total>0 ? completed/total : 0;
  const recency   = daysSince<=7?1:daysSince<=21?0.6:daysSince<=45?0.3:0.1;
  const readiness = Math.round(Math.max(0,Math.min(100,(progress*0.6+attRate*0.3+recency*0.1)*100)));
  const passProb  = Math.round(Math.min(95,Math.max(5,readiness*0.9+attRate*10)));
  let status,statusColor;
  if(readiness>=80){status='Ready';statusColor='#16a34a';}
  else if(readiness>=55){status='Nearly Ready';statusColor='#2563eb';}
  else if(readiness>=30){status='In Progress';statusColor='#d97706';}
  else{status='Needs More Training';statusColor='#dc2626';}
  let risk=0;
  if(daysSince>30)risk+=40; else if(daysSince>14)risk+=20; else if(daysSince>7)risk+=8;
  if(total>0&&attRate<0.6)risk+=25; else if(total>0&&attRate<0.8)risk+=10;
  if(pending>0)risk+=15; if(total===0)risk+=25; risk=Math.min(100,risk);
  let riskLevel,riskColor;
  if(risk>=50){riskLevel='High Risk';riskColor='#dc2626';}
  else if(risk>=20){riskLevel='Medium Risk';riskColor='#d97706';}
  else{riskLevel='Low Risk';riskColor='#16a34a';}
  let rec='Steady progress — continue current lesson plan.';
  if(daysSince>21&&total>0) rec=`Hasn't booked in ${daysSince} days — reach out.`;
  else if(risk>=50) rec='High dropout risk — proactive outreach recommended.';
  else if(readiness>=80) rec='Test-ready — suggest official test booking.';
  else if(readiness>=55) rec='Good progress — a few more lessons recommended.';
  else if(total===0) rec='No bookings yet — schedule introductory lesson.';
  return { u, total, completed, pending, readiness, status, statusColor, passProb, risk, riskLevel, riskColor, rec, daysSince, attRate:Math.round(attRate*100) };
}

function renderAIInsightBox() {
  const lines=[];
  const ready   = _aiPredictions.filter(p=>p.status==='Ready').length;
  const highRisk= _aiPredictions.filter(p=>p.riskLevel==='High Risk').length;
  const inactive= _aiPredictions.filter(p=>p.daysSince>14&&p.total>0).length;
  lines.push(`${_aiPredictions.length} students analysed across all active courses.`);
  if(highRisk>0) lines.push(`${highRisk} student(s) flagged as High Dropout Risk — proactive outreach recommended.`);
  if(ready>0)    lines.push(`${ready} student(s) are test-ready — consider scheduling official tests.`);
  if(inactive>0) lines.push(`${inactive} student(s) have not booked a lesson in over 14 days.`);
  const ul=document.getElementById('aiInsightList');
  if(ul) ul.innerHTML=lines.map(l=>`<li>${l}</li>`).join('');
}

function renderAIBiLayers(bookings) {
  const el=document.getElementById('aiBiLayers'); if(!el) return;
  const ready  =_aiPredictions.filter(p=>p.status==='Ready').length;
  const nearly =_aiPredictions.filter(p=>p.status==='Nearly Ready').length;
  const highRisk=_aiPredictions.filter(p=>p.riskLevel==='High Risk').length;
  const comp   =(bookings||[]).filter(b=>b.status==='completed').length;
  const pend   =(bookings||[]).filter(b=>b.status==='pending').length;
  el.innerHTML=`
    <div class="card" style="border-top:4px solid #2563eb"><div class="card-body">
      <div style="font-size:11px;font-weight:700;letter-spacing:.5px;color:#2563eb;margin-bottom:.6rem">📊 WHAT HAPPENED</div>
      <div style="font-size:13px;line-height:1.8"><strong>Completed lessons:</strong> ${comp}<br><strong>Pending bookings:</strong> ${pend}<br><strong>Students analysed:</strong> ${_aiPredictions.length}</div>
    </div></div>
    <div class="card" style="border-top:4px solid #d97706"><div class="card-body">
      <div style="font-size:11px;font-weight:700;letter-spacing:.5px;color:#d97706;margin-bottom:.6rem">🔍 WHY IT HAPPENED</div>
      <div style="font-size:13px;line-height:1.8">
        ${highRisk>0?`<strong>${highRisk} high-risk</strong> students — extended booking gaps driving dropout risk.<br>`:''}
        ${pend>0?`<strong>${pend} pending</strong> bookings need admin confirmation.<br>`:''}
        ${comp>0?`<strong>${comp} lessons</strong> completed successfully.`:'No completed lessons yet.'}
      </div>
    </div></div>
    <div class="card" style="border-top:4px solid #16a34a"><div class="card-body">
      <div style="font-size:11px;font-weight:700;letter-spacing:.5px;color:#16a34a;margin-bottom:.6rem">🔮 WHAT IS NEXT</div>
      <div style="font-size:13px;line-height:1.8">
        ${ready>0?`<strong>${ready} test-ready</strong> — expect official test bookings soon.<br>`:''}
        ${nearly>0?`<strong>${nearly} nearly ready</strong> — test-ready within 2–4 weeks.<br>`:''}
        ${highRisk>0?`<strong>${highRisk}</strong> at dropout risk — outreach in next 7 days.`:'Dropout risk is low — great work!'}
      </div>
    </div></div>`;
}

function renderAIKpis() {
  const el=document.getElementById('aiKpis'); if(!el) return;
  el.innerHTML=`
    <div class="stat-card sc-green"><div class="sc-num">${_aiPredictions.filter(p=>p.status==='Ready').length}</div><div class="sc-lbl">✅ Ready for Test</div></div>
    <div class="stat-card sc-blue"><div class="sc-num">${_aiPredictions.filter(p=>p.status==='Nearly Ready').length}</div><div class="sc-lbl">⏱️ Nearly Ready</div></div>
    <div class="stat-card" style="border-color:#dc2626"><div class="sc-num" style="color:#dc2626">${_aiPredictions.filter(p=>p.riskLevel==='High Risk').length}</div><div class="sc-lbl">⚠️ High Dropout Risk</div></div>
    <div class="stat-card sc-dark"><div class="sc-num">${_aiPredictions.length}</div><div class="sc-lbl">🤖 Analysed</div></div>`;
}

function renderAIRevenueChart(bookings) {
  const el=document.getElementById('aiRevenueChart'); if(!el) return;
  const months=[];
  for(let i=5;i>=0;i--){
    const d=new Date(); d.setMonth(d.getMonth()-i);
    const label=d.toLocaleString('default',{month:'short'});
    const yr=d.getFullYear(), mo=String(d.getMonth()+1).padStart(2,'0');
    const count=(bookings||[]).filter(b=>(b.created_at||'').startsWith(`${yr}-${mo}`)).length;
    months.push({label,count});
  }
  const maxC=Math.max(1,...months.map(m=>m.count));
  el.innerHTML=`<div style="font-weight:600;font-size:13.5px;margin-bottom:1rem">📊 Bookings per Month</div>
    <div style="display:flex;align-items:flex-end;gap:.8rem;height:120px;padding:0 .5rem">
      ${months.map((m,i)=>{
        const h=Math.max(6,Math.round(m.count/maxC*100));
        return `<div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:.3rem">
          <span style="font-size:11px;font-weight:600;color:${i===5?'var(--primary,#1a3557)':'#888'}">${m.count}</span>
          <div style="width:100%;height:${h}px;border-radius:4px 4px 0 0;background:${i===5?'linear-gradient(180deg,#38bdf8,#0ea5e9)':'#e2e8f0'}"></div>
          <span style="font-size:11px;color:#888">${m.label}</span>
        </div>`;
      }).join('')}
    </div>`;
}

function renderAIAttendanceChart(bookings) {
  const el=document.getElementById('aiAttendanceChart'); if(!el) return;
  const groups={Completed:0,Confirmed:0,Pending:0,Cancelled:0};
  (bookings||[]).forEach(b=>{const k=b.status.charAt(0).toUpperCase()+b.status.slice(1);if(k in groups)groups[k]++;});
  const total=(bookings||[]).length||1;
  const colors={Completed:'#16a34a',Confirmed:'#2563eb',Pending:'#d97706',Cancelled:'#dc2626'};
  el.innerHTML=`<div style="font-weight:600;font-size:13.5px;margin-bottom:1rem">📈 Booking Status Breakdown</div>
    ${Object.entries(groups).map(([k,v])=>`
      <div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:.3rem"><span>${k}</span><strong>${v}</strong></div>
      <div style="background:#f1f5f9;border-radius:6px;height:8px;margin-bottom:.8rem;overflow:hidden">
        <div style="height:100%;width:${Math.round(v/total*100)}%;background:${colors[k]};border-radius:6px"></div>
      </div>`).join('')}`;
}

function renderAIReadinessDist() {
  const el=document.getElementById('aiReadinessDist'); if(!el) return;
  const counts={'Ready':0,'Nearly Ready':0,'In Progress':0,'Needs More Training':0};
  _aiPredictions.forEach(p=>{if(p.status in counts)counts[p.status]++;});
  const colors={'Ready':'#16a34a','Nearly Ready':'#2563eb','In Progress':'#d97706','Needs More Training':'#dc2626'};
  const max=Math.max(1,...Object.values(counts));
  el.innerHTML=`<div style="font-weight:600;font-size:13.5px;margin-bottom:1rem">📋 Test Readiness Distribution</div>
    ${Object.entries(counts).map(([k,v])=>`
      <div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:.3rem"><span>${k}</span><strong>${v}</strong></div>
      <div style="background:#f1f5f9;border-radius:6px;height:8px;margin-bottom:.8rem;overflow:hidden">
        <div style="height:100%;width:${Math.round(v/max*100)}%;background:${colors[k]};border-radius:6px"></div>
      </div>`).join('')}`;
}

function renderAIRiskDist() {
  const el=document.getElementById('aiRiskDist'); if(!el) return;
  const counts={'Low Risk':0,'Medium Risk':0,'High Risk':0};
  _aiPredictions.forEach(p=>{if(p.riskLevel in counts)counts[p.riskLevel]++;});
  const colors={'Low Risk':'#16a34a','Medium Risk':'#d97706','High Risk':'#dc2626'};
  const max=Math.max(1,...Object.values(counts));
  el.innerHTML=`<div style="font-weight:600;font-size:13.5px;margin-bottom:1rem">⚠️ Dropout Risk Distribution</div>
    ${Object.entries(counts).map(([k,v])=>`
      <div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:.3rem"><span>${k}</span><strong>${v}</strong></div>
      <div style="background:#f1f5f9;border-radius:6px;height:8px;margin-bottom:.8rem;overflow:hidden">
        <div style="height:100%;width:${Math.round(v/max*100)}%;background:${colors[k]};border-radius:6px"></div>
      </div>`).join('')}`;
}

function renderAITable() {
  const tbody=document.getElementById('aiStudentBody'); if(!tbody) return;
  const search=(document.getElementById('aiStudentSearch')||{value:''}).value.toLowerCase();
  const rf=(document.getElementById('aiReadinessFilter')||{value:''}).value;
  const rkf=(document.getElementById('aiRiskFilter')||{value:''}).value;
  const filtered=_aiPredictions.filter(p=>{
    const name=`${p.u.first_name} ${p.u.last_name}`.toLowerCase();
    if(search&&!name.includes(search)) return false;
    if(rf&&p.status!==rf) return false;
    if(rkf&&p.riskLevel!==rkf) return false;
    return true;
  });
  if(!filtered.length){ tbody.innerHTML='<tr><td colspan="7" style="text-align:center;padding:2rem;color:#888">No students match the filters.</td></tr>'; return; }
  const pillBg = c=>({'#16a34a':'#dcfce7','#2563eb':'#dbeafe','#d97706':'#fef9c3','#dc2626':'#fee2e2'}[c]||'#f1f5f9');
  tbody.innerHTML=filtered.map(p=>{
    const ini=(p.u.first_name[0]+p.u.last_name[0]).toUpperCase();
    return `<tr>
      <td><div style="display:flex;align-items:center;gap:.5rem">
        <div style="width:30px;height:30px;border-radius:50%;background:var(--navy,#1a2744);color:#fff;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;flex-shrink:0">${ini}</div>
        <span>${p.u.first_name} ${p.u.last_name}</span>
      </div></td>
      <td style="font-size:12px;color:#888">${p.u.student_number||'—'}</td>
      <td><strong style="color:${p.statusColor}">${p.readiness}%</strong>
        <div style="background:#f1f5f9;border-radius:4px;height:5px;width:70px;margin-top:3px;overflow:hidden;display:inline-block;vertical-align:middle;margin-left:5px">
          <div style="height:100%;width:${p.readiness}%;background:${p.statusColor};border-radius:4px"></div>
        </div>
      </td>
      <td><span style="background:${pillBg(p.statusColor)};color:${p.statusColor};font-size:11.5px;font-weight:500;padding:2px 10px;border-radius:20px">● ${p.status}</span></td>
      <td>${p.passProb}%</td>
      <td><span style="background:${pillBg(p.riskColor)};color:${p.riskColor};font-size:11.5px;font-weight:500;padding:2px 10px;border-radius:20px">${p.riskLevel}</span></td>
      <td style="font-size:12px;color:#888;max-width:200px">${p.rec}</td>
    </tr>`;
  }).join('');
}

// ══════════════════════════════════════════════════
//  MY READINESS (Student Dashboard)
// ══════════════════════════════════════════════════
async function loadMyReadiness() {
  if(!currentUser) return;
  const el=document.getElementById('readinessContent'); if(!el) return;
  el.innerHTML='<p class="text-muted" style="padding:2rem">Loading readiness data…</p>';
  try {
    const mine = await UniDriveAPI.getMyBookings(currentUser.id);
    const completed=mine.filter(b=>b.status==='completed').length;
    const total=mine.length;
    const lastBk=mine.sort((a,b)=>(b.created_at||'').localeCompare(a.created_at||''))[0];
    const target={'learners':5,'code8':10,'codeA':10,'code10':15,'code14':15,'adaptive':8}[lastBk?.course_id]||10;
    const progress=Math.min(1,completed/target);
    const attRate=total>0?completed/total:0;
    const daysSince=lastBk?Math.floor((Date.now()-new Date(lastBk.created_at||Date.now()))/86400000):null;
    const recency=daysSince===null?0.1:daysSince<=7?1:daysSince<=21?0.6:daysSince<=45?0.3:0.1;
    const readiness=Math.round(Math.max(0,Math.min(100,(progress*0.6+attRate*0.3+recency*0.1)*100)));
    const passProb=Math.round(Math.min(95,Math.max(5,readiness*0.9+attRate*10)));
    const lessonsLeft=Math.max(0,target-completed);
    let status,color,emoji;
    if(readiness>=80){status='Ready for Test';color='#16a34a';emoji='🎉';}
    else if(readiness>=55){status='Nearly Ready';color='#2563eb';emoji='💪';}
    else if(readiness>=30){status='In Progress';color='#d97706';emoji='📈';}
    else{status='Needs More Training';color='#dc2626';emoji='🚦';}
    let predictedDate='Not enough data yet';
    if(lessonsLeft===0) predictedDate='You\'ve hit your lesson target!';
    else if(total>0){
      const weeks=Math.ceil(lessonsLeft/Math.max(0.5,completed/Math.max(1,daysSince/7)));
      const d=new Date(); d.setDate(d.getDate()+weeks*7);
      predictedDate=d.toLocaleDateString('en-ZA',{day:'numeric',month:'short',year:'numeric'});
    }
    const tips=[];
    if(readiness<30){tips.push('Aim for 1–2 bookings per week to build momentum.');tips.push('Review study materials before each lesson.');}
    else if(readiness<55){tips.push('Keep your lesson pace consistent to reach test-readiness sooner.');tips.push('Ask your instructor for feedback on challenging areas.');}
    else if(readiness<80){tips.push('You\'re close! A few more lessons will push you to test-ready.');tips.push('Practice mock K53 questions from the Study Materials section.');}
    else{tips.push('You\'re test-ready! Talk to admin about booking your official test.');tips.push('Do a final review of road signs and rules the night before.');}
    const circ=2*Math.PI*90, offset=circ*(1-readiness/100);
    el.innerHTML=`
      <div style="display:grid;grid-template-columns:1fr 1.5fr;gap:1.5rem;align-items:start" class="readiness-main-grid">
        <div class="card"><div class="card-body" style="text-align:center">
          <div style="font-weight:600;font-size:14px;margin-bottom:.5rem">Test Readiness Score</div>
          <div style="position:relative;width:200px;height:200px;margin:0 auto 1rem">
            <svg width="200" height="200" viewBox="0 0 200 200" style="transform:rotate(-90deg)">
              <circle cx="100" cy="100" r="90" fill="none" stroke="#f1f5f9" stroke-width="13"/>
              <circle cx="100" cy="100" r="90" fill="none" stroke="${color}" stroke-width="13" stroke-linecap="round"
                stroke-dasharray="${circ}" stroke-dashoffset="${offset}"/>
            </svg>
            <div style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center">
              <div style="font-size:2.8rem;font-weight:800;color:${color};line-height:1">${readiness}%</div>
              <div style="font-size:11px;color:#888;letter-spacing:.4px;margin-top:.2rem">READINESS</div>
            </div>
          </div>
          <div style="display:inline-flex;align-items:center;gap:6px;padding:5px 16px;border-radius:20px;font-size:13px;font-weight:600;background:${color}22;color:${color};margin-bottom:1rem">${emoji} ${status}</div>
          <div style="text-align:left;margin-top:.5rem">
            <div style="display:flex;justify-content:space-between;padding:.55rem 0;border-bottom:1px solid #f1f5f9;font-size:13.5px"><span>Pass Probability</span><strong>${passProb}%</strong></div>
            <div style="display:flex;justify-content:space-between;padding:.55rem 0;border-bottom:1px solid #f1f5f9;font-size:13.5px"><span>Lessons Completed</span><strong>${completed} / ${target}</strong></div>
            <div style="display:flex;justify-content:space-between;padding:.55rem 0;border-bottom:1px solid #f1f5f9;font-size:13.5px"><span>Completion Rate</span><strong>${Math.round(attRate*100)}%</strong></div>
            <div style="display:flex;justify-content:space-between;padding:.55rem 0;font-size:13.5px"><span>Last Booking</span><strong>${daysSince===null?'No bookings yet':daysSince===0?'Today':daysSince+' days ago'}</strong></div>
          </div>
        </div></div>
        <div>
          <div style="background:linear-gradient(135deg,#1a3557,#1a2636);color:#fff;border-radius:12px;padding:1.5rem;text-align:center;margin-bottom:1.2rem">
            <div style="font-size:11px;color:rgba(255,255,255,.5);letter-spacing:.4px;margin-bottom:.4rem">🔮 TEST DAY PREDICTOR</div>
            <div style="font-size:1.6rem;font-weight:700;color:#fbbf24">~${predictedDate}</div>
            <div style="font-size:12px;color:rgba(255,255,255,.6);margin-top:.4rem">${lessonsLeft} lesson(s) remaining to reach your ${target}-lesson target.</div>
          </div>
          <div class="card"><div class="card-body">
            <div style="font-weight:600;font-size:13.5px;margin-bottom:.8rem">💡 Personalised Tips</div>
            <ul style="list-style:none;padding:0;margin:0">
              ${tips.map(t=>`<li style="display:flex;gap:.6rem;padding:.6rem 0;border-bottom:1px solid #f1f5f9;font-size:13px;align-items:flex-start"><span style="color:#16a34a;flex-shrink:0">✓</span><span>${t}</span></li>`).join('')}
            </ul>
            <div style="margin-top:1rem;display:flex;gap:.5rem;flex-wrap:wrap">
              <a href="learn.html" class="btn btn-primary btn-sm">📚 Study Materials</a>
              <a href="mocktest.html" class="btn btn-ghost btn-sm">📝 Mock Test</a>
            </div>
          </div></div>
        </div>
      </div>
      <style>@media(max-width:700px){.readiness-main-grid{grid-template-columns:1fr!important}}</style>`;
  } catch(err) { el.innerHTML=`<p class="text-muted">Could not load readiness data: ${err.message}</p>`; }
}
