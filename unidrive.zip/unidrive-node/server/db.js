// server/db.js — JSON file database helper
const fs   = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, '../data/db.json');
const GREEN  = '\x1b[32m';
const YELLOW = '\x1b[33m';
const RESET  = '\x1b[0m';
const DIM    = '\x1b[2m';

function read() {
  return JSON.parse(fs.readFileSync(DB_PATH, 'utf-8'));
}

function write(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
  const time = new Date().toLocaleTimeString('en-ZA');
  console.log(`${DIM}[${time}]${RESET} ${YELLOW}💾  db.json updated${RESET}`);
}

module.exports = { read, write };
