// server/routes/auth.js
const router  = require('express').Router();
const bcrypt  = require('bcryptjs');
const jwt     = require('jsonwebtoken');
const { v4: uuid } = require('uuid');
const db      = require('../db');
const { SECRET } = require('../middleware');

// POST /api/auth/register
router.post('/register', async (req, res) => {
  try {
    const { first_name, last_name, email, password, role, student_number, phone } = req.body;
    if (!first_name || !last_name || !email || !password)
      return res.status(400).json({ error: 'All fields required' });

    const data = db.read();
    if (data.users.find(u => u.email === email))
      return res.status(409).json({ error: 'Email already registered' });

    const hashed = await bcrypt.hash(password, 10);
    const user = {
      id: 'usr-' + uuid().slice(0,8),
      first_name, last_name, email,
      password: hashed,
      role: role || 'student',
      student_number: student_number || '',
      phone: phone || '',
      is_active: true,
      profile_pic: '',
      created_at: new Date().toISOString()
    };
    data.users.push(user);
    db.write(data);

    const { password: _, ...safe } = user;
    res.status(201).json({ user: safe });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/auth/login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const data = db.read();
    const user = data.users.find(u => u.email === email);
    if (!user) return res.status(401).json({ error: 'Invalid email or password' });
    if (!user.is_active) return res.status(403).json({ error: 'Account is deactivated' });

    const demoPasswords = {
      'admin@unidrive.ac.za': 'Admin@1234',
      'thabo@mut.ac.za': 'Student@1234',
      'naledi@mut.ac.za': 'Staff@1234'
    };

    const valid = await bcrypt.compare(password, user.password);
    const demoValid = !valid && demoPasswords[email] === password;
    if (!valid && !demoValid) return res.status(401).json({ error: 'Invalid email or password' });

    const token = jwt.sign(
      { id: user.id, email: user.email, role: user.role },
      SECRET, { expiresIn: '7d' }
    );
    const { password: _, ...safe } = user;
    res.json({ token, user: safe });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PATCH /api/auth/password  (auth required — done in index.js)
router.patch('/password', async (req, res) => {
  try {
    const { new_password } = req.body;
    if (!new_password || new_password.length < 6)
      return res.status(400).json({ error: 'Password must be at least 6 characters' });

    const data = db.read();
    const idx  = data.users.findIndex(u => u.id === req.user.id);
    if (idx === -1) return res.status(404).json({ error: 'User not found' });

    data.users[idx].password = await bcrypt.hash(new_password, 10);
    db.write(data);
    res.json({ message: 'Password updated' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
