// server/routes/enquiries.js
const router = require('express').Router();
const { v4: uuid } = require('uuid');
const { auth, adminOnly } = require('../middleware');
const db = require('../db');

// POST /api/enquiries  (public)
router.post('/', (req, res) => {
  const { name, email, phone, message } = req.body;
  if (!name || !email || !message) return res.status(400).json({ error: 'name, email and message required' });
  const data = db.read();
  const enq  = { id:'enq-'+uuid().slice(0,8), name, email, phone:phone||'', message, status:'new', created_at: new Date().toISOString() };
  data.enquiries.push(enq);
  db.write(data);
  res.status(201).json(enq);
});

// GET /api/enquiries  (admin)
router.get('/', auth, adminOnly, (_req, res) => {
  const data = db.read();
  res.json(data.enquiries.sort((a,b) => b.created_at.localeCompare(a.created_at)));
});

// PATCH /api/enquiries/:id/status  (admin)
router.patch('/:id/status', auth, adminOnly, (req, res) => {
  const data = db.read();
  const idx  = data.enquiries.findIndex(e => e.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  data.enquiries[idx].status = req.body.status;
  db.write(data);
  res.json(data.enquiries[idx]);
});

module.exports = router;
