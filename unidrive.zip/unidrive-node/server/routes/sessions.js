// server/routes/sessions.js
const router = require('express').Router();
const { auth } = require('../middleware');
const db = require('../db');

// GET /api/sessions/progress
router.get('/progress', auth, (req, res) => {
  const data = db.read();
  res.json(data.session_progress.filter(s => s.user_id === req.user.id));
});

// POST /api/sessions/progress  (mark watched)
router.post('/progress', auth, (req, res) => {
  const { session_id, session_title } = req.body;
  const data = db.read();
  const existing = data.session_progress.findIndex(s => s.user_id === req.user.id && s.session_id === session_id);
  const entry = { user_id: req.user.id, session_id, session_title: session_title||'', watched: true, watched_at: new Date().toISOString() };
  if (existing !== -1) data.session_progress[existing] = entry;
  else data.session_progress.push(entry);
  db.write(data);
  res.json(entry);
});

module.exports = router;
