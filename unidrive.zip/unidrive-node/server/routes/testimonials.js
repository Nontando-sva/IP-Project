// server/routes/testimonials.js
const router = require('express').Router();
const { v4: uuid } = require('uuid');
const { auth, adminOnly } = require('../middleware');
const db = require('../db');

// GET /api/testimonials  (public — approved only)
router.get('/', (_req, res) => {
  const data = db.read();
  const approved = data.testimonials
    .filter(t => t.is_approved)
    .map(t => {
      const user = data.users.find(u => u.id === t.user_id);
      return { ...t, user: user ? { first_name: user.first_name, last_name: user.last_name } : null };
    })
    .sort((a, b) => b.created_at.localeCompare(a.created_at));
  res.json(approved);
});

// GET /api/testimonials/all  (admin)
router.get('/all', auth, adminOnly, (_req, res) => {
  const data = db.read();
  const all  = data.testimonials.map(t => {
    const user = data.users.find(u => u.id === t.user_id);
    return { ...t, user: user ? { first_name: user.first_name, last_name: user.last_name, email: user.email } : null };
  }).sort((a,b) => b.created_at.localeCompare(a.created_at));
  res.json(all);
});

// POST /api/testimonials
router.post('/', auth, (req, res) => {
  const { rating, message } = req.body;
  if (!rating || !message) return res.status(400).json({ error: 'rating and message required' });
  const data = db.read();
  const t = { id:'tst-'+uuid().slice(0,8), user_id: req.user.id, rating: Number(rating), message, is_approved: false, created_at: new Date().toISOString() };
  data.testimonials.push(t);
  db.write(data);
  res.status(201).json(t);
});

// PATCH /api/testimonials/:id/approve  (admin)
router.patch('/:id/approve', auth, adminOnly, (req, res) => {
  const data = db.read();
  const idx  = data.testimonials.findIndex(t => t.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  data.testimonials[idx].is_approved = req.body.is_approved;
  db.write(data);
  res.json(data.testimonials[idx]);
});

module.exports = router;
