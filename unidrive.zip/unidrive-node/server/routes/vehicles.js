// server/routes/vehicles.js
const router = require('express').Router();
const { v4: uuid } = require('uuid');
const { auth, adminOnly } = require('../middleware');
const db = require('../db');

router.get('/', auth, (_req, res) => res.json(db.read().vehicles));

router.post('/', auth, adminOnly, (req, res) => {
  const data = db.read();
  const v = { id:'veh-'+uuid().slice(0,8), ...req.body, status:'Available', km:0, created_at: new Date().toISOString() };
  data.vehicles.push(v);
  db.write(data);
  res.status(201).json(v);
});

router.patch('/:id', auth, adminOnly, (req, res) => {
  const data = db.read();
  const idx  = data.vehicles.findIndex(v => v.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  data.vehicles[idx] = { ...data.vehicles[idx], ...req.body };
  db.write(data);
  res.json(data.vehicles[idx]);
});

router.delete('/:id', auth, adminOnly, (req, res) => {
  const data = db.read();
  data.vehicles = data.vehicles.filter(v => v.id !== req.params.id);
  db.write(data);
  res.json({ message: 'Deleted' });
});

// Trips
router.get('/trips', auth, adminOnly, (_req, res) => {
  const data = db.read();
  const trips = data.vehicle_trips.map(t => ({
    ...t, vehicle: data.vehicles.find(v => v.id === t.vehicle_id) || null
  })).sort((a,b) => b.trip_date.localeCompare(a.trip_date));
  res.json(trips);
});

router.post('/trips', auth, adminOnly, (req, res) => {
  const data = db.read();
  const trip = { id:'trp-'+uuid().slice(0,8), ...req.body, created_at: new Date().toISOString() };
  data.vehicle_trips.push(trip);
  db.write(data);
  res.status(201).json(trip);
});

module.exports = router;
