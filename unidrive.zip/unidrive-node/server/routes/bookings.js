// server/routes/bookings.js
const router = require('express').Router();
const { v4: uuid } = require('uuid');
const { auth, adminOnly } = require('../middleware');
const db = require('../db');

// GET /api/bookings/mine
router.get('/mine', auth, (req, res) => {
  const data  = db.read();
  const items = data.bookings
    .filter(b => b.user_id === req.user.id)
    .map(b => ({ ...b, course: data.courses.find(c => c.id === b.course_id) || null }))
    .sort((a, b) => b.created_at.localeCompare(a.created_at));
  res.json(items);
});

// GET /api/bookings  (admin)
router.get('/', auth, adminOnly, (req, res) => {
  const data = db.read();
  const items = data.bookings.map(b => ({
    ...b,
    course: data.courses.find(c => c.id === b.course_id) || null,
    user:   (() => { const u = data.users.find(u => u.id === b.user_id); if(!u) return null; const {password,...s}=u; return s; })()
  })).sort((a, b) => b.created_at.localeCompare(a.created_at));
  res.json(items);
});

// POST /api/bookings
router.post('/', auth, (req, res) => {
  const { course_id, booking_date, booking_time, total_price, notes } = req.body;
  const data = db.read();

  // Check slot clash
  const clash = data.bookings.find(b =>
    b.booking_date === booking_date &&
    b.booking_time === booking_time &&
    ['pending','confirmed'].includes(b.status)
  );
  if (clash) return res.status(409).json({ error: 'That time slot is already taken. Please choose another.' });

  const booking = {
    id: 'bk-' + uuid().slice(0,8),
    user_id: req.user.id,
    course_id, booking_date, booking_time,
    total_price: Number(total_price),
    status: 'pending',
    paid: false,
    notes: notes || '',
    created_at: new Date().toISOString()
  };
  data.bookings.push(booking);
  db.write(data);
  res.status(201).json({ ...booking, course: data.courses.find(c => c.id === course_id) });
});

// PATCH /api/bookings/:id/status
router.patch('/:id/status', auth, (req, res) => {
  const data = db.read();
  const idx  = data.bookings.findIndex(b => b.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Booking not found' });

  const booking = data.bookings[idx];
  // students can only cancel their own
  if (req.user.role !== 'admin' && booking.user_id !== req.user.id)
    return res.status(403).json({ error: 'Forbidden' });

  data.bookings[idx].status = req.body.status;
  db.write(data);
  res.json(data.bookings[idx]);
});

module.exports = router;
