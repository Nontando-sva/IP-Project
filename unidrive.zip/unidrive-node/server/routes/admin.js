// server/routes/admin.js
const router = require('express').Router();
const { auth, adminOnly } = require('../middleware');
const db = require('../db');

// GET /api/admin/stats
router.get('/stats', auth, adminOnly, (_req, res) => {
  const data = db.read();
  const b    = data.bookings;
  const p    = data.payments;
  res.json({
    total_users:        data.users.length,
    total_students:     data.users.filter(u => u.role === 'student').length,
    total_staff:        data.users.filter(u => u.role === 'staff').length,
    total_bookings:     b.length,
    pending_bookings:   b.filter(x => x.status === 'pending').length,
    confirmed_bookings: b.filter(x => x.status === 'confirmed').length,
    new_enquiries:      data.enquiries.filter(e => e.status === 'new').length,
    total_revenue:      p.filter(x => x.status === 'completed').reduce((s, x) => s + x.amount, 0)
  });
});

module.exports = router;
