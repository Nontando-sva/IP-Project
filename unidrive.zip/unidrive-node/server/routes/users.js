// server/routes/users.js
const router = require('express').Router();
const { auth, adminOnly } = require('../middleware');
const db = require('../db');

// GET /api/users/me
router.get('/me', auth, (req, res) => {
  const data = db.read();
  const user = data.users.find(u => u.id === req.user.id);
  if (!user) return res.status(404).json({ error: 'User not found' });
  const { password, ...safe } = user;
  res.json(safe);
});

// GET /api/users  (admin)
router.get('/', auth, adminOnly, (req, res) => {
  const data = db.read();
  const users = data.users.map(({ password, ...u }) => u);
  res.json(users);
});

// PATCH /api/users/me
router.patch('/me', auth, (req, res) => {
  const allowed = ['first_name','last_name','phone','student_number','profile_pic'];
  const data = db.read();
  const idx  = data.users.findIndex(u => u.id === req.user.id);
  if (idx === -1) return res.status(404).json({ error: 'User not found' });
  allowed.forEach(k => { if (req.body[k] !== undefined) data.users[idx][k] = req.body[k]; });
  db.write(data);
  const { password, ...safe } = data.users[idx];
  res.json(safe);
});

// PATCH /api/users/:id/status  (admin)
router.patch('/:id/status', auth, adminOnly, (req, res) => {
  const data = db.read();
  const idx  = data.users.findIndex(u => u.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'User not found' });
  data.users[idx].is_active = req.body.is_active;
  db.write(data);
  const { password, ...safe } = data.users[idx];
  res.json(safe);
});

module.exports = router;
