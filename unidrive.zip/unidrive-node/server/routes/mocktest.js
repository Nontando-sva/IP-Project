// server/routes/mocktest.js
const router = require('express').Router();
const { v4: uuid } = require('uuid');
const { auth, adminOnly } = require('../middleware');
const db = require('../db');

// GET /api/mocktest/mine
router.get('/mine', auth, (req, res) => {
  const data = db.read();
  const results = data.mock_test_results
    .filter(r => r.user_id === req.user.id)
    .sort((a,b) => b.created_at.localeCompare(a.created_at));
  res.json(results);
});

// POST /api/mocktest
router.post('/', auth, (req, res) => {
  const { score, total, percentage, passed, time_taken_s, answers } = req.body;
  const data   = db.read();
  const result = {
    id: 'mtr-' + uuid().slice(0,8),
    user_id: req.user.id,
    score: Number(score), total: Number(total),
    percentage: Number(percentage), passed: Boolean(passed),
    time_taken_s: Number(time_taken_s) || 0,
    answers: answers || {},
    created_at: new Date().toISOString()
  };
  data.mock_test_results.push(result);
  db.write(data);
  res.status(201).json(result);
});

// GET /api/mocktest/all  (admin)
router.get('/all', auth, adminOnly, (_req, res) => {
  const data = db.read();
  const all = data.mock_test_results.map(r => {
    const user = data.users.find(u => u.id === r.user_id);
    return { ...r, user: user ? { first_name: user.first_name, last_name: user.last_name, student_number: user.student_number } : null };
  }).sort((a,b) => b.created_at.localeCompare(a.created_at));
  res.json(all);
});

module.exports = router;
