// server/routes/payments.js
const router = require('express').Router();
const { v4: uuid } = require('uuid');
const { auth, adminOnly } = require('../middleware');
const db = require('../db');

// GET /api/payments/mine
router.get('/mine', auth, (req, res) => {
  const data = db.read();
  const items = data.payments
    .filter(p => p.user_id === req.user.id)
    .map(p => ({ ...p, booking: data.bookings.find(b => b.id === p.booking_id) || null }))
    .sort((a, b) => b.created_at.localeCompare(a.created_at));
  res.json(items);
});

// POST /api/payments
router.post('/', auth, (req, res) => {
  const { booking_id, amount, method } = req.body;
  const data  = db.read();

  const reference = 'UDA-' + Date.now().toString(36).toUpperCase();
  const payment = {
    id: 'pay-' + uuid().slice(0,8),
    booking_id, user_id: req.user.id,
    amount: Number(amount), method,
    status: 'completed',
    reference,
    created_at: new Date().toISOString()
  };
  data.payments.push(payment);

  // Mark booking as paid + confirmed
  const bIdx = data.bookings.findIndex(b => b.id === booking_id);
  if (bIdx !== -1) { data.bookings[bIdx].paid = true; data.bookings[bIdx].status = 'confirmed'; }
  db.write(data);
  res.status(201).json(payment);
});

// GET /api/payments  (admin)
router.get('/', auth, adminOnly, (req, res) => {
  const data = db.read();
  res.json(data.payments.sort((a,b) => b.created_at.localeCompare(a.created_at)));
});

module.exports = router;
