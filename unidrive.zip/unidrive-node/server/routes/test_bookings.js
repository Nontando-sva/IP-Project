// server/routes/test_bookings.js
const router = require('express').Router();
const { v4: uuid } = require('uuid');
const { auth, adminOnly } = require('../middleware');
const db = require('../db');

router.get('/mine', auth, (req, res) => {
  const data = db.read();
  res.json(data.test_bookings
    .filter(t => t.user_id === req.user.id)
    .sort((a,b) => a.test_date.localeCompare(b.test_date)));
});

router.post('/', auth, (req, res) => {
  const { test_type, dltc_centre, test_date, test_time, id_number, notes } = req.body;
  const data = db.read();
  const tb = {
    id: 'tb-' + uuid().slice(0,8),
    user_id: req.user.id,
    test_type, dltc_centre, test_date, test_time,
    id_number, notes: notes||'',
    status: 'pending',
    created_at: new Date().toISOString()
  };
  data.test_bookings.push(tb);
  db.write(data);
  res.status(201).json(tb);
});

router.get('/', auth, adminOnly, (_req, res) => {
  const data = db.read();
  const all  = data.test_bookings.map(t => {
    const user = data.users.find(u => u.id === t.user_id);
    return { ...t, user: user ? { first_name: user.first_name, last_name: user.last_name } : null };
  });
  res.json(all);
});

router.patch('/:id/status', auth, (req, res) => {
  const data = db.read();
  const idx  = data.test_bookings.findIndex(t => t.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  data.test_bookings[idx].status = req.body.status;
  db.write(data);
  res.json(data.test_bookings[idx]);
});

module.exports = router;
