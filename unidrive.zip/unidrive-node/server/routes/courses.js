// server/routes/courses.js
const router = require('express').Router();
const db = require('../db');

router.get('/', (_req, res) => res.json(db.read().courses));
router.get('/:id', (req, res) => {
  const c = db.read().courses.find(x => x.id === req.params.id);
  c ? res.json(c) : res.status(404).json({ error: 'Not found' });
});
module.exports = router;
