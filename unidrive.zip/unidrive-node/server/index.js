// server/index.js — Uni-Drive Academy Express Server
const express = require('express');
const cors    = require('cors');
const path    = require('path');
const { auth } = require('./middleware');

const app  = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

// ── Request Logger ─────────────────────────────────────────────────────────
const COLORS = { GET:'\x1b[32m', POST:'\x1b[34m', PATCH:'\x1b[33m', DELETE:'\x1b[31m' };
const RESET  = '\x1b[0m';
const DIM    = '\x1b[2m';
const BOLD   = '\x1b[1m';

app.use((req, res, next) => {
  if (!req.path.startsWith('/api')) return next();
  const start = Date.now();
  const color = COLORS[req.method] || '\x1b[37m';
  const time  = new Date().toLocaleTimeString('en-ZA');
  res.on('finish', () => {
    const ms     = Date.now() - start;
    const status = res.statusCode;
    const sc     = status < 400 ? '\x1b[32m' : '\x1b[31m';
    console.log(
      `${DIM}[${time}]${RESET} ` +
      `${color}${BOLD}${req.method.padEnd(7)}${RESET} ` +
      `${req.path.padEnd(35)} ` +
      `${sc}${status}${RESET} ` +
      `${DIM}${ms}ms${RESET}`
    );
  });
  next();
});

// ── Serve static frontend ──────────────────────────────────────────────────
app.use(express.static(path.join(__dirname, '../public')));

// ── API Routes ─────────────────────────────────────────────────────────────
app.use('/api/auth',          require('./routes/auth'));
app.use('/api/auth',          auth, require('./routes/auth'));   // password endpoint needs auth
app.use('/api/users',         require('./routes/users'));
app.use('/api/courses',       require('./routes/courses'));
app.use('/api/bookings',      require('./routes/bookings'));
app.use('/api/payments',      require('./routes/payments'));
app.use('/api/enquiries',     require('./routes/enquiries'));
app.use('/api/testimonials',  require('./routes/testimonials'));
app.use('/api/vehicles',      require('./routes/vehicles'));
app.use('/api/mocktest',      require('./routes/mocktest'));
app.use('/api/sessions',      require('./routes/sessions'));
app.use('/api/test-bookings', require('./routes/test_bookings'));
app.use('/api/admin',         require('./routes/admin'));

// ── SPA fallback — serve index.html for unknown routes ────────────────────
app.get('*', (_req, res) => {
  res.sendFile(path.join(__dirname, '../public/index.html'));
});

app.listen(PORT, () => {
  console.log(`\n🚗  Uni-Drive Academy running at http://localhost:${PORT}`);
  console.log(`📡  API endpoints:  http://localhost:${PORT}/api`);
  console.log(`\n  Demo accounts:`);
  console.log(`  Admin   → admin@unidrive.ac.za  / Admin@1234`);
  console.log(`  Student → thabo@mut.ac.za       / Student@1234`);
  console.log(`  Staff   → naledi@mut.ac.za       / Staff@1234\n`);
});
