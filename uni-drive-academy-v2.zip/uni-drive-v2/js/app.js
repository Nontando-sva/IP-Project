// js/app.js — Uni-Drive Academy v2
// localStorage-based, no server required
'use strict';

// ══════════════════════════════════════════════════
//  DATABASE (localStorage)
// ══════════════════════════════════════════════════
const DB_KEY = 'unidrive_db_v2';

function getDB() {
  const raw = localStorage.getItem(DB_KEY);
  if (raw) return JSON.parse(raw);
  const seed = {
    users: [
      { id:'user_admin', first_name:'Admin', last_name:'UniDrive',
        email:'admin@unidrive.ac.za', password:'admin123',
        role:'admin', student_number:'', phone:'031 907 7111',
        is_active:true, profile_pic:'', created_at:'2026-01-01T08:00:00.000Z' },
      { id:'user_thabo', first_name:'Thabo', last_name:'Mokoena',
        email:'thabo@mut.ac.za', password:'student123',
        role:'student', student_number:'220123456', phone:'0821234567',
        is_active:true, profile_pic:'', created_at:'2026-01-15T09:00:00.000Z' },
      { id:'user_naledi', first_name:'Naledi', last_name:'Dlamini',
        email:'naledi@mut.ac.za', password:'staff123',
        role:'staff', student_number:'', phone:'0731234567',
        is_active:true, profile_pic:'', created_at:'2026-01-20T10:00:00.000Z' },
    ],
    bookings: [
      { id:'bk001', user_id:'user_thabo',
        student_name:'Thabo Mokoena', student_email:'thabo@mut.ac.za',
        course_id:'code8', course_name:'Code 8 — Light Motor Vehicle',
        booking_date:'2026-06-10', booking_time:'09:00',
        total_price:2300, status:'confirmed', notes:'', paid:true,
        created_at:'2026-05-20T08:00:00.000Z' },
    ],
    enquiries: [
      { id:'enq001', name:'Siphamandla Ngcobo', email:'sngcobo@mut.ac.za',
        phone:'0798765432',
        message:'I would like to know more about the Code 10 programme.',
        status:'new', created_at:'2026-05-25T14:00:00.000Z' },
    ],
    testimonials: [
      { id:'rev001', user_id:'user_thabo', name:'Thabo Mokoena',
        msg:'Passed my Code 8 first time! The instructors are patient and thorough.',
        rating:5, is_approved:true, created_at:'2026-04-10T12:00:00.000Z' },
      { id:'rev002', user_id:'user_naledi', name:'Naledi Dlamini',
        msg:'Affordable, convenient, and professional. Highly recommend!',
        rating:5, is_approved:true, created_at:'2026-04-15T14:00:00.000Z' },
    ],
    testBookings: [],
    payments: [],
  };
  saveDB(seed);
  return seed;
}
function saveDB(db) { localStorage.setItem(DB_KEY, JSON.stringify(db)); }

const COURSES = {
  learners: { id:'learners', name:"Learner's Licence Prep",    price_student:800,  price_staff:1000, icon:'📋' },
  code8:    { id:'code8',    name:'Code 8 — Light Motor Vehicle', price_student:2300, price_staff:2800, icon:'🚗' },
  codeA:    { id:'codeA',    name:'Code A — Motorcycle',       price_student:2000, price_staff:2400, icon:'🏍️' },
  code10:   { id:'code10',   name:'Code 10 — Heavy Vehicle',   price_student:2500, price_staff:3000, icon:'🚛' },
  code14:   { id:'code14',   name:'Code 14 — Extra Heavy',     price_student:3000, price_staff:3500, icon:'🚚' },
  adaptive: { id:'adaptive', name:'Adaptive Driving',          price_student:1500, price_staff:1800, icon:'♿' },
};

// ══════════════════════════════════════════════════
//  STATE
// ══════════════════════════════════════════════════
let currentUser       = null;
let selectedRating    = 5;
let priceMode         = 'student';
let adminBookingsCache = [];
let adminUsersCache   = [];
let pageHistory       = [];  // back-button stack

// Payment flow state
let pendingBookingData = null; // holds booking details before payment

const SESSION_KEY = 'unidrive_sess_v2';

// ══════════════════════════════════════════════════
//  INIT
// ══════════════════════════════════════════════════
document.addEventListener('DOMContentLoaded', () => {
  checkAuth();
  setMinDate();
  goto('home');
});

// ══════════════════════════════════════════════════
//  ROUTER + BACK BUTTON
// ══════════════════════════════════════════════════
function goto(page, skipHistory) {
  const current = document.querySelector('.pg.active');
  const currentId = current ? current.id.replace('pg-', '') : null;

  document.querySelectorAll('.pg').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nl[data-p]').forEach(l =>
    l.classList.toggle('active', l.dataset.p === page));

  const el = document.getElementById('pg-' + page);
  if (el) el.classList.add('active');
  window.scrollTo({ top:0, behavior:'smooth' });
  document.getElementById('navLinks')?.classList.remove('open');

  // Push to history (skip for back-navigation and non-content pages)
  if (!skipHistory && currentId && currentId !== page &&
      !['pay-success'].includes(currentId)) {
    pageHistory.push(currentId);
    if (pageHistory.length > 15) pageHistory.shift();
  }

  const loaders = {
    home:       loadHome,      courses:     loadCourses,
    instructors:loadInstructors, book:      loadBookPage,
    faq:        loadFaq,       dashboard:   loadDashboard,
    admin:      loadAdmin,     learn:       loadLearn,
    sessions:   loadSessions,  mocktest:    loadMocktest,
    testbooking:loadTestBooking,
  };
  if (loaders[page]) loaders[page]();
}

function goBack() {
  const prev = pageHistory.pop();
  if (prev) goto(prev, true);
  else goto('home', true);
}

function toggleNav() {
  document.getElementById('navLinks').classList.toggle('open');
}

// ══════════════════════════════════════════════════
//  AUTH
// ══════════════════════════════════════════════════
function checkAuth() {
  const sess = localStorage.getItem(SESSION_KEY);
  if (sess) { try { currentUser = JSON.parse(sess); } catch { currentUser = null; } }
  renderNav();
}

function renderNav() {
  const area = document.getElementById('authArea');
  if (!currentUser) {
    area.innerHTML = `<a class="nl nav-cta" onclick="goto('login')">Login</a>`;
    return;
  }
  // Show profile pic or initials
  const initials = (currentUser.first_name[0] + currentUser.last_name[0]).toUpperCase();
  const dash = currentUser.role === 'admin' ? 'admin' : 'dashboard';
  const picHtml = currentUser.profile_pic
    ? `<img src="${currentUser.profile_pic}" style="width:27px;height:27px;border-radius:50%;object-fit:cover;border:2px solid var(--gold)"/>`
    : `<span class="nav-avatar">${initials}</span>`;
  area.innerHTML = `
    <a class="nl" onclick="goto('${dash}')" style="display:flex;align-items:center;gap:.5rem">
      ${picHtml}
      <span>${currentUser.first_name}</span>
    </a>
    <a class="nl logout-link" onclick="doLogout()">Logout</a>`;
}

function doLogin(e) {
  e.preventDefault();
  const msgEl = document.getElementById('loginMsg');
  clearMsg(msgEl);
  const email = document.getElementById('loginEmail').value.trim().toLowerCase();
  const pw    = document.getElementById('loginPw').value;
  const db    = getDB();
  const user  = db.users.find(u => u.email.toLowerCase() === email && u.password === pw);
  if (!user) { showMsg(msgEl, 'Invalid email or password.', 'error'); return; }
  if (!user.is_active) { showMsg(msgEl, 'Account deactivated. Contact admin.', 'error'); return; }
  currentUser = { ...user }; delete currentUser.password;
  localStorage.setItem(SESSION_KEY, JSON.stringify(currentUser));
  renderNav();
  toast(`Welcome back, ${user.first_name}! 🚗`, 'success');
  goto(user.role === 'admin' ? 'admin' : 'dashboard');
}

function doRegister(e) {
  e.preventDefault();
  const msgEl = document.getElementById('regMsg');
  clearMsg(msgEl);
  const first = document.getElementById('regFirst').value.trim();
  const last  = document.getElementById('regLast').value.trim();
  const email = document.getElementById('regEmail').value.trim().toLowerCase();
  const pw    = document.getElementById('regPw').value;
  const role  = document.getElementById('regRole').value;
  const sn    = document.getElementById('regSn')?.value?.trim() || '';
  const phone = document.getElementById('regPhone')?.value?.trim() || '';
  if (!first||!last||!email||!pw) { showMsg(msgEl,'Fill in all required fields.','error'); return; }
  if (pw.length < 6) { showMsg(msgEl,'Password must be at least 6 characters.','error'); return; }
  const db = getDB();
  if (db.users.find(u => u.email.toLowerCase() === email)) {
    showMsg(msgEl,'An account with this email already exists.','error'); return;
  }
  const newUser = { id:'user_'+Date.now(), first_name:first, last_name:last,
    email, password:pw, role, student_number:sn, phone,
    is_active:true, profile_pic:'', created_at:new Date().toISOString() };
  db.users.push(newUser); saveDB(db);
  currentUser = { ...newUser }; delete currentUser.password;
  localStorage.setItem(SESSION_KEY, JSON.stringify(currentUser));
  renderNav();
  toast(`Account created! Welcome, ${first}! 🎉`, 'success');
  goto('dashboard');
}

function doLogout() {
  currentUser = null; pendingBookingData = null;
  localStorage.removeItem(SESSION_KEY);
  pageHistory = [];
  renderNav(); goto('home');
  toast('Logged out.', 'info');
}

function fillLogin(email, pw) {
  document.getElementById('loginEmail').value = email;
  document.getElementById('loginPw').value    = pw;
}
function togglePw(id, btn) {
  const inp = document.getElementById(id);
  inp.type = inp.type === 'text' ? 'password' : 'text';
  btn.textContent = inp.type === 'text' ? '🙈' : '👁';
}
function toggleStudentFields() {
  const role = document.getElementById('regRole').value;
  const g = document.getElementById('regSnGroup');
  if (g) g.style.display = role === 'student' ? 'flex' : 'none';
}

// ══════════════════════════════════════════════════
//  HOME
// ══════════════════════════════════════════════════
function loadHome() {
  const db = getDB();
  const approved = db.testimonials.filter(t => t.is_approved);
  const el = document.getElementById('homeTestimonials');
  if (el && approved.length) {
    el.innerHTML = approved.map(t => `
      <div class="test-card">
        <div class="test-stars">${'★'.repeat(t.rating)}</div>
        <p class="test-msg">"${t.msg}"</p>
        <div class="test-name">— ${t.name}</div>
      </div>`).join('');
  }
}

// ══════════════════════════════════════════════════
//  COURSES
// ══════════════════════════════════════════════════
function loadCourses() { /* pre-rendered */ }

function setPriceMode(mode) {
  priceMode = mode;
  document.getElementById('ptStudent').classList.toggle('active', mode==='student');
  document.getElementById('ptStaff').classList.toggle('active', mode==='staff');
  const map = {
    learners:{student:'R 800', staff:'R 1 000'},
    code8:   {student:'R 2 300', staff:'R 2 800'},
    codeA:   {student:'R 2 000', staff:'R 2 400'},
    code10:  {student:'R 2 500', staff:'R 3 000'},
    code14:  {student:'R 3 000', staff:'R 3 500'},
    adaptive:{student:'R 1 500', staff:'R 1 800'},
  };
  document.querySelectorAll('.price-row strong').forEach((el,i) => {
    const keys = Object.keys(map);
    const cIdx = Math.floor(i/2);
    const isStaff = i%2===1;
    const key = keys[cIdx];
    if (key && map[key]) el.textContent = isStaff ? map[key].staff : map[key][mode];
  });
}

// Called from "Book This Course" button on the Courses page
function startCourseBooking(courseId, courseName, priceS, priceP) {
  if (!currentUser) { goto('login'); return; }
  goto('book');
  // Pre-select the course
  setTimeout(() => {
    const sel = document.getElementById('bkCourse');
    if (sel) { sel.value = courseId; updateBookingPrice(); }
  }, 200);
}

// ══════════════════════════════════════════════════
//  INSTRUCTORS
// ══════════════════════════════════════════════════
function loadInstructors() { /* pre-rendered */ }

// ══════════════════════════════════════════════════
//  BOOK PAGE
// ══════════════════════════════════════════════════
function loadBookPage() {
  if (!currentUser) {
    document.getElementById('bookGate').classList.remove('hidden');
    document.getElementById('bookContent').classList.add('hidden');
    return;
  }
  document.getElementById('bookGate').classList.add('hidden');
  document.getElementById('bookContent').classList.remove('hidden');
  checkActiveCourseNotice();
  loadMyBookings();
  setMinDate();
}

// Check if user already has an active (pending/confirmed) booking
function getActiveCourse() {
  if (!currentUser) return null;
  const db = getDB();
  return db.bookings.find(b =>
    b.user_id === currentUser.id && ['pending','confirmed'].includes(b.status)
  ) || null;
}

function checkActiveCourseNotice() {
  const active = getActiveCourse();
  const notice = document.getElementById('activeCourseNotice');
  const form   = document.getElementById('bookFormWrap');
  if (!notice) return;
  if (active) {
    document.getElementById('activeCourseNameDisplay').textContent = active.course_name;
    notice.classList.remove('hidden');
    if (form) form.classList.add('hidden');
  } else {
    notice.classList.add('hidden');
    if (form) form.classList.remove('hidden');
  }
}

function updateBookingPrice() {
  const sel = document.getElementById('bkCourse');
  const opt = sel.options[sel.selectedIndex];
  const box = document.getElementById('bkPriceBox');
  if (!sel.value) { box.classList.add('hidden'); return; }
  const isStaff = currentUser?.role === 'staff';
  const price = isStaff ? parseFloat(opt.dataset.pp) : parseFloat(opt.dataset.ps);
  document.getElementById('bkPriceAmt').textContent = `R ${price.toLocaleString()}`;
  box.classList.remove('hidden');
}

function setMinDate() {
  const today = new Date().toISOString().split('T')[0];
  ['bkDate','dbkDate'].forEach(id => {
    const el = document.getElementById(id); if(el) el.min = today;
  });
}

function loadTimeSlots() { buildSlots('bkDate','slotsWrapper','slotsGrid','bkTime'); }
function loadDashSlots()  { buildSlots('dbkDate','dbkSlotsWrapper','dbkSlotsGrid','dbkTime'); }

function buildSlots(dateId, wrapperId, gridId, hiddenId) {
  const date = document.getElementById(dateId).value;
  const wrap = document.getElementById(wrapperId);
  const grid = document.getElementById(gridId);
  document.getElementById(hiddenId).value = '';
  if (!date) { wrap.style.display='none'; return; }
  const slots = [];
  for (let h=8; h<=17; h++) {
    slots.push(`${String(h).padStart(2,'0')}:00`);
    if (h<17) slots.push(`${String(h).padStart(2,'0')}:30`);
  }
  grid.innerHTML = slots.map(t =>
    `<button type="button" class="slot-btn" onclick="selectSlot('${t}',this,'${hiddenId}')">${t}</button>`
  ).join('');
  wrap.style.display = 'block';
}

function selectSlot(time, btn, hiddenId) {
  btn.closest('.slots-grid').querySelectorAll('.slot-btn').forEach(b=>b.classList.remove('selected'));
  btn.classList.add('selected');
  document.getElementById(hiddenId).value = time;
}

// ── Booking → Payment flow ─────────────────────
function submitBooking(e) {
  e.preventDefault();
  const msgEl = document.getElementById('bookMsg');
  clearMsg(msgEl);
  goToPayment('bkCourse','bkDate','bkTime','bkNotes','bookMsg');
}

function submitDashBooking(e) {
  e.preventDefault();
  const msgEl = document.getElementById('dbkMsg');
  clearMsg(msgEl);
  goToPayment('dbkCourse','dbkDate','dbkTime','dbkNotes','dbkMsg');
}

function goToPayment(courseId, dateId, timeId, notesId, msgId) {
  const msgEl  = document.getElementById(msgId);
  const course = document.getElementById(courseId).value;
  const date   = document.getElementById(dateId).value;
  const time   = document.getElementById(timeId).value;
  const notes  = document.getElementById(notesId).value;

  if (!course) { showMsg(msgEl,'Please select a course.','error'); return; }
  if (!date)   { showMsg(msgEl,'Please select a date.','error'); return; }
  if (!time)   { showMsg(msgEl,'Please select a time slot.','error'); return; }

  const today = new Date().toISOString().split('T')[0];
  if (date < today) { showMsg(msgEl,'Date cannot be in the past.','error'); return; }

  // ONE COURSE AT A TIME check
  const active = getActiveCourse();
  if (active) {
    showMsg(msgEl, `You are already enrolled in "${active.course_name}". Cancel it first to book a new course.`, 'error');
    return;
  }

  const courseObj = COURSES[course];
  const price = currentUser.role === 'staff' ? courseObj.price_staff : courseObj.price_student;

  // Store pending booking data
  pendingBookingData = { course, courseObj, date, time, notes, price };

  // Navigate to payment page and populate it
  setupPaymentPage(pendingBookingData);
  goto('payment');
}

function setupPaymentPage(data) {
  const vat      = Math.round(data.price * 0.15);
  const total    = data.price + vat;
  const ref      = 'UDA-' + Date.now().toString(36).toUpperCase().slice(-8);

  setText('payCourse',   data.courseObj.name);
  setText('payIcon',     data.courseObj.icon);
  setText('payMeta',     `📅 ${data.date}   🕐 ${data.time}`);
  setText('paySubtotal', `R ${data.price.toLocaleString()}`);
  setText('payVat',      `R ${vat.toLocaleString()}`);
  setText('payTotal',    `R ${total.toLocaleString()}`);
  setText('eftRef',      ref);
  setText('eftAmount',   `R ${total.toLocaleString()}`);

  pendingBookingData._vat   = vat;
  pendingBookingData._total = total;
  pendingBookingData._ref   = ref;

  clearMsg(document.getElementById('payMsg'));
  clearMsg(document.getElementById('eftMsg'));
  // Switch to card tab by default
  switchPayTab('card', document.querySelector('.pay-tab'));
}

function setText(id, val) {
  const el = document.getElementById(id); if(el) el.textContent = val;
}

function switchPayTab(name, btn) {
  document.querySelectorAll('.pay-tab').forEach(t=>t.classList.remove('active'));
  document.querySelectorAll('.pay-tab-content').forEach(t=>t.classList.add('hidden'));
  if(btn) btn.classList.add('active');
  const panel = document.getElementById('pay-'+name);
  if(panel) panel.classList.remove('hidden');
}

// Card number formatting
function formatCardNum(input) {
  let v = input.value.replace(/\D/g,'').slice(0,16);
  input.value = v.replace(/(.{4})/g,'$1 ').trim();
  const icon = document.getElementById('cardTypeIcon');
  if (icon) {
    if (v.startsWith('4')) icon.textContent = '💳';
    else if (v.startsWith('5')) icon.textContent = '💳';
    else if (v.startsWith('3')) icon.textContent = '💳';
    else icon.textContent = '💳';
  }
}
function formatExpiry(input) {
  let v = input.value.replace(/\D/g,'').slice(0,4);
  if (v.length > 2) v = v.slice(0,2)+'/'+v.slice(2);
  input.value = v;
}

// Process card payment
function processPayment(e) {
  e.preventDefault();
  if (!pendingBookingData) { goto('book'); return; }
  const msgEl  = document.getElementById('payMsg');
  const btn    = document.getElementById('paySubmitBtn');
  clearMsg(msgEl);

  const name   = document.getElementById('payCardName').value.trim();
  const num    = document.getElementById('payCardNum').value.replace(/\s/g,'');
  const expiry = document.getElementById('payExpiry').value.trim();
  const cvv    = document.getElementById('payCvv').value.trim();

  if (!name) { showMsg(msgEl,'Please enter the cardholder name.','error'); return; }
  if (num.length < 13) { showMsg(msgEl,'Please enter a valid card number.','error'); return; }
  if (!expiry.match(/^\d{2}\/\d{2}$/)) { showMsg(msgEl,'Enter expiry as MM/YY.','error'); return; }
  if (cvv.length < 3) { showMsg(msgEl,'Please enter your CVV code.','error'); return; }

  // Simulate processing
  btn.textContent = '⏳ Processing…';
  btn.classList.add('loading');
  setTimeout(() => {
    btn.textContent = '🔒 Pay & Confirm Booking';
    btn.classList.remove('loading');
    confirmBookingAfterPayment('card');
  }, 2000);
}

function submitEft() {
  if (!pendingBookingData) { goto('book'); return; }
  const msgEl = document.getElementById('eftMsg');
  clearMsg(msgEl);
  showMsg(msgEl, '⏳ Submitting your EFT booking request…', 'info');
  setTimeout(() => {
    confirmBookingAfterPayment('eft');
  }, 1200);
}

function confirmBookingAfterPayment(method) {
  const d  = pendingBookingData;
  if (!d) return;
  const db = getDB();

  // Final one-course check
  const active = db.bookings.find(b =>
    b.user_id === currentUser.id && ['pending','confirmed'].includes(b.status)
  );
  if (active) {
    toast(`You are already enrolled in "${active.course_name}".`, 'error'); return;
  }

  const booking = {
    id: 'bk_' + Date.now(),
    user_id: currentUser.id,
    student_name: `${currentUser.first_name} ${currentUser.last_name}`,
    student_email: currentUser.email,
    course_id: d.course, course_name: d.courseObj.name,
    booking_date: d.date, booking_time: d.time,
    total_price: d.price, status: method==='eft' ? 'pending' : 'confirmed',
    notes: d.notes, paid: method==='card',
    payment_method: method, payment_ref: d._ref,
    created_at: new Date().toISOString(),
  };
  db.bookings.push(booking);

  // Save payment record
  db.payments = db.payments || [];
  db.payments.push({
    id: 'pay_'+Date.now(), booking_id: booking.id,
    user_id: currentUser.id, amount: d._total,
    method, ref: d._ref, status: method==='card'?'paid':'pending_eft',
    created_at: new Date().toISOString(),
  });
  saveDB(db);

  pendingBookingData = null;
  showPaymentSuccess(booking, d, method);
}

function showPaymentSuccess(booking, d, method) {
  const el = document.getElementById('successDetails');
  if (el) {
    el.innerHTML = `
      <div class="sd-row"><span>Course</span><span>${booking.course_name}</span></div>
      <div class="sd-row"><span>Date</span><span>${booking.booking_date}</span></div>
      <div class="sd-row"><span>Time</span><span>${booking.booking_time}</span></div>
      <div class="sd-row"><span>Reference</span><span>${d._ref}</span></div>
      <div class="sd-row"><span>Payment Method</span><span>${method === 'card' ? '💳 Card' : '🏦 EFT'}</span></div>
      <div class="sd-row"><span>Status</span><span>${method==='card' ? '✅ Confirmed' : '⏳ Pending EFT confirmation'}</span></div>
      <div class="sd-row"><span>Total Paid</span><span>R ${(d._total).toLocaleString()}</span></div>`;
  }
  goto('pay-success');
  toast('🎉 Booking confirmed!', 'success');
}

function loadMyBookings() {
  const db = getDB();
  const bookings = db.bookings
    .filter(b => b.user_id === currentUser?.id)
    .sort((a,b) => new Date(b.created_at)-new Date(a.created_at));

  const html = bookings.length
    ? bookings.map(b => `
        <div class="bk-item">
          <div class="bk-hdr">
            <div class="bk-course">${b.course_name}</div>
            <span class="badge badge-${b.status}">${b.status}</span>
          </div>
          <div class="bk-meta">📅 ${b.booking_date} &nbsp; 🕐 ${b.booking_time} &nbsp; 💰 R${b.total_price.toLocaleString()}</div>
          ${b.payment_method ? `<div class="bk-meta">💳 ${b.payment_method==='card'?'Card payment':'EFT'} · ${b.payment_ref||''}</div>` : ''}
          ${b.notes ? `<div class="bk-meta">📝 ${b.notes}</div>` : ''}
          ${['pending','confirmed'].includes(b.status) ? `
            <div style="margin-top:.65rem">
              <button class="btn btn-sm btn-red" onclick="cancelBooking('${b.id}')">Cancel</button>
            </div>` : ''}
        </div>`).join('')
    : '<p class="text-muted">No bookings yet. <a onclick="goto(\'book\')" style="color:var(--green);font-weight:700;cursor:pointer">Book a lesson →</a></p>';

  ['myBookingsList','dashBookingsList'].forEach(id => {
    const el = document.getElementById(id); if(el) el.innerHTML = html;
  });
  updateDashStats();
}

function cancelBooking(id) {
  if (!confirm('Cancel this booking?')) return;
  const db = getDB();
  const bk = db.bookings.find(b=>b.id===id);
  if (bk) { bk.status='cancelled'; saveDB(db); }
  toast('Booking cancelled.','info');
  loadMyBookings();
  checkActiveCourseNotice();
  checkDashActiveNotice();
}

function updateDashStats() {
  if (!currentUser) return;
  const db = getDB();
  const mine = db.bookings.filter(b=>b.user_id===currentUser.id);
  const set = (id,val)=>{ const el=document.getElementById(id); if(el) el.textContent=val; };
  set('stat-total',     mine.length);
  set('stat-pending',   mine.filter(b=>b.status==='pending').length);
  set('stat-confirmed', mine.filter(b=>b.status==='confirmed').length);
  set('stat-completed', mine.filter(b=>b.status==='completed').length);
  const recent = document.getElementById('dashRecentBookings');
  if (!recent) return;
  const last3 = mine.slice(0,3);
  recent.innerHTML = last3.length
    ? last3.map(b=>`
        <div class="bk-item">
          <div class="bk-hdr"><div class="bk-course">${b.course_name}</div><span class="badge badge-${b.status}">${b.status}</span></div>
          <div class="bk-meta">📅 ${b.booking_date} &nbsp; 🕐 ${b.booking_time}</div>
        </div>`).join('')
    : '<p class="text-muted">No bookings yet.</p>';
}

// ══════════════════════════════════════════════════
//  FAQ
// ══════════════════════════════════════════════════
function loadFaq() { /* pre-rendered */ }
function toggleAcc(i,btn) {
  btn.classList.toggle('open');
  document.getElementById('acc-'+i).classList.toggle('show');
}
function searchFaq() {
  const q = document.getElementById('faqInput').value.trim().toLowerCase();
  const res = document.getElementById('faqResults');
  if (!q) { res.classList.add('hidden'); return; }
  res.classList.remove('hidden');
  const faqs = [
    { q:'How do I register for a course?', a:'Create an account, log in, then navigate to "Book a Lesson" and select your course.' },
    { q:'What documents do I need?', a:'Valid ID or passport, student card (if MUT student), and any existing licence if upgrading.' },
    { q:'Can I cancel a booking?', a:'Yes, up to 24 hours before your lesson from your dashboard without penalty.' },
    { q:'Do you offer payment plans?', a:'Yes! Contact us to arrange a flexible payment schedule.' },
    { q:'How long does it take to get a licence?', a:'Code 8 takes ~25 lessons (3–6 months) depending on your progress and availability.' },
    { q:'Are there classes for disabled students?', a:'Yes! Our Adaptive Driving programme caters for students with physical disabilities.' },
    { q:'How do online classes work?', a:'Book a session, receive a Microsoft Teams link by email, and join from your phone or laptop.' },
    { q:'How do I pay for lessons?', a:'After selecting your course and time slot, you can pay by card or EFT through our secure payment page.' },
  ];
  const results = faqs.filter(f=>f.q.toLowerCase().includes(q)||f.a.toLowerCase().includes(q));
  res.innerHTML = results.length
    ? results.map(r=>`<div class="faq-result-card"><div class="faq-rq">❓ ${r.q}</div><div class="faq-ra">✅ ${r.a}</div></div>`).join('')
    : `<div class="faq-no-result">No results for "<strong>${q}</strong>". Try: cancel, payment, online, documents.</div>`;
}

// ══════════════════════════════════════════════════
//  CONTACT
// ══════════════════════════════════════════════════
function submitEnquiry(e) {
  e.preventDefault();
  const msgEl = document.getElementById('contactMsg');
  clearMsg(msgEl);
  const db = getDB();
  db.enquiries.push({
    id: 'enq_'+Date.now(), name:document.getElementById('cName').value,
    email:document.getElementById('cEmail').value, phone:document.getElementById('cPhone').value,
    message:document.getElementById('cMsg').value, status:'new', created_at:new Date().toISOString()
  });
  saveDB(db);
  showMsg(msgEl,'✅ Message sent! We will respond within 1–2 business days.','success');
  e.target.reset(); toast('Message sent!','success');
}

// ══════════════════════════════════════════════════
//  CUSTOMER DASHBOARD
// ══════════════════════════════════════════════════
function loadDashboard() {
  if (!currentUser) { goto('login'); return; }
  const set = (id,v)=>{ const e=document.getElementById(id); if(e) e.textContent=v; };
  set('dashTitle', `Welcome, ${currentUser.first_name}!`);
  set('dashSub', `${currentUser.role==='staff'?'Staff':'Student'} Portal`);
  renderDashUserInfo();
  loadMyBookings();
  loadProfileForm();
  setMinDate();
  checkDashActiveNotice();
  // Quick actions
  const qa = document.getElementById('qaGrid');
  if (qa) qa.innerHTML = `
    <button class="qa-btn" onclick="goto('book')">📅 Book a Lesson</button>
    <button class="qa-btn" onclick="goto('courses')">📚 View Courses</button>
    <button class="qa-btn" onclick="goto('learn')">📖 Study Materials</button>
    <button class="qa-btn" onclick="goto('sessions')">🎓 Online Classes</button>
    <button class="qa-btn" onclick="goto('mocktest')">📝 Mock Test</button>
    <button class="qa-btn" onclick="goto('testbooking')">🏛️ Book Official Test</button>
    <button class="qa-btn" onclick="goto('faq')">❓ FAQ</button>
    <button class="qa-btn" onclick="goto('contact')">📞 Contact Us</button>`;
}

function renderDashUserInfo() {
  const dsUser = document.getElementById('dsUserInfo');
  if (!dsUser || !currentUser) return;
  const initials = (currentUser.first_name[0]+currentUser.last_name[0]).toUpperCase();
  const picHtml = currentUser.profile_pic
    ? `<img src="${currentUser.profile_pic}" style="width:36px;height:36px;border-radius:50%;object-fit:cover;border:2px solid rgba(255,255,255,.3)"/>`
    : `<div class="nav-avatar" style="width:36px;height:36px;font-size:.9rem">${initials}</div>`;
  dsUser.innerHTML = `
    <div style="display:flex;align-items:center;gap:.6rem;margin-bottom:.25rem">
      ${picHtml}
      <div>
        <div class="du-name">${currentUser.first_name} ${currentUser.last_name}</div>
        <div class="du-role">${currentUser.role}</div>
      </div>
    </div>
    ${currentUser.student_number?`<div style="font-size:.72rem;color:rgba(255,255,255,.35)">SN: ${currentUser.student_number}</div>`:''}`;
}

function checkDashActiveNotice() {
  const active  = getActiveCourse();
  const notice  = document.getElementById('dashActiveNotice');
  const form    = document.getElementById('dashBookFormWrap');
  if (!notice) return;
  if (active) {
    document.getElementById('dashActiveName').textContent = active.course_name;
    notice.classList.remove('hidden');
    if (form) form.classList.add('hidden');
  } else {
    notice.classList.add('hidden');
    if (form) form.classList.remove('hidden');
  }
}

function loadProfileForm() {
  if (!currentUser) return;
  const s = (id,v)=>{ const e=document.getElementById(id); if(e) e.value=v||''; };
  s('pFirst',currentUser.first_name); s('pLast',currentUser.last_name);
  s('pEmail',currentUser.email);      s('pPhone',currentUser.phone);
  s('pSn',currentUser.student_number);
  if (currentUser.role!=='student') {
    const g=document.getElementById('pSnGroup'); if(g) g.style.display='none';
  }
  // Profile picture
  updateProfilePicDisplay();
}

function updateProfilePicDisplay() {
  const display  = document.getElementById('profilePicDisplay');
  const img      = document.getElementById('profilePicImg');
  const initials = document.getElementById('profilePicInitials');
  const removeBtn= document.getElementById('removePicBtn');
  if (!display) return;
  const ini = (currentUser.first_name[0]+currentUser.last_name[0]).toUpperCase();
  if (currentUser.profile_pic) {
    if (img) { img.src=currentUser.profile_pic; img.style.display='block'; }
    if (initials) initials.style.display='none';
    if (removeBtn) removeBtn.style.display='inline-flex';
  } else {
    if (img) img.style.display='none';
    if (initials) { initials.textContent=ini; initials.style.display='block'; }
    if (removeBtn) removeBtn.style.display='none';
  }
}

function uploadProfilePic(input) {
  const file = input.files[0];
  if (!file) return;
  if (file.size > 2*1024*1024) { toast('Image too large. Max 2MB.','error'); return; }
  const reader = new FileReader();
  reader.onload = function(ev) {
    const dataUrl = ev.target.result;
    const db = getDB();
    const user = db.users.find(u=>u.id===currentUser.id);
    if (user) { user.profile_pic = dataUrl; saveDB(db); }
    currentUser.profile_pic = dataUrl;
    localStorage.setItem(SESSION_KEY, JSON.stringify(currentUser));
    updateProfilePicDisplay();
    renderNav();
    renderDashUserInfo();
    toast('Profile photo updated! 🎉','success');
  };
  reader.readAsDataURL(file);
}

function removeProfilePic() {
  const db = getDB();
  const user = db.users.find(u=>u.id===currentUser.id);
  if (user) { user.profile_pic=''; saveDB(db); }
  currentUser.profile_pic='';
  localStorage.setItem(SESSION_KEY, JSON.stringify(currentUser));
  updateProfilePicDisplay();
  renderNav();
  renderDashUserInfo();
  toast('Profile photo removed.','info');
  document.getElementById('profilePicInput').value='';
}

function updateProfile(e) {
  e.preventDefault();
  const msgEl = document.getElementById('profileMsg');
  clearMsg(msgEl);
  const db   = getDB();
  const user = db.users.find(u=>u.id===currentUser.id);
  if (!user) { showMsg(msgEl,'User not found.','error'); return; }
  user.first_name     = document.getElementById('pFirst').value.trim();
  user.last_name      = document.getElementById('pLast').value.trim();
  user.phone          = document.getElementById('pPhone').value.trim();
  user.student_number = document.getElementById('pSn').value.trim();
  saveDB(db);
  currentUser = { ...user }; delete currentUser.password;
  localStorage.setItem(SESSION_KEY, JSON.stringify(currentUser));
  renderNav(); renderDashUserInfo(); updateProfilePicDisplay();
  showMsg(msgEl,'✅ Profile updated!','success'); toast('Profile saved!','success');
}

function changePassword(e) {
  e.preventDefault();
  const msgEl = document.getElementById('pwMsg');
  clearMsg(msgEl);
  const cur  = document.getElementById('pwCur').value;
  const nw   = document.getElementById('pwNew').value;
  const conf = document.getElementById('pwConf').value;
  if (nw !== conf) { showMsg(msgEl,'Passwords do not match.','error'); return; }
  if (nw.length < 6) { showMsg(msgEl,'Min 6 characters.','error'); return; }
  const db   = getDB();
  const user = db.users.find(u=>u.id===currentUser.id);
  if (!user||user.password!==cur) { showMsg(msgEl,'Current password is incorrect.','error'); return; }
  user.password = nw; saveDB(db);
  showMsg(msgEl,'✅ Password updated!','success'); e.target.reset();
}

function dashTab(name, btn) {
  document.querySelectorAll('.dash-sidebar .dtab').forEach(b=>b.classList.remove('active'));
  document.querySelectorAll('#pg-dashboard .dtab-panel').forEach(p=>p.classList.add('hidden'));
  if(btn) btn.classList.add('active');
  const panel = document.getElementById('dtab-'+name);
  if(panel) panel.classList.remove('hidden');
  if (name==='bookings')  { loadMyBookings(); }
  if (name==='book-new')  { setMinDate(); checkDashActiveNotice(); }
  if (name==='profile')   { loadProfileForm(); }
}

function setRating(r) {
  selectedRating = r;
  document.querySelectorAll('.star').forEach((s,i)=>s.classList.toggle('active',i<r));
}
function submitReview(e) {
  e.preventDefault();
  const msgEl = document.getElementById('reviewStatus');
  clearMsg(msgEl);
  const msg = document.getElementById('reviewMsg').value.trim();
  if (!msg) { showMsg(msgEl,'Please write something.','error'); return; }
  const db = getDB();
  db.testimonials.push({
    id:'rev_'+Date.now(), user_id:currentUser.id,
    name:`${currentUser.first_name} ${currentUser.last_name}`,
    msg, rating:selectedRating, is_approved:false, created_at:new Date().toISOString()
  });
  saveDB(db);
  showMsg(msgEl,'✅ Thank you! Review is pending approval.','success');
  e.target.reset(); setRating(5);
}

function updateDashPrice() {
  const sel = document.getElementById('dbkCourse');
  const opt = sel.options[sel.selectedIndex];
  const box = document.getElementById('dbkPriceBox');
  if (!sel.value) { box.classList.add('hidden'); return; }
  const isStaff = currentUser?.role==='staff';
  const price = isStaff ? parseFloat(opt.dataset.pp) : parseFloat(opt.dataset.ps);
  document.getElementById('dbkPriceAmt').textContent = `R ${price.toLocaleString()}`;
  box.classList.remove('hidden');
}

// ══════════════════════════════════════════════════
//  ADMIN DASHBOARD
// ══════════════════════════════════════════════════
function loadAdmin() {
  if (!currentUser || currentUser.role !== 'admin') { goto('login'); return; }
  const ai = document.getElementById('adminUserInfo');
  if (ai) ai.innerHTML = `<div class="du-name">${currentUser.first_name} ${currentUser.last_name}</div><div class="du-role">Administrator</div>`;
  loadAdminStats();
}

function loadAdminStats() {
  const db = getDB();
  const stats = {
    total_users:       db.users.length,
    total_students:    db.users.filter(u=>u.role==='student').length,
    total_staff:       db.users.filter(u=>u.role==='staff').length,
    total_bookings:    db.bookings.length,
    pending_bookings:  db.bookings.filter(b=>b.status==='pending').length,
    confirmed_bookings:db.bookings.filter(b=>b.status==='confirmed').length,
    new_enquiries:     db.enquiries.filter(e=>e.status==='new').length,
    total_revenue:     db.bookings.filter(b=>['confirmed','completed'].includes(b.status)).reduce((s,b)=>s+b.total_price,0),
  };
  document.getElementById('adminStats').innerHTML = [
    ['Total Users',    stats.total_users,             '#1a2744'],
    ['Students',       stats.total_students,           '#1a6b3a'],
    ['Staff',          stats.total_staff,              '#5a6b5a'],
    ['Pending',        stats.pending_bookings,         '#c8a030'],
    ['Confirmed',      stats.confirmed_bookings,       '#1a6b3a'],
    ['All Bookings',   stats.total_bookings,           '#1a2744'],
    ['New Enquiries',  stats.new_enquiries,            '#dc2626'],
    ['Revenue',        'R '+stats.total_revenue.toLocaleString(),'#1a6b3a'],
  ].map(([l,v,c])=>`<div class="ast"><div class="ast-label">${l}</div><div class="ast-val" style="color:${c}">${v}</div></div>`).join('');

  const recent = db.bookings.slice(-5).reverse();
  document.getElementById('adminRecentBk').innerHTML = recent.length
    ? `<div class="table-wrap"><table class="data-table">
        <thead><tr><th>Student</th><th>Course</th><th>Date</th><th>Status</th><th>Price</th></tr></thead>
        <tbody>${recent.map(b=>`<tr>
          <td><strong>${b.student_name}</strong></td>
          <td>${b.course_name}</td>
          <td>${b.booking_date}</td>
          <td><span class="badge badge-${b.status}">${b.status}</span></td>
          <td>R${b.total_price.toLocaleString()}</td>
        </tr>`).join('')}</tbody></table></div>`
    : '<p class="text-muted">No bookings yet.</p>';
}

function loadAdminBookings() {
  const db = getDB();
  adminBookingsCache = [...db.bookings].sort((a,b)=>new Date(b.created_at)-new Date(a.created_at));
  renderAdminBookings(adminBookingsCache);
}
function renderAdminBookings(bookings) {
  const tbody = document.getElementById('adminBkBody');
  if (!bookings.length) { tbody.innerHTML='<tr><td colspan="8" class="tbl-empty">No bookings.</td></tr>'; return; }
  tbody.innerHTML = bookings.map(b=>`
    <tr>
      <td style="font-family:monospace;font-size:.75rem">${b.id.slice(-6)}</td>
      <td><strong>${b.student_name}</strong><span class="tbl-sub">${b.student_email}</span></td>
      <td>${b.course_name}</td>
      <td>${b.booking_date}</td>
      <td>${b.booking_time}</td>
      <td>R${b.total_price.toLocaleString()}</td>
      <td><span class="badge badge-${b.status}">${b.status}</span></td>
      <td class="tbl-actions">
        ${b.status==='pending'?`<button class="btn btn-xs btn-green" onclick="adminBkStatus('${b.id}','confirmed')">✅</button>`:''}
        ${['pending','confirmed'].includes(b.status)?`<button class="btn btn-xs btn-red" onclick="adminBkStatus('${b.id}','cancelled')">❌</button>`:''}
        ${b.status==='confirmed'?`<button class="btn btn-xs btn-ghost" onclick="adminBkStatus('${b.id}','completed')">✔</button>`:''}
      </td>
    </tr>`).join('');
}
function filterAdminBookings() {
  const q = document.getElementById('bkSearch').value.toLowerCase();
  renderAdminBookings(adminBookingsCache.filter(b=>
    b.student_name.toLowerCase().includes(q)||b.course_name.toLowerCase().includes(q)||
    b.status.includes(q)||b.booking_date.includes(q)
  ));
}
function adminBkStatus(id, status) {
  const db=getDB(); const bk=db.bookings.find(b=>b.id===id);
  if(bk){bk.status=status;saveDB(db);}
  toast(`Booking ${status}.`,'success'); loadAdminBookings(); loadAdminStats();
}

function loadAdminUsers() {
  const db=getDB();
  adminUsersCache=[...db.users].sort((a,b)=>new Date(b.created_at)-new Date(a.created_at));
  renderAdminUsers(adminUsersCache);
}
function renderAdminUsers(users) {
  const tbody=document.getElementById('adminUsersBody');
  if(!users.length){tbody.innerHTML='<tr><td colspan="7" class="tbl-empty">No users.</td></tr>';return;}
  tbody.innerHTML = users.map(u=>`
    <tr>
      <td>
        <div style="display:flex;align-items:center;gap:.6rem">
          ${u.profile_pic ? `<img src="${u.profile_pic}" style="width:28px;height:28px;border-radius:50%;object-fit:cover"/>` :
            `<div style="width:28px;height:28px;border-radius:50%;background:var(--navy);color:#fff;font-size:.7rem;font-weight:800;display:flex;align-items:center;justify-content:center">${(u.first_name[0]+u.last_name[0]).toUpperCase()}</div>`}
          <strong>${u.first_name} ${u.last_name}</strong>
        </div>
      </td>
      <td>${u.email}</td>
      <td><span class="role-badge role-${u.role}">${u.role}</span></td>
      <td>${u.student_number||'—'}</td>
      <td class="tbl-sub">${(u.created_at||'').substring(0,10)}</td>
      <td>${u.is_active?'<span style="color:var(--green);font-weight:700">Active</span>':'<span style="color:var(--red);font-weight:700">Inactive</span>'}</td>
      <td>${u.role!=='admin'?`<button class="btn btn-xs btn-ghost" onclick="toggleUser('${u.id}')">${u.is_active?'Deactivate':'Activate'}</button>`:'—'}</td>
    </tr>`).join('');
}
function filterAdminUsers() {
  const q=document.getElementById('userSearch').value.toLowerCase();
  renderAdminUsers(adminUsersCache.filter(u=>
    `${u.first_name} ${u.last_name}`.toLowerCase().includes(q)||u.email.toLowerCase().includes(q)||u.role.includes(q)
  ));
}
function toggleUser(id) {
  const db=getDB(); const user=db.users.find(u=>u.id===id);
  if(user){user.is_active=!user.is_active;saveDB(db);}
  toast(`User ${user.is_active?'activated':'deactivated'}.`,'info'); loadAdminUsers();
}

function loadAdminEnquiries() {
  const db=getDB();
  const el=document.getElementById('adminEnqList');
  const enquiries=[...db.enquiries].sort((a,b)=>new Date(b.created_at)-new Date(a.created_at));
  if(!enquiries.length){el.innerHTML='<p class="text-muted">No enquiries yet.</p>';return;}
  el.innerHTML=enquiries.map(eq=>`
    <div class="enq-card">
      <div class="enq-hdr">
        <div><strong>${eq.name}</strong><span class="tbl-sub">${eq.email}${eq.phone?' · '+eq.phone:''}</span></div>
        <div style="display:flex;gap:.5rem;align-items:center">
          <span class="badge badge-${eq.status==='new'?'pending':'confirmed'}">${eq.status}</span>
          ${eq.status==='new'?`<button class="btn btn-xs btn-ghost" onclick="markEnquiry('${eq.id}','read')">Mark Read</button>`:''}
        </div>
      </div>
      <p style="font-size:.88rem;color:var(--muted);margin:.4rem 0">${eq.message}</p>
      <div class="tbl-sub">${(eq.created_at||'').substring(0,10)}</div>
    </div>`).join('');
}
function markEnquiry(id,status) {
  const db=getDB(); const eq=db.enquiries.find(e=>e.id===id);
  if(eq){eq.status=status;saveDB(db);} loadAdminEnquiries(); loadAdminStats();
}

function loadAdminReviews() {
  const db=getDB();
  const el=document.getElementById('adminRevList');
  const all=[...db.testimonials].sort((a,b)=>new Date(b.created_at)-new Date(a.created_at));
  if(!all.length){el.innerHTML='<p class="text-muted">No reviews yet.</p>';return;}
  el.innerHTML=all.map(t=>`
    <div class="bk-item">
      <div class="bk-hdr">
        <strong>${t.name}</strong>
        <div style="display:flex;align-items:center;gap:.75rem">
          <span style="color:var(--gold)">${'★'.repeat(t.rating)}</span>
          ${t.is_approved?`<span style="color:var(--green);font-size:.8rem;font-weight:700">✅ Approved</span>`:`<span style="background:#fef3c7;color:#92400e;padding:.15rem .5rem;border-radius:99px;font-size:.72rem;font-weight:700">Pending</span>`}
        </div>
      </div>
      <p style="font-size:.88rem;color:var(--muted);margin:.4rem 0">${t.msg}</p>
      <div style="display:flex;gap:.5rem;margin-top:.6rem">
        ${!t.is_approved?`<button class="btn btn-sm btn-primary" onclick="approveReview('${t.id}')">✅ Approve</button>`:''}
        <button class="btn btn-sm btn-red" onclick="deleteReview('${t.id}')">🗑 Delete</button>
      </div>
    </div>`).join('');
}
function approveReview(id) {
  const db=getDB(); const t=db.testimonials.find(r=>r.id===id);
  if(t){t.is_approved=true;saveDB(db);} toast('Approved!','success'); loadAdminReviews(); loadHome();
}
function deleteReview(id) {
  if(!confirm('Delete this review?')) return;
  const db=getDB(); db.testimonials=db.testimonials.filter(r=>r.id!==id); saveDB(db);
  toast('Deleted.','info'); loadAdminReviews();
}

function adminTab(name,btn) {
  document.querySelectorAll('.admin-sidebar .dtab').forEach(b=>b.classList.remove('active'));
  document.querySelectorAll('#pg-admin .dtab-panel').forEach(p=>p.classList.add('hidden'));
  if(btn) btn.classList.add('active');
  const panel=document.getElementById('atab-'+name);
  if(panel) panel.classList.remove('hidden');
  const loaders={stats:loadAdminStats,bookings:loadAdminBookings,users:loadAdminUsers,enquiries:loadAdminEnquiries,reviews:loadAdminReviews};
  if(loaders[name]) loaders[name]();
}

// ══════════════════════════════════════════════════
//  STUDY MATERIALS
// ══════════════════════════════════════════════════
function loadLearn() { learnTab('signs', document.querySelector('.ltab')); }
function learnTab(name,btn) {
  document.querySelectorAll('.ltab').forEach(b=>b.classList.remove('active'));
  document.querySelectorAll('.ltab-content').forEach(c=>c.classList.add('hidden'));
  if(btn) btn.classList.add('active');
  const el=document.getElementById('lc-'+name); if(el) el.classList.remove('hidden');
}

// ══════════════════════════════════════════════════
//  ONLINE SESSIONS (CLASSES PAGE)
// ══════════════════════════════════════════════════
function loadSessions() {
  const gate    = document.getElementById('sessionsGate');
  const content = document.getElementById('sessionsContent');
  if (!currentUser) { gate.classList.remove('hidden'); content.classList.add('hidden'); return; }
  gate.classList.add('hidden'); content.classList.remove('hidden');
  renderTodaySchedule();
  renderUpcomingList();
  renderRecordedSessions();
}

const LIVE_SESSIONS = [
  { time:'08:00', ampm:'AM', title:"K53 Theory — Road Signs & Rules", instructor:"Ms. Nompumelelo Zulu", status:'live',
    link:'https://teams.microsoft.com/l/meetup-join/DEMO_THEORY_001' },
  { time:'10:00', ampm:'AM', title:'Code 8 Pre-Lesson Briefing', instructor:'Mr. Sipho Mkhize', status:'upcoming',
    link:'https://teams.microsoft.com/l/meetup-join/DEMO_CODE8_001' },
  { time:'13:00', ampm:'PM', title:'Adaptive Driving Q&A Session', instructor:'Mr. Bongani Ndlela', status:'upcoming',
    link:'https://teams.microsoft.com/l/meetup-join/DEMO_ADAPTIVE_001' },
  { time:'15:30', ampm:'PM', title:'Mock Test Preparation & Tips', instructor:'Ms. Nompumelelo Zulu', status:'upcoming',
    link:'https://teams.microsoft.com/l/meetup-join/DEMO_MOCK_001' },
];

const UPCOMING_SESSIONS = [
  { dow:'Mon', day:'09', title:'K53 Road Signs Deep Dive', instructor:'Ms. N. Zulu', time:'09:00–10:30', link:'https://teams.microsoft.com/l/meetup-join/DEMO_SIGNS_002' },
  { dow:'Tue', day:'10', title:'Vehicle Controls & K53 Manoeuvres', instructor:'Mr. S. Mkhize', time:'10:00–11:30', link:'https://teams.microsoft.com/l/meetup-join/DEMO_CTRL_002' },
  { dow:'Wed', day:'11', title:'Rules of the Road — Intersections', instructor:'Mr. B. Ndlela', time:'14:00–15:30', link:'https://teams.microsoft.com/l/meetup-join/DEMO_RULES_002' },
  { dow:'Thu', day:'12', title:'Full Mock Test + Review Session', instructor:'Ms. N. Zulu', time:'09:00–11:00', link:'https://teams.microsoft.com/l/meetup-join/DEMO_FULL_002' },
  { dow:'Fri', day:'13', title:'Code 10 Heavy Vehicle Theory', instructor:'Mr. S. Mkhize', time:'13:00–14:30', link:'https://teams.microsoft.com/l/meetup-join/DEMO_C10_002' },
];

const RECORDED_SESSIONS_DATA = [
  { id:'rec1', title:'Introduction to K53 — What to Expect', icon:'🎬', color:'#dbeafe', sub:'45 min · Recorded Jun 1', instructor:'Ms. N. Zulu',
    desc:'Overview of the K53 learner\'s test format, what chapters are covered, and how to prepare.' },
  { id:'rec2', title:'Road Signs Masterclass — All 3 Categories', icon:'🚦', color:'#fee2e2', sub:'60 min · Recorded Jun 2', instructor:'Ms. N. Zulu',
    desc:'Complete walkthrough of regulatory, warning, and informatory signs with examples.' },
  { id:'rec3', title:'Rules of the Road — Right of Way', icon:'🛣️', color:'#dcfce7', sub:'40 min · Recorded Jun 3', instructor:'Mr. S. Mkhize',
    desc:'Right of way at uncontrolled intersections, 4-way stops, roundabouts, and emergency vehicles.' },
  { id:'rec4', title:'Vehicle Controls & MSM Routine', icon:'🎛️', color:'#ede9fe', sub:'55 min · Recorded Jun 4', instructor:'Mr. B. Ndlela',
    desc:'Mirror-Signal-Manoeuvre, blind spots, clutch control, hill starts, and K53 yard manoeuvres.' },
  { id:'rec5', title:'Code 8 Practical Demonstration', icon:'🚗', color:'#fef9c3', sub:'50 min · Recorded Jun 5', instructor:'Mr. S. Mkhize',
    desc:'On-road demonstration of K53 driving test route with commentary on scoring and common mistakes.' },
  { id:'rec6', title:'Adaptive Driving — Info Session', icon:'♿', color:'#f0fdf4', sub:'35 min · Recorded Jun 3', instructor:'Mr. B. Ndlela',
    desc:'Information for students requiring adaptive driving training: available vehicles, assessment, enrolment.' },
];

function renderTodaySchedule() {
  const grid = document.getElementById('todaySchedule');
  if (!grid) return;
  grid.innerHTML = LIVE_SESSIONS.map(s => `
    <div class="schedule-card">
      <div class="sc-time-badge">
        <div class="sc-time">${s.time}</div>
        <div class="sc-ampm">${s.ampm}</div>
      </div>
      <div class="sc-body">
        <h4>${s.title}</h4>
        <div class="sc-instructor">👩‍🏫 ${s.instructor}</div>
        <a class="sc-join-btn ${s.status}" href="${s.link}" target="_blank" onclick="return confirmJoin()">
          ${s.status==='live' ? '🔴 Join Live' : '🔗 Join Session'}
        </a>
      </div>
    </div>`).join('');
}

function renderUpcomingList() {
  const list = document.getElementById('upcomingList');
  if (!list) return;
  list.innerHTML = UPCOMING_SESSIONS.map(s => `
    <div class="upcoming-item">
      <div class="ui-left">
        <div class="ui-day">
          <div class="ud-day">${s.day}</div>
          <div class="ud-dow">${s.dow}</div>
        </div>
        <div class="ui-info">
          <h4>${s.title}</h4>
          <p>👩‍🏫 ${s.instructor} &nbsp; 🕐 ${s.time}</p>
        </div>
      </div>
      <a class="sc-join-btn upcoming" href="${s.link}" target="_blank" onclick="return confirmJoin()">Register / Join</a>
    </div>`).join('');
}

function renderRecordedSessions() {
  const prog = getSessionProgress();
  const grid = document.getElementById('sessionsGrid');
  if (!grid) return;
  grid.innerHTML = RECORDED_SESSIONS_DATA.map(s => {
    const done = prog[s.id];
    return `
      <div class="sess-card ${done?'completed':''}" onclick="openSession('${s.id}')">
        <div class="sess-hdr">
          <div class="sess-icon" style="background:${s.color}">${s.icon}</div>
          <div class="sess-meta">
            <div class="sess-title">${s.title}</div>
            <div class="sess-sub">${s.sub}</div>
          </div>
          <span class="sess-status ${done?'done':'todo'}">${done?'✅ Done':'▶ Watch'}</span>
        </div>
        <div class="sess-body">
          <div class="sess-progress"><div class="sess-pbar" style="width:${done?100:0}%"></div></div>
          <p class="sess-desc">${s.desc}</p>
          <button class="btn btn-primary sess-btn">${done?'🔄 Watch Again':'▶ Watch Recording'}</button>
        </div>
      </div>`;
  }).join('');
}

function confirmJoin() {
  toast('Opening Microsoft Teams meeting link…','info');
  return true;
}

function getSessionProgress() {
  const raw = localStorage.getItem('unidrive_sess_prog_'+(currentUser?.id||''));
  return raw ? JSON.parse(raw) : {};
}
function saveSessionProgress(p) {
  localStorage.setItem('unidrive_sess_prog_'+currentUser.id, JSON.stringify(p));
}

function openSession(id) {
  const s = RECORDED_SESSIONS_DATA.find(x=>x.id===id);
  if (!s) return;
  document.getElementById('sessionModalTitle').textContent = s.icon+' '+s.title;
  document.getElementById('sessionModalBody').innerHTML = `
    <div style="padding:1.4rem">
      <div style="background:${s.color};border-radius:var(--radius);padding:1.1rem 1.25rem;margin-bottom:1.25rem;display:flex;align-items:flex-start;gap:.85rem">
        <span style="font-size:2rem">${s.icon}</span>
        <div>
          <div style="font-weight:700;font-size:1rem;margin-bottom:.2rem">${s.title}</div>
          <div style="font-size:12.5px;color:var(--muted)">👩‍🏫 ${s.instructor} &nbsp; 🕐 ${s.sub}</div>
        </div>
      </div>
      <p style="font-size:13.5px;color:var(--muted);margin-bottom:1.5rem">${s.desc}</p>

      <div style="background:#0a1930;border-radius:var(--radius);padding:2.5rem;text-align:center;margin-bottom:1.25rem;border:1px solid rgba(255,255,255,.1)">
        <div style="font-size:3.5rem;margin-bottom:.75rem">▶</div>
        <div style="color:#fff;font-weight:700;margin-bottom:.4rem">Recorded Class Playback</div>
        <div style="color:rgba(255,255,255,.5);font-size:12.5px;margin-bottom:1.2rem">${s.sub}</div>
        <a href="https://teams.microsoft.com/l/meetup-join/DEMO_RECORDING_${id}" target="_blank"
           class="btn btn-gold" onclick="markSessionComplete('${id}');return true;">
          ▶ Watch via Microsoft Teams
        </a>
      </div>
      <div style="background:var(--off);border-radius:var(--radius);padding:.85rem 1rem;margin-bottom:1rem;font-size:13px;color:var(--muted)">
        📌 <strong>Note:</strong> This is a simulated demo link. In the live system, clicking this would open the actual Teams recording from your instructor's session.
      </div>
      <button class="btn btn-primary btn-full" onclick="markSessionComplete('${id}')">✅ Mark as Watched</button>
    </div>`;
  document.getElementById('sessionModal').classList.remove('hidden');
  document.body.style.overflow = 'hidden';
}

function markSessionComplete(id) {
  const prog = getSessionProgress(); prog[id]=true; saveSessionProgress(prog);
  renderRecordedSessions();
  toast('Session marked as watched! ✅','success');
}
function closeSessionModal() {
  document.getElementById('sessionModal').classList.add('hidden');
  document.body.style.overflow='';
}

// ══════════════════════════════════════════════════
//  MOCK TEST (full 68-question K53 engine)
// ══════════════════════════════════════════════════
function loadMocktest() {
  const gate=document.getElementById('mocktestGate');
  const content=document.getElementById('mocktestContent');
  if (!currentUser) { gate.classList.remove('hidden'); content.classList.add('hidden'); return; }
  gate.classList.add('hidden'); content.classList.remove('hidden');
  showMtHistory(); showSection('mt-start');
}

const MOCK_QUESTIONS = [
  {cat:'Road Signs',q:'A red octagonal STOP sign means:',opts:['Slow down and look both ways','Come to a complete stop and yield','Stop if other vehicles are present','Reduce speed to 20 km/h'],a:1},
  {cat:'Road Signs',q:'A red circle with a white horizontal bar means:',opts:['Max speed limit','No entry for vehicles','No stopping','Yield to oncoming traffic'],a:1},
  {cat:'Road Signs',q:'A yellow diamond-shaped sign indicates:',opts:['A mandatory instruction','A warning of hazard ahead','A speed limit','An information guide'],a:1},
  {cat:'Road Signs',q:'A round blue sign with a white arrow pointing right means:',opts:['You may turn right','You MUST turn right','No right turn','Right lane ends'],a:1},
  {cat:'Road Signs',q:'What colour are regulatory signs in South Africa?',opts:['Yellow and black','Blue and white','Red, white, and black','Green and white'],a:2},
  {cat:'Road Signs',q:'A triangular sign with a red border is a:',opts:['Regulatory sign','Warning sign','Yield sign','Information sign'],a:2},
  {cat:'Road Signs',q:'What does a sign with 80 inside a red circle mean?',opts:['Minimum speed 80','Maximum speed 80','Advisory 80','End of speed limit'],a:1},
  {cat:'Road Signs',q:'A broken white centre line means:',opts:['No overtaking','You may overtake if safe','Road ending','Pedestrian zone'],a:1},
  {cat:'Road Signs',q:'A solid yellow line on your side means:',opts:['Slow down','You may NOT cross or overtake','End of restriction','Bicycle lane'],a:1},
  {cat:'Road Signs',q:'An inverted triangle sign (point down) means:',opts:['Stop completely','Yield to all traffic','Warning of danger','One-way road'],a:1},
  {cat:'Road Signs',q:'What does a "No Stopping" sign mean?',opts:['Stop for 5 minutes only','No stopping at all','Stop to drop passengers','30 min parking'],a:1},
  {cat:'Road Signs',q:'What shape is a STOP sign?',opts:['Triangle','Circle','Octagon','Diamond'],a:2},
  {cat:'Road Signs',q:'A level crossing sign warns you of:',opts:['A steep hill','A railway crossing','A pedestrian crossing','A sharp bend'],a:1},
  {cat:'Road Signs',q:'Green direction signs indicate:',opts:['Major hazards','Mandatory turns','Routes on national roads','No-go zones'],a:2},
  {cat:'Road Signs',q:'A "No Overtaking" sign applies until:',opts:['You passed 5 vehicles','Next traffic light','End-of-restriction sign or road marking change','After 2 km'],a:2},
  {cat:'Road Signs',q:'A sign showing two opposing arrows on a narrow road means:',opts:['Overtaking permitted','Two-way traffic ahead','Road narrows','High speed zone'],a:1},
  {cat:'Road Signs',q:'A blue rectangular "P" sign means:',opts:['Parking prohibited','Parking permitted','Police ahead','Pedestrian zone'],a:1},
  {cat:'Road Signs',q:'When you see a "Slippery Road" sign you should:',opts:['Increase speed','Reduce speed and avoid harsh braking','Switch to neutral','Brake firmly'],a:1},
  {cat:'Road Signs',q:'A sign with children and a school building means:',opts:['40 km/h applies','Children may cross anywhere','School buses have priority','No under-18s'],a:0},
  {cat:'Road Signs',q:'What does a pedestrian crossing warning sign look like?',opts:['Blue rectangle with walking person','Yellow diamond with walking figure','Red octagon','Green rectangle'],a:1},
  {cat:'Road Signs',q:'A sign with a torch icon warns of:',opts:['Tunnel ahead','Low visibility zone','No lights zone','Emergency vehicles'],a:0},
  {cat:'Road Signs',q:'What does "NO ENTRY" mean?',opts:['Yield to oncoming traffic','You may not enter in this direction','One-way caution','Road closed temporarily'],a:1},
  {cat:'Rules of the Road',q:'At an uncontrolled intersection you must yield to:',opts:['Vehicles on your left','Vehicles on your right','Vehicles straight ahead','No one — first to arrive proceeds'],a:1},
  {cat:'Rules of the Road',q:'At a 4-way stop, two vehicles arrive simultaneously. Who goes first?',opts:['The heavier vehicle','Vehicle on left yields to vehicle on right','The faster vehicle','Vehicle going straight'],a:1},
  {cat:'Rules of the Road',q:'The general speed limit on a South African freeway is:',opts:['100 km/h','110 km/h','120 km/h','140 km/h'],a:2},
  {cat:'Rules of the Road',q:'Legal blood alcohol limit for a driver in South Africa:',opts:['0.02g/100ml','0.05g/100ml','0.08g/100ml','0.10g/100ml'],a:1},
  {cat:'Rules of the Road',q:'The 2-second rule is used to maintain:',opts:['Correct speed','Safe following distance','Lane position','Mirror check frequency'],a:1},
  {cat:'Rules of the Road',q:'When may you use a cell phone while driving?',opts:['At a red light','Only to make calls','Only with a hands-free system','Never while moving'],a:3},
  {cat:'Rules of the Road',q:'In wet conditions your following distance should be:',opts:['Same as dry','Halved','Doubled to at least 4 seconds','Tripled'],a:2},
  {cat:'Rules of the Road',q:'A yellow traffic light means:',opts:['Speed up to clear intersection','Stop if safe to do so','Always proceed','Flash lights'],a:1},
  {cat:'Rules of the Road',q:'When must headlights be used?',opts:['Only in fog','30 min after sunset to 30 min before sunrise','Only on freeways at night','Over 100 km/h'],a:1},
  {cat:'Rules of the Road',q:'On which side may you overtake in South Africa?',opts:['Left only','Right only','Either if safe','Only on freeways'],a:1},
  {cat:'Rules of the Road',q:'You must NOT overtake when:',opts:['On a straight with good visibility','Near the crest of a hill or blind rise','Vehicle in front is at 60 km/h','On a dual carriageway'],a:1},
  {cat:'Rules of the Road',q:'Are all occupants required to wear seat belts?',opts:['Only the driver','Driver and front passenger','All occupants','Only adults over 18'],a:2},
  {cat:'Rules of the Road',q:'Who is responsible for ensuring passengers under 14 are buckled?',opts:['The passenger','The parent','The driver','It is voluntary'],a:2},
  {cat:'Rules of the Road',q:'A learner licence holder blood alcohol limit is:',opts:['0.05g/100ml','0.02g/100ml','0.00g/100ml (zero)','0.08g/100ml'],a:2},
  {cat:'Rules of the Road',q:'When approaching an emergency vehicle with sirens, you must:',opts:['Speed up','Pull left and stop until it passes','Continue at same speed','Flash your lights'],a:1},
  {cat:'Rules of the Road',q:'Urban speed limit in South Africa:',opts:['50 km/h','60 km/h','70 km/h','80 km/h'],a:1},
  {cat:'Rules of the Road',q:'You must NOT use the hooter (horn):',opts:['To warn of danger on open road','Between 21:00 and 06:00 in built-up area','In an emergency','When pedestrian steps in road'],a:1},
  {cat:'Rules of the Road',q:'In a roundabout, who has right of way?',opts:['Vehicles entering','Vehicles already inside','The largest vehicle','Vehicles on the left'],a:1},
  {cat:'Rules of the Road',q:'A double solid centre line means:',opts:['Overtaking allowed for faster vehicles','No vehicle may cross or overtake','Road is ending','Speed doubles'],a:1},
  {cat:'Rules of the Road',q:'At a zebra crossing you must:',opts:['Hoot to warn pedestrians','Yield to pedestrians already on crossing','Stop only if in your lane','Flash lights and proceed slowly'],a:1},
  {cat:'Rules of the Road',q:'How far before a turn should you signal?',opts:['At least 20 m','At least 30 m','At least 50 m','At the turn itself'],a:1},
  {cat:'Rules of the Road',q:'You are in an accident. What to do FIRST?',opts:['Leave and report later','Stop, warn traffic, assist injured, report to police','Take photos and leave','Move all vehicles immediately'],a:1},
  {cat:'Rules of the Road',q:'Is a U-turn at a traffic light legal?',opts:['Yes, always','No, never','Yes, unless a sign prohibits it','Only on a green arrow'],a:2},
  {cat:'Rules of the Road',q:'A broken yellow line between lanes means:',opts:['You may NOT overtake','You may change lanes if safe','Road ending','Bus lane'],a:1},
  {cat:'Rules of the Road',q:'Minimum tread depth for vehicle tyres:',opts:['1 mm','1.6 mm','2.5 mm','3 mm'],a:1},
  {cat:'Rules of the Road',q:'When parking on a hill facing uphill, wheels should be turned:',opts:['Straight ahead','Toward the kerb (right)','Away from kerb (left)','Position does not matter'],a:2},
  {cat:'Vehicle Controls',q:'MSM routine stands for:',opts:['Move, Stop, Manoeuvre','Mirror, Signal, Manoeuvre','Monitor, Steer, Move','Mirror, Speed, Move'],a:1},
  {cat:'Vehicle Controls',q:'Before moving off, a blind spot check is done by:',opts:['Checking interior mirror only','Looking over your shoulder in direction of travel','Sounding the hooter','Checking door mirror only'],a:1},
  {cat:'Vehicle Controls',q:'The clutch pedal on a manual vehicle is on the:',opts:['Far right','Middle','Far left','Steering column'],a:2},
  {cat:'Vehicle Controls',q:'To prevent rolling back on a hill start, use:',opts:['Accelerator only','Handbrake method or left-foot clutch technique','High gear','Neutral with foot on brake'],a:1},
  {cat:'Vehicle Controls',q:'When should you check mirrors?',opts:['Only when turning','Only when changing lanes','Before every signal, speed change, or manoeuvre','Only when reversing'],a:2},
  {cat:'Vehicle Controls',q:'Coasting (neutral downhill) is dangerous because:',opts:['Increases tyre wear','You have no engine braking and less steering control','It improves fuel economy too much','It overheats the clutch'],a:1},
  {cat:'Vehicle Controls',q:'What is the "biting point" on a clutch?',opts:['When pedal is fully pressed','Point where clutch starts to engage and car moves','When gear is fully engaged','Only in first gear'],a:1},
  {cat:'Vehicle Controls',q:'Emergency stop WITHOUT ABS brakes:',opts:['Pump brakes rapidly','Apply steady firm pressure','Press as hard as possible and hold','Use handbrake first'],a:0},
  {cat:'Vehicle Controls',q:'Emergency stop WITH ABS brakes:',opts:['Pump brakes rapidly','Press hard and hold — ABS prevents lock','Use handbrake simultaneously','Apply clutch and brake at once'],a:1},
  {cat:'Vehicle Controls',q:'Low beams should be switched to high beams when:',opts:['In fog','Approaching oncoming vehicle within 150 m','On open dark road with no oncoming traffic','In heavy rain'],a:2},
  {cat:'Vehicle Controls',q:'You must NOT use the handbrake as primary stopping device:',opts:['When parking','When stopped on a hill','While vehicle is moving at speed','Before leaving the vehicle'],a:2},
  {cat:'Vehicle Controls',q:'Correct sequence when stopping:',opts:['Brake → Clutch → Handbrake → Neutral','Clutch → Brake → Neutral → Handbrake','Neutral → Brake → Clutch → Handbrake','Handbrake → Neutral → Clutch → Brake'],a:0},
  {cat:'Vehicle Controls',q:'Before a right turn, check mirrors in this order:',opts:['Right door mirror only','Interior mirror then right door mirror','Right door mirror then interior','Blind spot only'],a:1},
  {cat:'Vehicle Controls',q:'When parallel parking, your vehicle must end within __ of the kerb:',opts:['15 cm','30 cm','50 cm','1 metre'],a:1},
  {cat:'Vehicle Controls',q:'A three-point turn must be completed:',opts:['In exactly 3 moves','Without mounting kerb and only when safe','At speeds under 10 km/h','Only on painted centreline roads'],a:1},
  {cat:'Vehicle Controls',q:'The rear-view (interior) mirror shows:',opts:['Front of vehicle','Directly behind through rear window','Both side blind spots','Road ahead via camera'],a:1},
  {cat:'Vehicle Controls',q:'Before getting into a vehicle, a driver should:',opts:['Start engine immediately','Do a walk-around check for defects','Adjust seat first','Check fuel gauge on dash'],a:1},
  {cat:'Vehicle Controls',q:'Which dashboard light indicates low oil pressure?',opts:['Battery with lightning bolt','Engine outline','Oil can symbol','Thermometer'],a:2},
  {cat:'Vehicle Controls',q:'To signal a right turn you use:',opts:['Left turn signal lever','Right turn signal lever (indicator)','Flash headlights','Use hooter'],a:1},
];

let mtQuestions=[],mtCurrent=0,mtAnswers={},mtTimer=null,mtSecsLeft=1800;

function shuffle(arr){const a=[...arr];for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;}

function showMtHistory() {
  const key='unidrive_mt_'+(currentUser?.id||'');
  const raw=localStorage.getItem(key);
  const hist=raw?JSON.parse(raw):[];
  const el=document.getElementById('mt-history');
  if(!el||!hist.length) return;
  el.innerHTML=`
    <div class="mt-history-wrap">
      <div class="mt-history-title">📊 Your Previous Results (last 5)</div>
      ${hist.slice(-5).reverse().map(h=>`
        <div class="mt-hist-row">
          <span>${h.date}</span>
          <span>${h.score}/${h.total} (${Math.round(h.score/h.total*100)}%)</span>
          <span class="badge badge-${h.passed?'confirmed':'cancelled'}">${h.passed?'PASS':'FAIL'}</span>
        </div>`).join('')}
    </div>`;
}

function startMockTest() {
  const signs=shuffle(MOCK_QUESTIONS.filter(q=>q.cat==='Road Signs')).slice(0,22);
  const rules=shuffle(MOCK_QUESTIONS.filter(q=>q.cat==='Rules of the Road')).slice(0,26);
  const ctrls=shuffle(MOCK_QUESTIONS.filter(q=>q.cat==='Vehicle Controls')).slice(0,20);
  mtQuestions=shuffle([...signs,...rules,...ctrls]);
  mtCurrent=0; mtAnswers={}; mtSecsLeft=1800;
  showSection('mt-test'); renderMtQuestion(); startMtTimer();
}

function renderMtQuestion() {
  const q=mtQuestions[mtCurrent], total=mtQuestions.length;
  document.getElementById('mt-q-counter').textContent=`Question ${mtCurrent+1} of ${total}`;
  document.getElementById('mtPbarFill').style.width=((mtCurrent+1)/total*100)+'%';
  document.getElementById('mt-prev-btn').disabled=mtCurrent===0;
  document.getElementById('mt-next-btn').textContent=mtCurrent===total-1?'✅ Submit Test':'Next →';
  const letters=['A','B','C','D'], chosen=mtAnswers[mtCurrent];
  document.getElementById('mt-question-wrap').innerHTML=`
    <div class="mt-q-category">${q.cat}</div>
    <div class="mt-q-text">${q.q}</div>
    <div class="mt-options">
      ${q.opts.map((o,i)=>`
        <button class="mt-opt ${chosen===i?'selected':''}" onclick="selectMtAnswer(${i},this)">
          <span class="mt-opt-letter">${letters[i]}</span>${o}
        </button>`).join('')}
    </div>`;
}

function selectMtAnswer(idx,btn) {
  mtAnswers[mtCurrent]=idx;
  document.querySelectorAll('.mt-opt').forEach(b=>b.classList.remove('selected'));
  btn.classList.add('selected');
}
function mtNext() { mtCurrent===mtQuestions.length-1?submitMockTest():(mtCurrent++,renderMtQuestion()); }
function mtPrev() { if(mtCurrent>0){mtCurrent--;renderMtQuestion();} }

function startMtTimer() {
  clearInterval(mtTimer); updateMtTimerDisplay();
  mtTimer=setInterval(()=>{
    mtSecsLeft--; updateMtTimerDisplay();
    if(mtSecsLeft<=0){clearInterval(mtTimer);toast('⏱️ Time up! Submitting…','info');submitMockTest();}
  },1000);
}
function updateMtTimerDisplay() {
  const m=Math.floor(mtSecsLeft/60),s=mtSecsLeft%60;
  const el=document.getElementById('mt-timer'); if(!el) return;
  el.textContent=`${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
  el.classList.toggle('urgent',mtSecsLeft<=120);
}

function submitMockTest() {
  clearInterval(mtTimer);
  let correct=0;
  const total=mtQuestions.length;
  mtQuestions.forEach((q,i)=>{if(mtAnswers[i]===q.a)correct++;});
  const pct=Math.round(correct/total*100);
  const passed=correct>=Math.ceil(total*0.77);
  const key='unidrive_mt_'+currentUser.id;
  const raw=localStorage.getItem(key);
  const hist=raw?JSON.parse(raw):[];
  hist.push({date:new Date().toLocaleDateString('en-ZA'),score:correct,total,passed});
  localStorage.setItem(key,JSON.stringify(hist));
  const letters=['A','B','C','D'];
  document.getElementById('mtResultCard').innerHTML=`
    <div class="mt-result-score ${passed?'pass':'fail'}">${pct}%</div>
    <div class="mt-result-label">${passed?'🎉 PASS — Well Done!':'❌ FAIL — Keep Studying!'}</div>
    <div class="mt-result-sub">You scored ${correct} out of ${total}.
      ${passed?'You are ready for the official K53 test!':'You need 77% (≥'+Math.ceil(total*0.77)+' correct) to pass.'}</div>
    <div class="mt-result-breakdown">
      <div class="mt-rb-item"><div class="mt-rb-num" style="color:var(--green)">${correct}</div><div class="mt-rb-lbl">Correct</div></div>
      <div class="mt-rb-item"><div class="mt-rb-num" style="color:#ef4444">${total-correct}</div><div class="mt-rb-lbl">Wrong</div></div>
      <div class="mt-rb-item"><div class="mt-rb-num">${total}</div><div class="mt-rb-lbl">Total</div></div>
    </div>`;
  document.getElementById('mt-review').innerHTML=`
    <h3 style="font-family:'Syne',sans-serif;margin-bottom:1rem">📋 Answer Review</h3>
    ${mtQuestions.map((q,i)=>{
      const chosen=mtAnswers[i],isCorrect=chosen===q.a;
      return `<div class="mt-rv-item ${isCorrect?'rv-correct':'rv-wrong'}">
        <div class="mt-rv-q">${i+1}. ${q.q} <span class="mt-rv-badge ${isCorrect?'correct':'wrong'}">${isCorrect?'✅ Correct':'❌ Wrong'}</span></div>
        <div class="mt-rv-a">${!isCorrect?`Your answer: <em>${chosen!==undefined?letters[chosen]+'. '+q.opts[chosen]:'Not answered'}</em> · `:''} Correct: <strong>${letters[q.a]}. ${q.opts[q.a]}</strong></div>
      </div>`;
    }).join('')}`;
  showSection('mt-results');
}

function showSection(id) {
  ['mt-start','mt-test','mt-results'].forEach(s=>{
    const el=document.getElementById(s); if(el) el.classList.toggle('hidden',s!==id);
  });
}

// ══════════════════════════════════════════════════
//  OFFICIAL TEST BOOKING
// ══════════════════════════════════════════════════
function loadTestBooking() {
  const gate=document.getElementById('testbookGate');
  const content=document.getElementById('testbookContent');
  if (!currentUser) { gate.classList.remove('hidden'); content.classList.add('hidden'); return; }
  gate.classList.add('hidden'); content.classList.remove('hidden');
  loadMyTestBookings();
  const el=document.getElementById('tbDate');
  if(el){const d=new Date();d.setDate(d.getDate()+7);el.min=d.toISOString().split('T')[0];}
}
function updateTestInfo() {
  const val=document.getElementById('tbTestType').value;
  const box=document.getElementById('tbTestInfoBox');
  const info={
    learners_k53:'📋 K53 Theory Test — 68 questions, 30 min. Score 77% to pass. Bring ID + R70 fee.',
    driving_code8:'🚗 Code 8 Driving Test — Yard test + road test. Bring Learner\'s Licence, ID, R130 fee.',
    driving_codeA:'🏍️ Code A Motorcycle Test — Approved safety gear required. Bring Learner\'s Licence, ID, R130 fee.',
    driving_code10:'🚛 Code 10 — Must hold Code 8 first. Vehicle must be roadworthy. ID + Code 8 + R200 fee.',
    driving_code14:'🚚 Code 14 — Must hold Code 10. ID + Code 10 + R200 fee required.',
  };
  if(val&&info[val]){box.textContent=info[val];box.classList.remove('hidden');}else box.classList.add('hidden');
}
function loadTestSlots() {
  const date=document.getElementById('tbDate').value;
  const wrap=document.getElementById('tbSlotsWrapper');
  const grid=document.getElementById('tbSlotsGrid');
  document.getElementById('tbTime').value='';
  if(!date){wrap.style.display='none';return;}
  wrap.style.display='block';
  const slots=['07:00','07:30','08:00','08:30','09:00','09:30','10:00','10:30','11:00','11:30','12:00','12:30','13:00','13:30','14:00','14:30','15:00'];
  grid.innerHTML=slots.map(t=>`<button type="button" class="slot-btn" onclick="selectSlot('${t}',this,'tbTime')">${t}</button>`).join('');
}
function submitTestBooking(e) {
  e.preventDefault();
  const msgEl=document.getElementById('tbMsg'); clearMsg(msgEl);
  const testType=document.getElementById('tbTestType').value;
  const dltc=document.getElementById('tbDLTC').value;
  const date=document.getElementById('tbDate').value;
  const time=document.getElementById('tbTime').value;
  const idNum=document.getElementById('tbIdNumber').value.trim();
  const notes=document.getElementById('tbNotes').value.trim();
  if(!testType){showMsg(msgEl,'Select a test type.','error');return;}
  if(!dltc){showMsg(msgEl,'Select a DLTC centre.','error');return;}
  if(!date){showMsg(msgEl,'Select a date.','error');return;}
  if(!time){showMsg(msgEl,'Select a time slot.','error');return;}
  if(!idNum){showMsg(msgEl,'Enter your ID number.','error');return;}
  const db=getDB();
  const testNames={learners_k53:"Learner's Licence (K53 Theory)",driving_code8:'Driving Test — Code 8',
    driving_codeA:'Driving Test — Code A',driving_code10:'Driving Test — Code 10',driving_code14:'Driving Test — Code 14'};
  const dltcNames={pinetown:'Pinetown DLTC',durban_north:'Durban North DLTC',umlazi:'Umlazi DLTC'};
  if(!db.testBookings) db.testBookings=[];
  const booking={id:'tb_'+Date.now(),user_id:currentUser.id,
    student_name:`${currentUser.first_name} ${currentUser.last_name}`,student_email:currentUser.email,
    test_type:testType,test_name:testNames[testType]||testType,dltc,dltc_name:dltcNames[dltc]||dltc,
    test_date:date,test_time:time,id_number:idNum,notes,status:'pending',
    ref:'UDA-'+Date.now().toString(36).toUpperCase().slice(-8),created_at:new Date().toISOString()};
  db.testBookings.push(booking); saveDB(db);
  showMsg(msgEl,`✅ Reserved! Reference: ${booking.ref}. Confirmation within 2 business days.`,'success');
  e.target.reset();
  document.getElementById('tbSlotsWrapper').style.display='none';
  document.getElementById('tbTestInfoBox').classList.add('hidden');
  toast('Test booking submitted! 🏛️','success'); loadMyTestBookings();
}
function loadMyTestBookings() {
  const el=document.getElementById('myTestBookingsList'); if(!el) return;
  const db=getDB();
  const bookings=(db.testBookings||[]).filter(b=>b.user_id===currentUser?.id)
    .sort((a,b)=>new Date(b.created_at)-new Date(a.created_at));
  if(!bookings.length){el.innerHTML='<p class="text-muted">No official test bookings yet.</p>';return;}
  el.innerHTML=bookings.map(b=>`
    <div class="tbk-item">
      <div class="tbk-hdr"><div class="tbk-type">${b.test_name}</div>
        <span class="badge badge-${b.status==='confirmed'?'confirmed':b.status==='cancelled'?'cancelled':'pending'}">${b.status}</span>
      </div>
      <div class="tbk-meta"><span>🏛️ ${b.dltc_name}</span><span>📅 ${b.test_date} · 🕐 ${b.test_time}</span><span>🔖 ${b.ref}</span></div>
      ${['pending','confirmed'].includes(b.status)?`<div style="margin-top:.5rem"><button class="btn btn-sm btn-red" onclick="cancelTestBooking('${b.id}')">Cancel</button></div>`:''}
    </div>`).join('');
}
function cancelTestBooking(id) {
  if(!confirm('Cancel this test booking?')) return;
  const db=getDB(); if(!db.testBookings) return;
  const bk=db.testBookings.find(b=>b.id===id);
  if(bk){bk.status='cancelled';saveDB(db);} toast('Test booking cancelled.','info'); loadMyTestBookings();
}

// ══════════════════════════════════════════════════
//  UI HELPERS
// ══════════════════════════════════════════════════
function showMsg(el, msg, type) { if(!el) return; el.className=`msg-box msg-${type}`; el.textContent=msg; }
function clearMsg(el) { if(!el) return; el.className='msg-box hidden'; el.textContent=''; }
function toast(msg, type='success') {
  const wrap=document.getElementById('toastWrap');
  const el=document.createElement('div');
  el.className=`toast-item toast-${type}`; el.textContent=msg;
  wrap.appendChild(el); setTimeout(()=>el.remove(),4000);
}
