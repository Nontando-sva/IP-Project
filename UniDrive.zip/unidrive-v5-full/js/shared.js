// js/shared.js — Shared UI components, auth state, toast, router
'use strict';

// ══════════════════════════════════════════════════
//  AUTH STATE
// ══════════════════════════════════════════════════
let currentUser = null;

async function initAuth() {
  const user = await UniDriveAPI.getSession();
  if (user) {
    currentUser = await UniDriveAPI.getProfile(user.id);
  }
  renderNav();
  return currentUser;
}

function renderNav() {
  const area = document.getElementById('authArea');
  if (!area) return;
  if (!currentUser) {
    area.innerHTML = `<a class="nl nav-cta" href="login.html">Login</a>`;
    return;
  }
  const initials = (currentUser.first_name[0] + currentUser.last_name[0]).toUpperCase();
  const dash = currentUser.role === 'admin' ? 'admin.html' : 'dashboard.html';
  const picHtml = currentUser.profile_pic
    ? `<img src="${currentUser.profile_pic}" style="width:27px;height:27px;border-radius:50%;object-fit:cover;border:2px solid var(--gold)"/>`
    : `<span class="nav-avatar">${initials}</span>`;
  area.innerHTML = `
    <a class="nl" href="${dash}" style="display:flex;align-items:center;gap:.5rem">
      ${picHtml}<span>${currentUser.first_name}</span>
    </a>
    <a class="nl logout-link" onclick="doLogout()">Logout</a>`;
}

async function doLogout() {
  await UniDriveAPI.logout();
  currentUser = null;
  window.location.href = 'index.html';
}

function requireAuth(redirectTo = 'login.html') {
  if (!currentUser) {
    window.location.href = redirectTo;
    return false;
  }
  return true;
}

function requireAdmin() {
  if (!currentUser || currentUser.role !== 'admin') {
    window.location.href = 'index.html';
    return false;
  }
  return true;
}

// ══════════════════════════════════════════════════
//  NAVBAR HTML (injected into every page)
// ══════════════════════════════════════════════════
function injectNavbar() {
  const nav = document.getElementById('navbar');
  if (!nav) return;
  const page = window.location.pathname.split('/').pop() || 'index.html';
  const active = (p) => page === p ? 'active' : '';
  nav.innerHTML = `
    <div class="nav-wrap">
      <div class="nav-brand" onclick="window.location.href='index.html'">
        <div class="brand-icon">🚗</div>
        <div>
          <div class="brand-name">Uni-Drive Academy</div>
          <div class="brand-tag">Your Road to Success</div>
        </div>
      </div>
      <div class="nav-links" id="navLinks">
        <a class="nl ${active('index.html')}"        href="index.html">Home</a>
        <a class="nl ${active('courses.html')}"      href="courses.html">Courses</a>
        <a class="nl ${active('instructors.html')}"  href="instructors.html">Instructors</a>
        <a class="nl ${active('book.html')}"         href="book.html">Book a Lesson</a>
        <a class="nl ${active('learn.html')}"        href="learn.html">Study Materials</a>
        <a class="nl ${active('sessions.html')}"     href="sessions.html">Online Sessions</a>
        <a class="nl ${active('mocktest.html')}"     href="mocktest.html">Mock Test</a>
        <a class="nl ${active('testbooking.html')}"  href="testbooking.html">Official Test</a>
        <a class="nl ${active('faq.html')}"          href="faq.html">FAQ</a>
        <a class="nl ${active('contact.html')}"      href="contact.html">Contact</a>
        <div id="authArea"><a class="nl nav-cta" href="login.html">Login</a></div>
      </div>
      <button class="hamburger" onclick="toggleNav()">&#9776;</button>
      <button class="nav-search-btn" onclick="openSmartSearch()" title="Search">🔍</button>
    </div>`;
}

function toggleNav() {
  document.getElementById('navLinks')?.classList.toggle('open');
}

// ══════════════════════════════════════════════════
//  TOAST NOTIFICATIONS
// ══════════════════════════════════════════════════
function toast(msg, type = 'info') {
  const wrap = document.getElementById('toastWrap');
  if (!wrap) return;
  const t = document.createElement('div');
  t.className = `toast toast-${type}`;
  t.textContent = msg;
  wrap.appendChild(t);
  setTimeout(() => t.classList.add('show'), 10);
  setTimeout(() => { t.classList.remove('show'); setTimeout(() => t.remove(), 400); }, 3500);
}

// ══════════════════════════════════════════════════
//  FORM HELPERS
// ══════════════════════════════════════════════════
function showMsg(el, msg, type = 'error') {
  if (!el) return;
  el.textContent = msg;
  el.className = `msg-box msg-${type}`;
  el.classList.remove('hidden');
}

function clearMsg(el) {
  if (!el) return;
  el.textContent = '';
  el.classList.add('hidden');
}

function setMinDate() {
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  document.querySelectorAll('input[type="date"]').forEach(i => {
    i.min = tomorrow.toISOString().split('T')[0];
  });
}

// ══════════════════════════════════════════════════
//  PASSWORD TOGGLE
// ══════════════════════════════════════════════════
function togglePw(inputId, btn) {
  const input = document.getElementById(inputId);
  if (!input) return;
  input.type = input.type === 'password' ? 'text' : 'password';
  btn.textContent = input.type === 'password' ? '👁' : '🙈';
}

// ══════════════════════════════════════════════════
//  TIME SLOTS GENERATOR
// ══════════════════════════════════════════════════
function generateTimeSlots() {
  const slots = [];
  for (let h = 8; h <= 16; h++) {
    slots.push(`${String(h).padStart(2,'0')}:00`);
    if (h < 16) slots.push(`${String(h).padStart(2,'0')}:30`);
  }
  return slots;
}

async function loadTimeSlots(dateInputId, slotsGridId, hiddenInputId, wrapId) {
  const dateVal = document.getElementById(dateInputId)?.value;
  if (!dateVal) return;
  const wrap = document.getElementById(wrapId);
  const grid = document.getElementById(slotsGridId);
  if (!wrap || !grid) return;

  // Fetch already-booked slots for this date
  const { data: booked } = await window.sb
    .from('bookings')
    .select('booking_time')
    .eq('booking_date', dateVal)
    .in('status', ['pending','confirmed']);

  const bookedTimes = new Set((booked || []).map(b => b.booking_time.slice(0,5)));
  const slots = generateTimeSlots();

  grid.innerHTML = slots.map(slot => {
    const taken = bookedTimes.has(slot);
    return `<button type="button" class="slot-btn${taken ? ' slot-taken' : ''}"
      ${taken ? 'disabled' : `onclick="selectSlot('${slot}','${hiddenInputId}',this)"`}>
      ${slot}${taken ? ' ✗' : ''}
    </button>`;
  }).join('');

  wrap.style.display = 'block';
}

function selectSlot(time, hiddenInputId, btn) {
  document.querySelectorAll('.slot-btn.selected').forEach(b => b.classList.remove('selected'));
  btn.classList.add('selected');
  const hidden = document.getElementById(hiddenInputId);
  if (hidden) hidden.value = time;
}

// ══════════════════════════════════════════════════
//  PAGE INIT
// ══════════════════════════════════════════════════
document.addEventListener('DOMContentLoaded', async () => {
  injectNavbar();
  await initAuth();
  setMinDate();
});
