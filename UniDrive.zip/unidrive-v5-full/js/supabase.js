// js/supabase.js — Uni-Drive Academy Supabase Client & API Layer
'use strict';

// ══════════════════════════════════════════════════
//  CONFIGURATION — replace with your project values
// ══════════════════════════════════════════════════
const SUPABASE_URL  = 'https://YOUR_PROJECT_ID.supabase.co';
const SUPABASE_ANON = 'YOUR_ANON_PUBLIC_KEY';

// Load Supabase JS client (add to HTML before this script):
// <script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
const { createClient } = window.supabase;
const sb = createClient(SUPABASE_URL, SUPABASE_ANON);

// ══════════════════════════════════════════════════
//  AUTH API
// ══════════════════════════════════════════════════

/**
 * POST /auth/register
 * Registers a new user and creates their profile row.
 */
async function api_register({ first_name, last_name, email, password, role, student_number, phone }) {
  const { data, error } = await sb.auth.signUp({
    email, password,
    options: { data: { first_name, last_name, role, student_number, phone } }
  });
  if (error) throw error;
  return data.user;
}

/**
 * POST /auth/login
 * Signs in with email + password. Returns session + user.
 */
async function api_login({ email, password }) {
  const { data, error } = await sb.auth.signInWithPassword({ email, password });
  if (error) throw error;
  return data;
}

/**
 * POST /auth/logout
 * Ends the current session.
 */
async function api_logout() {
  const { error } = await sb.auth.signOut();
  if (error) throw error;
}

/**
 * GET /auth/session
 * Returns the currently logged-in user (or null).
 */
async function api_getSession() {
  const { data } = await sb.auth.getSession();
  return data.session?.user ?? null;
}

/**
 * PATCH /auth/password
 * Updates the authenticated user's password.
 */
async function api_updatePassword(newPassword) {
  const { error } = await sb.auth.updateUser({ password: newPassword });
  if (error) throw error;
}

// ══════════════════════════════════════════════════
//  PROFILES API
// ══════════════════════════════════════════════════

/**
 * GET /profiles/:id
 * Fetch a user's profile by their auth UUID.
 */
async function api_getProfile(userId) {
  const { data, error } = await sb
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .single();
  if (error) throw error;
  return data;
}

/**
 * GET /profiles
 * Fetch all profiles (admin only — enforced by RLS).
 */
async function api_getAllProfiles() {
  const { data, error } = await sb
    .from('profiles')
    .select('*')
    .order('created_at', { ascending: false });
  if (error) throw error;
  return data;
}

/**
 * PATCH /profiles/:id
 * Update profile fields (first_name, last_name, phone, student_number, profile_pic).
 */
async function api_updateProfile(userId, updates) {
  const allowed = ['first_name','last_name','phone','student_number','profile_pic'];
  const safe = Object.fromEntries(
    Object.entries(updates).filter(([k]) => allowed.includes(k))
  );
  const { data, error } = await sb
    .from('profiles')
    .update(safe)
    .eq('id', userId)
    .select()
    .single();
  if (error) throw error;
  return data;
}

/**
 * PATCH /profiles/:id/status
 * Toggle a user's is_active flag (admin only).
 */
async function api_toggleUserActive(userId, isActive) {
  const { data, error } = await sb
    .from('profiles')
    .update({ is_active: isActive })
    .eq('id', userId)
    .select()
    .single();
  if (error) throw error;
  return data;
}

// ══════════════════════════════════════════════════
//  COURSES API
// ══════════════════════════════════════════════════

/**
 * GET /courses
 * Returns all available courses.
 */
async function api_getCourses() {
  const { data, error } = await sb
    .from('courses')
    .select('*')
    .order('price_student');
  if (error) throw error;
  return data;
}

/**
 * GET /courses/:id
 * Returns a single course by ID.
 */
async function api_getCourse(courseId) {
  const { data, error } = await sb
    .from('courses')
    .select('*')
    .eq('id', courseId)
    .single();
  if (error) throw error;
  return data;
}

// ══════════════════════════════════════════════════
//  BOOKINGS API
// ══════════════════════════════════════════════════

/**
 * GET /bookings?user_id=
 * Fetch all bookings for the current user (joined with course info).
 */
async function api_getMyBookings(userId) {
  const { data, error } = await sb
    .from('bookings')
    .select(`*, courses(name, icon)`)
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  if (error) throw error;
  return data;
}

/**
 * GET /bookings (admin)
 * Fetch all bookings with user and course info.
 */
async function api_getAllBookings() {
  const { data, error } = await sb
    .from('bookings')
    .select(`*, profiles(first_name, last_name, email, student_number), courses(name, icon)`)
    .order('created_at', { ascending: false });
  if (error) throw error;
  return data;
}

/**
 * POST /bookings
 * Create a new booking. Returns the created booking.
 */
async function api_createBooking({ user_id, course_id, booking_date, booking_time, total_price, notes }) {
  // Check for an existing active booking on the same slot
  const { data: clash } = await sb
    .from('bookings')
    .select('id')
    .eq('booking_date', booking_date)
    .eq('booking_time', booking_time)
    .in('status', ['pending','confirmed'])
    .single();
  if (clash) throw new Error('That time slot is already taken. Please choose another.');

  const { data, error } = await sb
    .from('bookings')
    .insert({ user_id, course_id, booking_date, booking_time, total_price, notes })
    .select()
    .single();
  if (error) throw error;
  return data;
}

/**
 * PATCH /bookings/:id/status
 * Update booking status (cancel by student, confirm/complete by admin).
 */
async function api_updateBookingStatus(bookingId, status) {
  const { data, error } = await sb
    .from('bookings')
    .update({ status })
    .eq('id', bookingId)
    .select()
    .single();
  if (error) throw error;
  return data;
}

// ══════════════════════════════════════════════════
//  PAYMENTS API
// ══════════════════════════════════════════════════

/**
 * POST /payments
 * Record a payment and mark the linked booking as paid.
 */
async function api_createPayment({ booking_id, user_id, amount, method }) {
  const reference = 'UDA-' + Date.now().toString(36).toUpperCase();

  const { data: payment, error: payErr } = await sb
    .from('payments')
    .insert({ booking_id, user_id, amount, method, reference, status: 'completed' })
    .select()
    .single();
  if (payErr) throw payErr;

  // Mark the booking as paid + confirmed
  await sb.from('bookings')
    .update({ paid: true, status: 'confirmed' })
    .eq('id', booking_id);

  return payment;
}

/**
 * GET /payments?user_id=
 * Fetch payment history for a user.
 */
async function api_getMyPayments(userId) {
  const { data, error } = await sb
    .from('payments')
    .select(`*, bookings(booking_date, booking_time, courses(name))`)
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  if (error) throw error;
  return data;
}

// ══════════════════════════════════════════════════
//  ENQUIRIES API
// ══════════════════════════════════════════════════

/**
 * POST /enquiries
 * Submit a contact form enquiry. Public endpoint (no auth needed).
 */
async function api_submitEnquiry({ name, email, phone, message }) {
  const { data, error } = await sb
    .from('enquiries')
    .insert({ name, email, phone, message })
    .select()
    .single();
  if (error) throw error;
  return data;
}

/**
 * GET /enquiries (admin only)
 * Fetch all enquiries ordered by newest first.
 */
async function api_getAllEnquiries() {
  const { data, error } = await sb
    .from('enquiries')
    .select('*')
    .order('created_at', { ascending: false });
  if (error) throw error;
  return data;
}

/**
 * PATCH /enquiries/:id/status (admin only)
 * Update enquiry status (new → in_progress → resolved).
 */
async function api_updateEnquiryStatus(enquiryId, status) {
  const { data, error } = await sb
    .from('enquiries')
    .update({ status })
    .eq('id', enquiryId)
    .select()
    .single();
  if (error) throw error;
  return data;
}

// ══════════════════════════════════════════════════
//  TESTIMONIALS API
// ══════════════════════════════════════════════════

/**
 * GET /testimonials?approved=true
 * Fetch all approved testimonials for public display.
 */
async function api_getApprovedTestimonials() {
  const { data, error } = await sb
    .from('testimonials')
    .select(`*, profiles(first_name, last_name)`)
    .eq('is_approved', true)
    .order('created_at', { ascending: false });
  if (error) throw error;
  return data;
}

/**
 * GET /testimonials (admin only)
 * Fetch all testimonials including pending ones.
 */
async function api_getAllTestimonials() {
  const { data, error } = await sb
    .from('testimonials')
    .select(`*, profiles(first_name, last_name, email)`)
    .order('created_at', { ascending: false });
  if (error) throw error;
  return data;
}

/**
 * POST /testimonials
 * Submit a new testimonial (authenticated users only).
 */
async function api_submitTestimonial({ user_id, rating, message }) {
  const { data, error } = await sb
    .from('testimonials')
    .insert({ user_id, rating, message, is_approved: false })
    .select()
    .single();
  if (error) throw error;
  return data;
}

/**
 * PATCH /testimonials/:id/approve (admin only)
 * Approve or reject a testimonial.
 */
async function api_approveTestimonial(testimonialId, isApproved) {
  const { data, error } = await sb
    .from('testimonials')
    .update({ is_approved: isApproved })
    .eq('id', testimonialId)
    .select()
    .single();
  if (error) throw error;
  return data;
}

// ══════════════════════════════════════════════════
//  TEST BOOKINGS API (DLTC official test slots)
// ══════════════════════════════════════════════════

/**
 * POST /test-bookings
 * Reserve an official DLTC test slot.
 */
async function api_createTestBooking({ user_id, test_type, dltc_centre, test_date, test_time, id_number, notes }) {
  const { data, error } = await sb
    .from('test_bookings')
    .insert({ user_id, test_type, dltc_centre, test_date, test_time, id_number, notes })
    .select()
    .single();
  if (error) throw error;
  return data;
}

/**
 * GET /test-bookings?user_id=
 * Fetch a user's official test bookings.
 */
async function api_getMyTestBookings(userId) {
  const { data, error } = await sb
    .from('test_bookings')
    .select('*')
    .eq('user_id', userId)
    .order('test_date', { ascending: true });
  if (error) throw error;
  return data;
}

// ══════════════════════════════════════════════════
//  ADMIN STATS API
// ══════════════════════════════════════════════════

/**
 * GET /admin/stats
 * Aggregated stats for the admin dashboard.
 */
async function api_getAdminStats() {
  const [users, bookings, enquiries, payments] = await Promise.all([
    sb.from('profiles').select('id, role, created_at'),
    sb.from('bookings').select('id, status, total_price, paid, created_at'),
    sb.from('enquiries').select('id, status'),
    sb.from('payments').select('id, amount, status'),
  ]);

  const b = bookings.data || [];
  const p = payments.data || [];

  return {
    total_users:        (users.data || []).length,
    total_students:     (users.data || []).filter(u => u.role === 'student').length,
    total_staff:        (users.data || []).filter(u => u.role === 'staff').length,
    total_bookings:     b.length,
    pending_bookings:   b.filter(x => x.status === 'pending').length,
    confirmed_bookings: b.filter(x => x.status === 'confirmed').length,
    new_enquiries:      (enquiries.data || []).filter(e => e.status === 'new').length,
    total_revenue:      p.filter(x => x.status === 'completed').reduce((s, x) => s + x.amount, 0),
  };
}

// ══════════════════════════════════════════════════
//  REALTIME SUBSCRIPTIONS
// ══════════════════════════════════════════════════

/**
 * Subscribe to new bookings in real-time (admin dashboard).
 * Returns the subscription channel — call .unsubscribe() to clean up.
 */
function api_subscribeToBookings(callback) {
  return sb
    .channel('bookings-changes')
    .on('postgres_changes', { event: '*', schema: 'public', table: 'bookings' }, callback)
    .subscribe();
}

/**
 * Subscribe to new enquiries in real-time (admin notifications).
 */
function api_subscribeToEnquiries(callback) {
  return sb
    .channel('enquiries-changes')
    .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'enquiries' }, callback)
    .subscribe();
}

// Export for use in page scripts
window.UniDriveAPI = {
  // Auth
  register:             api_register,
  login:                api_login,
  logout:               api_logout,
  getSession:           api_getSession,
  updatePassword:       api_updatePassword,

  // Profiles
  getProfile:           api_getProfile,
  getAllProfiles:        api_getAllProfiles,
  updateProfile:        api_updateProfile,
  toggleUserActive:     api_toggleUserActive,

  // Courses
  getCourses:           api_getCourses,
  getCourse:            api_getCourse,

  // Bookings
  getMyBookings:        api_getMyBookings,
  getAllBookings:        api_getAllBookings,
  createBooking:        api_createBooking,
  updateBookingStatus:  api_updateBookingStatus,

  // Payments
  createPayment:        api_createPayment,
  getMyPayments:        api_getMyPayments,

  // Enquiries
  submitEnquiry:        api_submitEnquiry,
  getAllEnquiries:       api_getAllEnquiries,
  updateEnquiryStatus:  api_updateEnquiryStatus,

  // Testimonials
  getApprovedTestimonials: api_getApprovedTestimonials,
  getAllTestimonials:       api_getAllTestimonials,
  submitTestimonial:       api_submitTestimonial,
  approveTestimonial:      api_approveTestimonial,

  // Test Bookings
  createTestBooking:    api_createTestBooking,
  getMyTestBookings:    api_getMyTestBookings,

  // Admin
  getAdminStats:        api_getAdminStats,

  // Realtime
  subscribeToBookings:  api_subscribeToBookings,
  subscribeToEnquiries: api_subscribeToEnquiries,
};

// ══════════════════════════════════════════════════
//  VEHICLES API
// ══════════════════════════════════════════════════

/** GET /vehicles — all vehicles (admin) */
async function api_getVehicles() {
  const { data, error } = await sb.from('vehicles').select('*').order('make');
  if (error) throw error; return data;
}

/** POST /vehicles — add a vehicle (admin) */
async function api_addVehicle(vehicle) {
  const { data, error } = await sb.from('vehicles').insert(vehicle).select().single();
  if (error) throw error; return data;
}

/** PATCH /vehicles/:id — update vehicle fields (admin) */
async function api_updateVehicle(id, updates) {
  const { data, error } = await sb.from('vehicles').update(updates).eq('id', id).select().single();
  if (error) throw error; return data;
}

/** DELETE /vehicles/:id — remove vehicle (admin) */
async function api_deleteVehicle(id) {
  const { error } = await sb.from('vehicles').delete().eq('id', id);
  if (error) throw error;
}

// ══════════════════════════════════════════════════
//  VEHICLE TRIPS API
// ══════════════════════════════════════════════════

/** GET /vehicle_trips — all trips with vehicle info (admin) */
async function api_getTrips() {
  const { data, error } = await sb
    .from('vehicle_trips')
    .select('*, vehicles(make,model,reg)')
    .order('trip_date', { ascending: false });
  if (error) throw error; return data;
}

/** POST /vehicle_trips — log a new trip (admin) */
async function api_logTrip({ vehicle_id, instructor_name, student_name, trip_date, distance_km, duration_min, notes }) {
  const { data, error } = await sb.from('vehicle_trips')
    .insert({ vehicle_id, instructor_name, student_name, trip_date, distance_km, duration_min, notes })
    .select().single();
  if (error) throw error; return data;
}

// ══════════════════════════════════════════════════
//  MOCK TEST RESULTS API
// ══════════════════════════════════════════════════

/** GET /mock_test_results?user_id= — fetch a student's test history */
async function api_getMyTestResults(userId) {
  const { data, error } = await sb
    .from('mock_test_results')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  if (error) throw error; return data;
}

/** POST /mock_test_results — save a test result */
async function api_saveTestResult({ user_id, score, total, percentage, passed, time_taken_s, answers }) {
  const { data, error } = await sb
    .from('mock_test_results')
    .insert({ user_id, score, total, percentage, passed, time_taken_s, answers })
    .select().single();
  if (error) throw error; return data;
}

/** GET /mock_test_results (admin) — all results */
async function api_getAllTestResults() {
  const { data, error } = await sb
    .from('mock_test_results')
    .select('*, profiles(first_name, last_name, student_number)')
    .order('created_at', { ascending: false });
  if (error) throw error; return data;
}

// ══════════════════════════════════════════════════
//  SESSION PROGRESS API
// ══════════════════════════════════════════════════

/** GET /session_progress?user_id= — get watched sessions for a user */
async function api_getSessionProgress(userId) {
  const { data, error } = await sb
    .from('session_progress')
    .select('session_id, session_title, watched_at')
    .eq('user_id', userId);
  if (error) throw error; return data;
}

/** UPSERT /session_progress — mark a session as watched */
async function api_markSessionWatched(userId, sessionId, sessionTitle) {
  const { data, error } = await sb
    .from('session_progress')
    .upsert({ user_id: userId, session_id: sessionId, session_title: sessionTitle, watched: true },
             { onConflict: 'user_id,session_id' })
    .select().single();
  if (error) throw error; return data;
}

// Extend the exported API object
Object.assign(window.UniDriveAPI, {
  // Vehicles
  getVehicles:          api_getVehicles,
  addVehicle:           api_addVehicle,
  updateVehicle:        api_updateVehicle,
  deleteVehicle:        api_deleteVehicle,
  // Trips
  getTrips:             api_getTrips,
  logTrip:              api_logTrip,
  // Mock Test
  getMyTestResults:     api_getMyTestResults,
  saveTestResult:       api_saveTestResult,
  getAllTestResults:     api_getAllTestResults,
  // Session Progress
  getSessionProgress:   api_getSessionProgress,
  markSessionWatched:   api_markSessionWatched,
});

// Expose raw sb client for inline usage
window.sb = sb;
