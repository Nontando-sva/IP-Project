# Uni-Drive Academy — API Endpoints Reference

All API calls go through **Supabase** (PostgREST + Auth). The client wrapper is in `js/supabase.js`.  
Base URL: `https://YOUR_PROJECT_ID.supabase.co`

---

## Authentication

| Method | Endpoint | Function | Description |
|--------|----------|----------|-------------|
| POST | `/auth/v1/signup` | `api_register()` | Create account + trigger profile insert |
| POST | `/auth/v1/token?grant_type=password` | `api_login()` | Sign in, returns JWT session |
| POST | `/auth/v1/logout` | `api_logout()` | Invalidate current session |
| GET  | `/auth/v1/user` | `api_getSession()` | Get current logged-in user |
| PUT  | `/auth/v1/user` | `api_updatePassword()` | Update authenticated user's password |

---

## Profiles

| Method | Endpoint | Function | Access |
|--------|----------|----------|--------|
| GET | `/rest/v1/profiles?id=eq.{id}` | `api_getProfile(userId)` | Own or admin |
| GET | `/rest/v1/profiles` | `api_getAllProfiles()` | Admin only |
| PATCH | `/rest/v1/profiles?id=eq.{id}` | `api_updateProfile(userId, updates)` | Own only |
| PATCH | `/rest/v1/profiles?id=eq.{id}` | `api_toggleUserActive(userId, bool)` | Admin only |

**Profile object:**
```json
{
  "id": "uuid",
  "first_name": "Thabo",
  "last_name": "Mokoena",
  "email": "thabo@mut.ac.za",
  "role": "student",
  "student_number": "220123456",
  "phone": "0821234567",
  "profile_pic": null,
  "is_active": true,
  "created_at": "2026-01-15T09:00:00Z"
}
```

---

## Courses

| Method | Endpoint | Function | Access |
|--------|----------|----------|--------|
| GET | `/rest/v1/courses?order=price_student` | `api_getCourses()` | Public |
| GET | `/rest/v1/courses?id=eq.{id}` | `api_getCourse(courseId)` | Public |

**Course IDs:** `learners` · `code8` · `codeA` · `code10` · `code14` · `adaptive`

---

## Bookings

| Method | Endpoint | Function | Access |
|--------|----------|----------|--------|
| GET | `/rest/v1/bookings?user_id=eq.{id}&select=*,courses(name,icon)` | `api_getMyBookings(userId)` | Own |
| GET | `/rest/v1/bookings?select=*,profiles(...),courses(...)` | `api_getAllBookings()` | Admin |
| POST | `/rest/v1/bookings` | `api_createBooking(data)` | Authenticated |
| PATCH | `/rest/v1/bookings?id=eq.{id}` | `api_updateBookingStatus(id, status)` | Own or admin |

**Booking statuses:** `pending` → `confirmed` → `completed` / `cancelled`

**Create booking payload:**
```json
{
  "user_id": "uuid",
  "course_id": "code8",
  "booking_date": "2026-07-15",
  "booking_time": "09:00",
  "total_price": 2300,
  "notes": "Manual gear only please"
}
```

---

## Payments

| Method | Endpoint | Function | Access |
|--------|----------|----------|--------|
| POST | `/rest/v1/payments` | `api_createPayment(data)` | Authenticated |
| GET  | `/rest/v1/payments?user_id=eq.{id}&select=*,bookings(...)` | `api_getMyPayments(userId)` | Own |

> `api_createPayment()` also auto-updates the linked booking to `paid=true, status='confirmed'`.

**Payment methods:** `card` · `eft` · `capitec_pay` · `snapscan`

---

## Enquiries

| Method | Endpoint | Function | Access |
|--------|----------|----------|--------|
| POST | `/rest/v1/enquiries` | `api_submitEnquiry(data)` | **Public** (no auth) |
| GET  | `/rest/v1/enquiries?order=created_at.desc` | `api_getAllEnquiries()` | Admin |
| PATCH | `/rest/v1/enquiries?id=eq.{id}` | `api_updateEnquiryStatus(id, status)` | Admin |

**Enquiry statuses:** `new` → `in_progress` → `resolved`

---

## Testimonials

| Method | Endpoint | Function | Access |
|--------|----------|----------|--------|
| GET | `/rest/v1/testimonials?is_approved=eq.true&select=*,profiles(...)` | `api_getApprovedTestimonials()` | Public |
| GET | `/rest/v1/testimonials?select=*,profiles(...)` | `api_getAllTestimonials()` | Admin |
| POST | `/rest/v1/testimonials` | `api_submitTestimonial(data)` | Authenticated |
| PATCH | `/rest/v1/testimonials?id=eq.{id}` | `api_approveTestimonial(id, bool)` | Admin |

---

## Test Bookings (DLTC)

| Method | Endpoint | Function | Access |
|--------|----------|----------|--------|
| POST | `/rest/v1/test_bookings` | `api_createTestBooking(data)` | Authenticated |
| GET  | `/rest/v1/test_bookings?user_id=eq.{id}` | `api_getMyTestBookings(userId)` | Own |

---

## Admin Stats

| Method | Function | Description |
|--------|----------|-------------|
| Aggregated | `api_getAdminStats()` | Runs 4 parallel queries; returns totals for users, bookings, enquiries, revenue |

**Response:**
```json
{
  "total_users": 45,
  "total_students": 38,
  "total_staff": 7,
  "total_bookings": 120,
  "pending_bookings": 14,
  "confirmed_bookings": 22,
  "new_enquiries": 5,
  "total_revenue": 184500
}
```

---

## Realtime Subscriptions

| Channel | Function | Event |
|---------|----------|-------|
| `bookings-changes` | `api_subscribeToBookings(cb)` | INSERT / UPDATE / DELETE on bookings |
| `enquiries-changes` | `api_subscribeToEnquiries(cb)` | INSERT on enquiries |

```js
const sub = UniDriveAPI.subscribeToBookings((payload) => {
  console.log('Booking changed:', payload);
});
// Later: sub.unsubscribe();
```

---

## Row Level Security Summary

| Table | Student/Staff | Admin |
|-------|--------------|-------|
| profiles | Read/update own | Full access |
| bookings | Read/insert/update own | Full access |
| payments | Read/insert own | Full access |
| enquiries | Insert only | Full access |
| testimonials | Read approved + manage own | Full access |
| courses | Read only | Read only |
| test_bookings | Read/insert own | Full access |

---

## Project File Structure

```
unidrive-v5/
├── pages/
│   ├── index.html          ← Home
│   ├── courses.html        ← Courses & pricing
│   ├── instructors.html    ← Instructor profiles
│   ├── book.html           ← Lesson booking form
│   ├── payment.html        ← Payment (card / EFT)
│   ├── pay-success.html    ← Booking confirmation
│   ├── dashboard.html      ← Student dashboard
│   ├── admin.html          ← Admin panel
│   ├── login.html          ← Login
│   ├── register.html       ← Registration
│   ├── contact.html        ← Contact / enquiry form
│   ├── faq.html            ← FAQ accordion
│   ├── learn.html          ← Study materials
│   ├── sessions.html       ← Online classes
│   ├── mocktest.html       ← Mock K53 test
│   └── testbooking.html    ← Official DLTC booking
├── js/
│   ├── supabase.js         ← API layer (all DB calls)
│   ├── shared.js           ← Auth, navbar, toast, helpers
│   ├── search.js           ← Smart search (Ctrl+K)
│   └── chatbot.js          ← Chat widget
├── css/
│   └── style.css           ← All styles (unchanged from v4)
└── sql/
    └── schema.sql          ← Supabase DB setup script
```

---

## Setup Instructions

1. Create a project at [supabase.com](https://supabase.com)
2. Run `sql/schema.sql` in the Supabase SQL Editor
3. In `js/supabase.js`, replace:
   - `SUPABASE_URL` with your project URL
   - `SUPABASE_ANON` with your `anon` public key
4. In Supabase Auth settings, disable email confirmation for local dev (or set up email provider)
5. Open `pages/index.html` in a browser or deploy to any static host (Netlify, Vercel, GitHub Pages)
