-- ══════════════════════════════════════════════════════════════
--  Uni-Drive Academy — Supabase Schema
--  Run this in your Supabase SQL Editor to set up the database
-- ══════════════════════════════════════════════════════════════

-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- ── USERS (extends Supabase auth.users) ──────────────────────
create table public.profiles (
  id             uuid primary key references auth.users(id) on delete cascade,
  first_name     text not null,
  last_name      text not null,
  email          text not null unique,
  role           text not null default 'student' check (role in ('student','staff','admin')),
  student_number text,
  phone          text,
  profile_pic    text,
  is_active      boolean not null default true,
  created_at     timestamptz not null default now()
);

-- ── COURSES (static reference table) ─────────────────────────
create table public.courses (
  id            text primary key,
  name          text not null,
  icon          text,
  price_student integer not null,
  price_staff   integer not null,
  duration      text,
  description   text,
  created_at    timestamptz not null default now()
);

insert into public.courses (id, name, icon, price_student, price_staff, duration, description) values
  ('learners', 'Learner''s Licence Prep',    '📋', 800,  1000, '3 weeks',   'Full K53 theory preparation including road signs and rules.'),
  ('code8',    'Code 8 — Light Motor Vehicle','🚗', 2300, 2800, '25 lessons','Complete Code 8 licence training for light motor vehicles.'),
  ('codeA',    'Code A — Motorcycle',         '🏍️',2000, 2400, '20 lessons','Motorcycle licence training with full safety gear provided.'),
  ('code10',   'Code 10 — Heavy Vehicle',     '🚛', 2500, 3000, '30 lessons','Professional truck driving training up to 16 000 kg.'),
  ('code14',   'Code 14 — Extra Heavy',       '🚚', 3000, 3500, '35 lessons','Extra-heavy motor vehicle licence for articulated trucks.'),
  ('adaptive', 'Adaptive Driving',            '♿', 1500, 1800, 'Custom',    'Specially adapted training for students with disabilities.');

-- ── BOOKINGS ──────────────────────────────────────────────────
create table public.bookings (
  id             uuid primary key default uuid_generate_v4(),
  user_id        uuid not null references public.profiles(id) on delete cascade,
  course_id      text not null references public.courses(id),
  booking_date   date not null,
  booking_time   time not null,
  total_price    integer not null,
  status         text not null default 'pending'
                 check (status in ('pending','confirmed','cancelled','completed')),
  notes          text,
  paid           boolean not null default false,
  created_at     timestamptz not null default now()
);

-- ── PAYMENTS ──────────────────────────────────────────────────
create table public.payments (
  id          uuid primary key default uuid_generate_v4(),
  booking_id  uuid not null references public.bookings(id) on delete cascade,
  user_id     uuid not null references public.profiles(id) on delete cascade,
  amount      integer not null,
  method      text not null check (method in ('card','eft','capitec_pay','snapscan')),
  status      text not null default 'completed'
              check (status in ('pending','completed','failed','refunded')),
  reference   text,
  created_at  timestamptz not null default now()
);

-- ── ENQUIRIES ─────────────────────────────────────────────────
create table public.enquiries (
  id          uuid primary key default uuid_generate_v4(),
  name        text not null,
  email       text not null,
  phone       text,
  message     text not null,
  status      text not null default 'new'
              check (status in ('new','in_progress','resolved')),
  created_at  timestamptz not null default now()
);

-- ── TESTIMONIALS ──────────────────────────────────────────────
create table public.testimonials (
  id          uuid primary key default uuid_generate_v4(),
  user_id     uuid not null references public.profiles(id) on delete cascade,
  rating      integer not null check (rating between 1 and 5),
  message     text not null,
  is_approved boolean not null default false,
  created_at  timestamptz not null default now()
);

-- ── TEST BOOKINGS (DLTC official test slots) ──────────────────
create table public.test_bookings (
  id          uuid primary key default uuid_generate_v4(),
  user_id     uuid not null references public.profiles(id) on delete cascade,
  test_type   text not null,
  dltc_centre text not null,
  test_date   date not null,
  test_time   time not null,
  id_number   text not null,
  status      text not null default 'pending'
              check (status in ('pending','confirmed','cancelled')),
  notes       text,
  created_at  timestamptz not null default now()
);

-- ── ROW LEVEL SECURITY ────────────────────────────────────────
alter table public.profiles      enable row level security;
alter table public.bookings      enable row level security;
alter table public.payments      enable row level security;
alter table public.enquiries     enable row level security;
alter table public.testimonials  enable row level security;
alter table public.test_bookings enable row level security;
alter table public.courses       enable row level security;

-- Profiles: users see/edit only their own; admins see all
create policy "Users can view own profile"
  on public.profiles for select using (auth.uid() = id);
create policy "Users can update own profile"
  on public.profiles for update using (auth.uid() = id);
create policy "Admins can view all profiles"
  on public.profiles for all using (
    exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
  );

-- Bookings: users see/edit own; admins see all
create policy "Users can view own bookings"
  on public.bookings for select using (auth.uid() = user_id);
create policy "Users can insert own bookings"
  on public.bookings for insert with check (auth.uid() = user_id);
create policy "Users can cancel own bookings"
  on public.bookings for update using (auth.uid() = user_id);
create policy "Admins can manage all bookings"
  on public.bookings for all using (
    exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
  );

-- Payments: users see own; admins see all
create policy "Users can view own payments"
  on public.payments for select using (auth.uid() = user_id);
create policy "Users can insert own payments"
  on public.payments for insert with check (auth.uid() = user_id);
create policy "Admins can manage all payments"
  on public.payments for all using (
    exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
  );

-- Enquiries: anyone can insert; admins manage
create policy "Anyone can submit enquiries"
  on public.enquiries for insert with check (true);
create policy "Admins can manage enquiries"
  on public.enquiries for all using (
    exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
  );

-- Testimonials: users manage own; approved ones are public
create policy "Users can manage own testimonials"
  on public.testimonials for all using (auth.uid() = user_id);
create policy "Approved testimonials are public"
  on public.testimonials for select using (is_approved = true);
create policy "Admins can manage all testimonials"
  on public.testimonials for all using (
    exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
  );

-- Courses: public read
create policy "Courses are publicly readable"
  on public.courses for select using (true);

-- Test bookings: users see own; admins see all
create policy "Users can manage own test bookings"
  on public.test_bookings for all using (auth.uid() = user_id);
create policy "Admins can manage all test bookings"
  on public.test_bookings for all using (
    exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
  );

-- ── FUNCTION: auto-create profile on sign-up ─────────────────
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, first_name, last_name, email, role)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'first_name', ''),
    coalesce(new.raw_user_meta_data->>'last_name',  ''),
    new.email,
    coalesce(new.raw_user_meta_data->>'role', 'student')
  );
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();
