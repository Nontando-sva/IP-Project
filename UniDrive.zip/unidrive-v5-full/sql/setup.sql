-- ══════════════════════════════════════════════════════════════════════════
--  UNI-DRIVE ACADEMY — SUPABASE SETUP SCRIPT
--  Paste this entire script into Supabase → SQL Editor → Run
--
--  Safe to re-run: uses IF NOT EXISTS and ON CONFLICT DO NOTHING
--  Includes: tables, RLS policies, trigger, seed data (courses + demo users)
-- ══════════════════════════════════════════════════════════════════════════


-- ── STEP 1: EXTENSIONS ────────────────────────────────────────────────────
create extension if not exists "uuid-ossp";


-- ── STEP 2: TABLES ────────────────────────────────────────────────────────

-- PROFILES (one per auth user)
create table if not exists public.profiles (
  id             uuid primary key references auth.users(id) on delete cascade,
  first_name     text not null default '',
  last_name      text not null default '',
  email          text not null unique,
  role           text not null default 'student'
                 check (role in ('student', 'staff', 'admin')),
  student_number text,
  phone          text,
  profile_pic    text,
  is_active      boolean not null default true,
  created_at     timestamptz not null default now()
);

-- COURSES (static reference)
create table if not exists public.courses (
  id            text primary key,
  name          text not null,
  icon          text,
  price_student integer not null,
  price_staff   integer not null,
  duration      text,
  description   text,
  created_at    timestamptz not null default now()
);

-- BOOKINGS
create table if not exists public.bookings (
  id           uuid primary key default uuid_generate_v4(),
  user_id      uuid not null references public.profiles(id) on delete cascade,
  course_id    text not null references public.courses(id),
  booking_date date not null,
  booking_time time not null,
  total_price  integer not null,
  status       text not null default 'pending'
               check (status in ('pending', 'confirmed', 'cancelled', 'completed')),
  notes        text,
  paid         boolean not null default false,
  created_at   timestamptz not null default now()
);

-- PAYMENTS
create table if not exists public.payments (
  id         uuid primary key default uuid_generate_v4(),
  booking_id uuid not null references public.bookings(id) on delete cascade,
  user_id    uuid not null references public.profiles(id) on delete cascade,
  amount     integer not null,
  method     text not null
             check (method in ('card', 'eft', 'capitec_pay', 'snapscan')),
  status     text not null default 'completed'
             check (status in ('pending', 'completed', 'failed', 'refunded')),
  reference  text,
  created_at timestamptz not null default now()
);

-- ENQUIRIES (contact form — no auth needed)
create table if not exists public.enquiries (
  id         uuid primary key default uuid_generate_v4(),
  name       text not null,
  email      text not null,
  phone      text,
  message    text not null,
  status     text not null default 'new'
             check (status in ('new', 'in_progress', 'resolved')),
  created_at timestamptz not null default now()
);

-- TESTIMONIALS (student reviews)
create table if not exists public.testimonials (
  id          uuid primary key default uuid_generate_v4(),
  user_id     uuid not null references public.profiles(id) on delete cascade,
  rating      integer not null check (rating between 1 and 5),
  message     text not null,
  is_approved boolean not null default false,
  created_at  timestamptz not null default now()
);

-- TEST BOOKINGS (official DLTC test slots)
create table if not exists public.test_bookings (
  id          uuid primary key default uuid_generate_v4(),
  user_id     uuid not null references public.profiles(id) on delete cascade,
  test_type   text not null,
  dltc_centre text not null,
  test_date   date not null,
  test_time   time not null,
  id_number   text not null,
  status      text not null default 'pending'
              check (status in ('pending', 'confirmed', 'cancelled')),
  notes       text,
  created_at  timestamptz not null default now()
);


-- ── STEP 3: ROW LEVEL SECURITY ────────────────────────────────────────────

alter table public.profiles      enable row level security;
alter table public.bookings      enable row level security;
alter table public.payments      enable row level security;
alter table public.enquiries     enable row level security;
alter table public.testimonials  enable row level security;
alter table public.test_bookings enable row level security;
alter table public.courses       enable row level security;

-- Drop existing policies before recreating (safe re-run)
do $$ declare
  r record;
begin
  for r in
    select policyname, tablename
    from pg_policies
    where schemaname = 'public'
  loop
    execute format('drop policy if exists %I on public.%I', r.policyname, r.tablename);
  end loop;
end $$;

-- ── PROFILES policies ──
create policy "profiles_select_own"
  on public.profiles for select
  using (auth.uid() = id);

create policy "profiles_update_own"
  on public.profiles for update
  using (auth.uid() = id);

create policy "profiles_insert_own"
  on public.profiles for insert
  with check (auth.uid() = id);

create policy "profiles_admin_all"
  on public.profiles for all
  using (
    exists (
      select 1 from public.profiles p
      where p.id = auth.uid() and p.role = 'admin'
    )
  );

-- ── COURSES policies ──
create policy "courses_public_read"
  on public.courses for select
  using (true);

-- ── BOOKINGS policies ──
create policy "bookings_select_own"
  on public.bookings for select
  using (auth.uid() = user_id);

create policy "bookings_insert_own"
  on public.bookings for insert
  with check (auth.uid() = user_id);

create policy "bookings_update_own"
  on public.bookings for update
  using (auth.uid() = user_id);

create policy "bookings_admin_all"
  on public.bookings for all
  using (
    exists (
      select 1 from public.profiles p
      where p.id = auth.uid() and p.role = 'admin'
    )
  );

-- ── PAYMENTS policies ──
create policy "payments_select_own"
  on public.payments for select
  using (auth.uid() = user_id);

create policy "payments_insert_own"
  on public.payments for insert
  with check (auth.uid() = user_id);

create policy "payments_admin_all"
  on public.payments for all
  using (
    exists (
      select 1 from public.profiles p
      where p.id = auth.uid() and p.role = 'admin'
    )
  );

-- ── ENQUIRIES policies ──
create policy "enquiries_public_insert"
  on public.enquiries for insert
  with check (true);

create policy "enquiries_admin_all"
  on public.enquiries for all
  using (
    exists (
      select 1 from public.profiles p
      where p.id = auth.uid() and p.role = 'admin'
    )
  );

-- ── TESTIMONIALS policies ──
create policy "testimonials_approved_public"
  on public.testimonials for select
  using (is_approved = true);

create policy "testimonials_own_all"
  on public.testimonials for all
  using (auth.uid() = user_id);

create policy "testimonials_admin_all"
  on public.testimonials for all
  using (
    exists (
      select 1 from public.profiles p
      where p.id = auth.uid() and p.role = 'admin'
    )
  );

-- ── TEST BOOKINGS policies ──
create policy "test_bookings_own_all"
  on public.test_bookings for all
  using (auth.uid() = user_id);

create policy "test_bookings_admin_all"
  on public.test_bookings for all
  using (
    exists (
      select 1 from public.profiles p
      where p.id = auth.uid() and p.role = 'admin'
    )
  );


-- ── STEP 4: TRIGGER — auto-create profile on sign-up ─────────────────────

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, first_name, last_name, email, role, student_number, phone)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'first_name', ''),
    coalesce(new.raw_user_meta_data->>'last_name',  ''),
    new.email,
    coalesce(new.raw_user_meta_data->>'role', 'student'),
    coalesce(new.raw_user_meta_data->>'student_number', ''),
    coalesce(new.raw_user_meta_data->>'phone', '')
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

-- Drop and recreate trigger (safe re-run)
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();


-- ── STEP 5: SEED DATA — Courses ───────────────────────────────────────────

insert into public.courses (id, name, icon, price_student, price_staff, duration, description)
values
  ('learners', 'Learner''s Licence Prep',     '📋', 800,  1000, '3 weeks',    'Full K53 theory preparation including road signs and rules. Includes 3 practice exams.'),
  ('code8',    'Code 8 — Light Motor Vehicle', '🚗', 2300, 2800, '25 lessons', 'Complete Code 8 licence training for cars and light vehicles. 25 structured K53 lessons.'),
  ('codeA',    'Code A — Motorcycle',          '🏍️',2000, 2400, '20 lessons', 'Motorcycle licence training with full safety gear provided. Includes off-road and road training.'),
  ('code10',   'Code 10 — Heavy Vehicle',      '🚛', 2500, 3000, '30 lessons', 'Professional truck driving training up to 16 000 kg. Ideal for students in logistics.'),
  ('code14',   'Code 14 — Extra Heavy',        '🚚', 3000, 3500, '35 lessons', 'Extra-heavy motor vehicle licence for articulated trucks, tankers, and freight vehicles.'),
  ('adaptive', 'Adaptive Driving',             '♿', 1500, 1800, 'Custom',     'Specially adapted training for students with physical disabilities. Modified vehicles available.')
on conflict (id) do update set
  name          = excluded.name,
  icon          = excluded.icon,
  price_student = excluded.price_student,
  price_staff   = excluded.price_staff,
  duration      = excluded.duration,
  description   = excluded.description;


-- ── STEP 6: SEED DATA — Demo Auth Users ───────────────────────────────────
--
--  This creates 3 demo accounts in auth.users directly.
--  Passwords are set below — change them before going live!
--
--  Admin  : admin@unidrive.ac.za  / Admin@1234
--  Student: thabo@mut.ac.za       / Student@1234
--  Staff  : naledi@mut.ac.za      / Staff@1234
--
--  NOTE: Supabase does not allow inserting into auth.users from SQL Editor
--  by default in newer projects. If the block below gives a permissions
--  error, create the accounts manually via:
--    Supabase Dashboard → Authentication → Users → Add User
--  Then set their role in the profiles table using the UPDATE at the bottom.
-- ─────────────────────────────────────────────────────────────────────────

do $$
declare
  admin_id   uuid := uuid_generate_v4();
  student_id uuid := uuid_generate_v4();
  staff_id   uuid := uuid_generate_v4();
begin

  -- ── Admin account ──
  if not exists (select 1 from auth.users where email = 'admin@unidrive.ac.za') then
    insert into auth.users (
      id, instance_id, aud, role, email,
      encrypted_password, email_confirmed_at,
      raw_user_meta_data, created_at, updated_at
    ) values (
      admin_id,
      '00000000-0000-0000-0000-000000000000',
      'authenticated', 'authenticated',
      'admin@unidrive.ac.za',
      crypt('Admin@1234', gen_salt('bf')),
      now(),
      '{"first_name":"Admin","last_name":"UniDrive","role":"admin"}'::jsonb,
      now(), now()
    );
    -- Upsert profile (trigger may have already created it)
    insert into public.profiles (id, first_name, last_name, email, role, phone, is_active)
    values (admin_id, 'Admin', 'UniDrive', 'admin@unidrive.ac.za', 'admin', '031 907 7111', true)
    on conflict (id) do update set role = 'admin';
  else
    -- User already exists — just make sure role is admin
    update public.profiles set role = 'admin' where email = 'admin@unidrive.ac.za';
  end if;

  -- ── Student account ──
  if not exists (select 1 from auth.users where email = 'thabo@mut.ac.za') then
    insert into auth.users (
      id, instance_id, aud, role, email,
      encrypted_password, email_confirmed_at,
      raw_user_meta_data, created_at, updated_at
    ) values (
      student_id,
      '00000000-0000-0000-0000-000000000000',
      'authenticated', 'authenticated',
      'thabo@mut.ac.za',
      crypt('Student@1234', gen_salt('bf')),
      now(),
      '{"first_name":"Thabo","last_name":"Mokoena","role":"student","student_number":"220123456"}'::jsonb,
      now(), now()
    );
    insert into public.profiles (id, first_name, last_name, email, role, student_number, phone, is_active)
    values (student_id, 'Thabo', 'Mokoena', 'thabo@mut.ac.za', 'student', '220123456', '0821234567', true)
    on conflict (id) do update set first_name = 'Thabo', last_name = 'Mokoena', student_number = '220123456';
  end if;

  -- ── Staff account ──
  if not exists (select 1 from auth.users where email = 'naledi@mut.ac.za') then
    insert into auth.users (
      id, instance_id, aud, role, email,
      encrypted_password, email_confirmed_at,
      raw_user_meta_data, created_at, updated_at
    ) values (
      staff_id,
      '00000000-0000-0000-0000-000000000000',
      'authenticated', 'authenticated',
      'naledi@mut.ac.za',
      crypt('Staff@1234', gen_salt('bf')),
      now(),
      '{"first_name":"Naledi","last_name":"Dlamini","role":"staff"}'::jsonb,
      now(), now()
    );
    insert into public.profiles (id, first_name, last_name, email, role, phone, is_active)
    values (staff_id, 'Naledi', 'Dlamini', 'naledi@mut.ac.za', 'staff', '0731234567', true)
    on conflict (id) do update set first_name = 'Naledi', last_name = 'Dlamini', role = 'staff';
  end if;

end $$;


-- ── STEP 7: SEED DATA — Sample Booking & Testimonials ────────────────────

-- Sample confirmed booking for Thabo
insert into public.bookings (user_id, course_id, booking_date, booking_time, total_price, status, paid, notes)
select
  p.id,
  'code8',
  current_date + interval '7 days',
  '09:00',
  2300,
  'confirmed',
  true,
  'Please use manual gear vehicle'
from public.profiles p
where p.email = 'thabo@mut.ac.za'
  and not exists (
    select 1 from public.bookings b where b.user_id = p.id
  );

-- Sample approved testimonials
insert into public.testimonials (user_id, rating, message, is_approved)
select p.id, 5, 'Passed my Code 8 first time! The instructors are patient and thorough. Highly recommended for all MUT students.', true
from public.profiles p where p.email = 'thabo@mut.ac.za'
on conflict do nothing;

insert into public.testimonials (user_id, rating, message, is_approved)
select p.id, 5, 'Affordable, convenient, and professional. The online booking system made everything so easy.', true
from public.profiles p where p.email = 'naledi@mut.ac.za'
on conflict do nothing;

-- Sample enquiry
insert into public.enquiries (name, email, phone, message, status)
values (
  'Siphamandla Ngcobo',
  'sngcobo@mut.ac.za',
  '0798765432',
  'I would like to know more about the Code 10 programme and payment options.',
  'new'
);


-- ── DONE ──────────────────────────────────────────────────────────────────
--
--  Your database is ready. Verify by running:
--    select * from public.courses;
--    select * from public.profiles;
--
--  If demo users were blocked by permissions, create them manually:
--    Supabase → Authentication → Users → Invite / Add User
--  Then update their role:
--    update public.profiles set role = 'admin' where email = 'admin@unidrive.ac.za';
--
-- ══════════════════════════════════════════════════════════════════════════
