-- ══════════════════════════════════════════════════════════════════════════
--  UNI-DRIVE ACADEMY — DATABASE UPDATE SCRIPT
--  Run this in Supabase → SQL Editor → Run
--  Adds tables for: Fleet, Trips, Mock Test Results, Session Progress
--  Safe to re-run: uses IF NOT EXISTS and ON CONFLICT DO NOTHING
-- ══════════════════════════════════════════════════════════════════════════


-- ── TABLE 1: VEHICLES (Fleet Management) ─────────────────────────────────
create table if not exists public.vehicles (
  id            uuid primary key default uuid_generate_v4(),
  make          text not null,
  model         text not null,
  year          integer not null,
  reg           text not null unique,
  colour        text not null default 'White',
  transmission  text not null default 'Manual'
                check (transmission in ('Manual','Automatic')),
  licence_type  text not null default 'Code 8',
  status        text not null default 'Available'
                check (status in ('Available','On Road','Maintenance','Decommissioned')),
  km            integer not null default 0,
  last_service  date,
  next_service  date,
  notes         text,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

-- ── TABLE 2: VEHICLE TRIPS (Trip History) ────────────────────────────────
create table if not exists public.vehicle_trips (
  id            uuid primary key default uuid_generate_v4(),
  vehicle_id    uuid not null references public.vehicles(id) on delete cascade,
  instructor_id uuid references public.profiles(id) on delete set null,
  student_id    uuid references public.profiles(id) on delete set null,
  instructor_name text,
  student_name  text,
  trip_date     date not null default current_date,
  distance_km   integer not null default 0,
  duration_min  integer not null default 0,
  notes         text,
  created_at    timestamptz not null default now()
);

-- ── TABLE 3: MOCK TEST RESULTS ────────────────────────────────────────────
create table if not exists public.mock_test_results (
  id            uuid primary key default uuid_generate_v4(),
  user_id       uuid not null references public.profiles(id) on delete cascade,
  score         integer not null,
  total         integer not null default 68,
  percentage    integer not null,
  passed        boolean not null,
  time_taken_s  integer,
  answers       jsonb,   -- stores {q_index: chosen_option} for review
  created_at    timestamptz not null default now()
);

-- ── TABLE 4: SESSION PROGRESS (Recorded Class Tracking) ──────────────────
create table if not exists public.session_progress (
  id            uuid primary key default uuid_generate_v4(),
  user_id       uuid not null references public.profiles(id) on delete cascade,
  session_id    text not null,   -- e.g. 'rec1', 'rec2' matching frontend IDs
  session_title text,
  watched       boolean not null default true,
  watched_at    timestamptz not null default now(),
  unique (user_id, session_id)
);


-- ── ROW LEVEL SECURITY ────────────────────────────────────────────────────
alter table public.vehicles        enable row level security;
alter table public.vehicle_trips   enable row level security;
alter table public.mock_test_results enable row level security;
alter table public.session_progress  enable row level security;

-- Drop old policies if re-running
drop policy if exists "vehicles_public_read"        on public.vehicles;
drop policy if exists "vehicles_admin_all"           on public.vehicles;
drop policy if exists "trips_admin_all"              on public.vehicle_trips;
drop policy if exists "trips_public_read"            on public.vehicle_trips;
drop policy if exists "mock_results_own"             on public.mock_test_results;
drop policy if exists "mock_results_admin_all"       on public.mock_test_results;
drop policy if exists "session_progress_own"         on public.session_progress;
drop policy if exists "session_progress_admin_read"  on public.session_progress;

-- Vehicles: everyone can read; only admins can insert/update/delete
create policy "vehicles_public_read"
  on public.vehicles for select using (true);

create policy "vehicles_admin_all"
  on public.vehicles for all
  using (exists (
    select 1 from public.profiles where id = auth.uid() and role = 'admin'
  ));

-- Vehicle trips: everyone can read; only admins can insert/update/delete
create policy "trips_public_read"
  on public.vehicle_trips for select using (true);

create policy "trips_admin_all"
  on public.vehicle_trips for all
  using (exists (
    select 1 from public.profiles where id = auth.uid() and role = 'admin'
  ));

-- Mock test results: users manage their own; admins can read all
create policy "mock_results_own"
  on public.mock_test_results for all
  using (auth.uid() = user_id);

create policy "mock_results_admin_all"
  on public.mock_test_results for select
  using (exists (
    select 1 from public.profiles where id = auth.uid() and role = 'admin'
  ));

-- Session progress: users manage their own; admins can read all
create policy "session_progress_own"
  on public.session_progress for all
  using (auth.uid() = user_id);

create policy "session_progress_admin_read"
  on public.session_progress for select
  using (exists (
    select 1 from public.profiles where id = auth.uid() and role = 'admin'
  ));


-- ── TRIGGER: auto-update updated_at on vehicles ───────────────────────────
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end;
$$;

drop trigger if exists vehicles_updated_at on public.vehicles;
create trigger vehicles_updated_at
  before update on public.vehicles
  for each row execute procedure public.set_updated_at();


-- ── SEED DATA: Fleet Vehicles ─────────────────────────────────────────────
insert into public.vehicles
  (make, model, year, reg, colour, transmission, licence_type, status, km, last_service, next_service, notes)
values
  ('Toyota',     'Corolla',  2021, 'GP 12 34 AB', 'White',  'Manual',    'Code 8',    'Available',   45200, '2026-03-01', '2026-09-01', 'Main Code 8 training vehicle. Good condition.'),
  ('Toyota',     'Corolla',  2020, 'GP 11 22 KL', 'Grey',   'Automatic', 'Refresher', 'Available',   67500, '2026-01-10', '2026-07-10', 'Automatic for refresher and elderly students.'),
  ('Volkswagen', 'Polo',     2022, 'GP 56 78 CD', 'Silver', 'Manual',    'Code 8',    'Available',   31000, '2026-04-15', '2026-10-15', 'Second Code 8 vehicle.'),
  ('Hyundai',    'i20',      2023, 'GP 78 90 IJ', 'Red',    'Automatic', 'Learners',  'Available',   12400, '2026-05-01', '2026-11-01', 'Used for learners theory and yard test prep.'),
  ('Toyota',     'Hilux',    2020, 'GP 91 23 EF', 'White',  'Manual',    'Code 10',   'Maintenance', 112000,'2025-12-01', '2026-06-01', 'Under scheduled maintenance.'),
  ('Nissan',     'NP200',    2019, 'GP 45 67 GH', 'Blue',   'Manual',    'Code 10',   'Available',   98700, '2026-02-20', '2026-08-20', 'Backup heavy vehicle for Code 10.')
on conflict (reg) do update set
  status       = excluded.status,
  km           = excluded.km,
  last_service = excluded.last_service,
  next_service = excluded.next_service,
  notes        = excluded.notes;


-- ── SEED DATA: Sample Trips ───────────────────────────────────────────────
-- Only insert if no trips exist yet
do $$
begin
  if not exists (select 1 from public.vehicle_trips) then
    insert into public.vehicle_trips
      (vehicle_id, instructor_name, student_name, trip_date, distance_km, duration_min, notes)
    select
      v.id,
      trip.instructor_name,
      trip.student_name,
      trip.trip_date::date,
      trip.distance_km,
      trip.duration_min,
      trip.notes
    from (values
      ('GP 12 34 AB', 'Mr. Sipho Mkhize',       'Thabo Mokoena',   '2026-06-20', 34, 60, 'Parallel parking practice'),
      ('GP 78 90 IJ', 'Ms. Nompumelelo Zulu',   'Naledi Sithole',  '2026-06-21', 12, 45, 'Yard manoeuvres'),
      ('GP 56 78 CD', 'Mr. Sipho Mkhize',       'Sipho Khumalo',   '2026-06-22', 28, 55, 'Open road — N3 route'),
      ('GP 11 22 KL', 'Ms. Nompumelelo Zulu',   'Zanele Dube',     '2026-06-19', 18, 50, 'Refresher — highway driving'),
      ('GP 12 34 AB', 'Mr. Bongani Ndlela',     'Lungelo Nxumalo', '2026-06-18', 22, 50, 'Hill starts and three-point turns'),
      ('GP 45 67 GH', 'Mr. Sipho Mkhize',       'Ayanda Mthembu',  '2026-06-17', 45, 90, 'Code 10 pre-test run')
    ) as trip(reg, instructor_name, student_name, trip_date, distance_km, duration_min, notes)
    join public.vehicles v on v.reg = trip.reg;
  end if;
end $$;


-- ── VERIFY ────────────────────────────────────────────────────────────────
-- Run these to confirm everything was created:
--
--   select table_name from information_schema.tables
--   where table_schema = 'public' order by table_name;
--
--   select make, model, reg, status from public.vehicles;
--
-- ══════════════════════════════════════════════════════════════════════════
