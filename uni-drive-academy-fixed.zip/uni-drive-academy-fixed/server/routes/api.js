// server/routes/api.js — All main API routes (NeDB version)
const express = require('express');
const router  = express.Router();
const db      = require('../../database/db');
const { protect, restrictTo } = require('../middleware/auth');
const { validateBooking, validateEnquiry } = require('../middleware/validate');

// ══════════════════════════════════════════════════════════════
//  COURSES  — Public
// ══════════════════════════════════════════════════════════════
router.get('/courses', async (req, res, next) => {
  try {
    const courses = await db.courses.findAsync({ is_active:true });
    res.json({ success:true, courses });
  } catch(err) { next(err); }
});

router.get('/courses/:id', async (req, res, next) => {
  try {
    const course = await db.courses.findOneAsync({ _id:req.params.id, is_active:true });
    if (!course) return res.status(404).json({ error:'Course not found.' });
    res.json({ success:true, course });
  } catch(err) { next(err); }
});

// ══════════════════════════════════════════════════════════════
//  BOOKINGS  — Protected
// ══════════════════════════════════════════════════════════════
router.get('/bookings', protect, async (req, res, next) => {
  try {
    const query = req.user.role === 'admin' ? {} : { user_id: req.user._id };
    const bookings = await db.bookings.findAsync(query);
    // Sort by created_at descending
    bookings.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
    res.json({ success:true, bookings });
  } catch(err) { next(err); }
});

router.post('/bookings', protect, validateBooking, async (req, res, next) => {
  try {
    const { course_id, booking_date, booking_time, notes } = req.body;

    if (new Date(booking_date) < new Date(new Date().toDateString()))
      return res.status(400).json({ error:'Booking date cannot be in the past.' });

    const course = await db.courses.findOneAsync({ _id: course_id });
    if (!course) return res.status(404).json({ error:'Course not found.' });

    // Check duplicate
    const dup = await db.bookings.findOneAsync({
      user_id: req.user._id, booking_date, booking_time,
      status: { $nin: ['cancelled'] }
    });
    if (dup) return res.status(400).json({ error:'You already have a booking at this date and time.' });

    const price = req.user.role === 'staff' ? course.price_staff : course.price_student;

    const booking = await db.bookings.insertAsync({
      user_id:       req.user._id,
      course_id,
      course_name:   course.name,
      student_name:  `${req.user.first_name} ${req.user.last_name}`,
      student_email: req.user.email,
      booking_date,
      booking_time,
      notes:         notes || '',
      total_price:   price,
      status:        'pending',
      payment_status:'unpaid',
      created_at:    new Date().toISOString(),
    });

    res.status(201).json({ success:true, booking });
  } catch(err) { next(err); }
});

router.patch('/bookings/:id/status', protect, restrictTo('admin'), async (req, res, next) => {
  try {
    const { status } = req.body;
    const allowed = ['pending','confirmed','cancelled','completed'];
    if (!allowed.includes(status)) return res.status(400).json({ error:'Invalid status.' });
    await db.bookings.updateAsync({ _id:req.params.id }, { $set:{ status } });
    res.json({ success:true });
  } catch(err) { next(err); }
});

router.delete('/bookings/:id', protect, async (req, res, next) => {
  try {
    const booking = await db.bookings.findOneAsync({ _id:req.params.id });
    if (!booking) return res.status(404).json({ error:'Booking not found.' });
    if (req.user.role !== 'admin' && booking.user_id !== req.user._id)
      return res.status(403).json({ error:'Not authorised.' });
    await db.bookings.updateAsync({ _id:req.params.id }, { $set:{ status:'cancelled' } });
    res.json({ success:true, message:'Booking cancelled.' });
  } catch(err) { next(err); }
});

// ══════════════════════════════════════════════════════════════
//  INSTRUCTORS  — Public
// ══════════════════════════════════════════════════════════════
router.get('/instructors', async (req, res, next) => {
  try {
    const instructors = await db.instructors.findAsync({ is_active:true });
    res.json({ success:true, instructors });
  } catch(err) { next(err); }
});

// ══════════════════════════════════════════════════════════════
//  FAQ  — AI NLP Keyword Search
// ══════════════════════════════════════════════════════════════
router.get('/faq', async (req, res, next) => {
  try {
    const faqs = await db.faqs.findAsync({});
    res.json({ success:true, faqs });
  } catch(err) { next(err); }
});

// POST /api/faq/search — NLP keyword scoring
router.post('/faq/search', async (req, res, next) => {
  try {
    const { question } = req.body;
    if (!question || question.trim().length < 2)
      return res.status(400).json({ error:'Please provide a question.' });

    const faqs  = await db.faqs.findAsync({});
    const query = question.toLowerCase().trim();
    const words = query.split(/\s+/).filter(w => w.length > 2);

    const scored = faqs.map(faq => {
      let score = 0;
      const kw = (faq.keywords || '').toLowerCase();
      const fq = faq.q.toLowerCase();
      const fa = faq.a.toLowerCase();
      words.forEach(w => {
        if (kw.includes(w)) score += 3;  // keyword match = highest weight
        if (fq.includes(w)) score += 2;  // question match
        if (fa.includes(w)) score += 1;  // answer match
      });
      if (fq.includes(query)) score += 10; // exact phrase bonus
      return { ...faq, score };
    });

    const results = scored
      .filter(f => f.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, 3);

    if (!results.length) {
      return res.json({
        success:true, results:[],
        suggestion:'No matching FAQs found. Please contact us at info@unidrive.ac.za or use the contact form.'
      });
    }
    res.json({ success:true, results });
  } catch(err) { next(err); }
});

// ══════════════════════════════════════════════════════════════
//  ENQUIRIES  — Contact Form
// ══════════════════════════════════════════════════════════════
router.post('/enquiries', validateEnquiry, async (req, res, next) => {
  try {
    const { name, email, phone, message } = req.body;
    await db.enquiries.insertAsync({
      name: name.trim(), email: email.trim(),
      phone: phone || '', message: message.trim(),
      status: 'new', created_at: new Date().toISOString()
    });
    res.status(201).json({ success:true, message:'Your enquiry has been received. We will respond within 1-2 business days.' });
  } catch(err) { next(err); }
});

router.get('/enquiries', protect, restrictTo('admin'), async (req, res, next) => {
  try {
    const enquiries = await db.enquiries.findAsync({});
    enquiries.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
    res.json({ success:true, enquiries });
  } catch(err) { next(err); }
});

router.patch('/enquiries/:id/status', protect, restrictTo('admin'), async (req, res, next) => {
  try {
    const { status } = req.body;
    await db.enquiries.updateAsync({ _id:req.params.id }, { $set:{ status } });
    res.json({ success:true });
  } catch(err) { next(err); }
});

// ══════════════════════════════════════════════════════════════
//  TESTIMONIALS
// ══════════════════════════════════════════════════════════════
router.get('/testimonials', async (req, res, next) => {
  try {
    const testimonials = await db.testimonials.findAsync({ is_approved:true });
    testimonials.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
    res.json({ success:true, testimonials });
  } catch(err) { next(err); }
});

router.get('/testimonials/all', protect, restrictTo('admin'), async (req, res, next) => {
  try {
    const testimonials = await db.testimonials.findAsync({});
    testimonials.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
    res.json({ success:true, testimonials });
  } catch(err) { next(err); }
});

router.post('/testimonials', protect, async (req, res, next) => {
  try {
    const { message, rating } = req.body;
    if (!message || message.length < 10)
      return res.status(400).json({ error:'Message must be at least 10 characters.' });
    await db.testimonials.insertAsync({
      user_id:    req.user._id,
      name:       `${req.user.first_name} ${req.user.last_name}`,
      msg:        message,
      rating:     parseInt(rating) || 5,
      is_approved:false,
      created_at: new Date().toISOString()
    });
    res.status(201).json({ success:true, message:'Thank you! Your review is pending approval.' });
  } catch(err) { next(err); }
});

router.patch('/admin/testimonials/:id/approve', protect, restrictTo('admin'), async (req, res, next) => {
  try {
    await db.testimonials.updateAsync({ _id:req.params.id }, { $set:{ is_approved:true } });
    res.json({ success:true });
  } catch(err) { next(err); }
});

// ══════════════════════════════════════════════════════════════
//  ADMIN STATS
// ══════════════════════════════════════════════════════════════
router.get('/admin/stats', protect, restrictTo('admin'), async (req, res, next) => {
  try {
    const [allUsers, allBookings, allEnquiries, allTestimonials] = await Promise.all([
      db.users.findAsync({}),
      db.bookings.findAsync({}),
      db.enquiries.findAsync({}),
      db.testimonials.findAsync({}),
    ]);

    const stats = {
      total_users:       allUsers.filter(u => u.role !== 'admin').length,
      total_students:    allUsers.filter(u => u.role === 'student').length,
      total_staff:       allUsers.filter(u => u.role === 'staff').length,
      total_bookings:    allBookings.length,
      pending_bookings:  allBookings.filter(b => b.status === 'pending').length,
      confirmed_bookings:allBookings.filter(b => b.status === 'confirmed').length,
      new_enquiries:     allEnquiries.filter(e => e.status === 'new').length,
      total_revenue:     allBookings.filter(b => ['confirmed','completed'].includes(b.status)).reduce((s, b) => s + b.total_price, 0),
      pending_reviews:   allTestimonials.filter(t => !t.is_approved).length,
    };
    res.json({ success:true, stats });
  } catch(err) { next(err); }
});

router.get('/admin/users', protect, restrictTo('admin'), async (req, res, next) => {
  try {
    const users = await db.users.findAsync({});
    users.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
    const safe = users.map(u => { const s={...u}; delete s.password_hash; return s; });
    res.json({ success:true, users:safe });
  } catch(err) { next(err); }
});

router.patch('/admin/users/:id/toggle', protect, restrictTo('admin'), async (req, res, next) => {
  try {
    const user = await db.users.findOneAsync({ _id:req.params.id });
    if (!user) return res.status(404).json({ error:'User not found.' });
    await db.users.updateAsync({ _id:req.params.id }, { $set:{ is_active: !user.is_active } });
    res.json({ success:true });
  } catch(err) { next(err); }
});

module.exports = router;
