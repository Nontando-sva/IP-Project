// server/routes/auth.js
// GET /api/auth/me  POST /api/auth/login  POST /api/auth/register
// POST /api/auth/logout  PUT /api/auth/profile  PUT /api/auth/change-password
const express = require('express');
const router  = express.Router();
const bcrypt  = require('bcryptjs');
const jwt     = require('jsonwebtoken');
const db      = require('../../database/db');
const { protect } = require('../middleware/auth');

const SECRET      = process.env.JWT_SECRET || 'uni-drive-secret-2026';
const COOKIE_OPTS = { httpOnly:true, secure:process.env.NODE_ENV==='production', sameSite:'lax', maxAge:7*24*60*60*1000 };

const signToken = id => jwt.sign({ id }, SECRET, { expiresIn:'7d' });

const sendToken = (user, status, res) => {
  const safe = { ...user }; delete safe.password_hash;
  const token = signToken(user._id);
  res.cookie('token', token, COOKIE_OPTS);
  res.status(status).json({ success:true, token, user:safe });
};

// POST /api/auth/register
router.post('/register', async (req, res, next) => {
  try {
    const { first_name, last_name, email, password, role, student_number, phone } = req.body;
    if (!first_name || !last_name || !email || !password)
      return res.status(400).json({ error:'Please provide all required fields.' });
    if (password.length < 6)
      return res.status(400).json({ error:'Password must be at least 6 characters.' });

    const existing = await db.users.findOneAsync({ email: email.toLowerCase().trim() });
    if (existing) return res.status(400).json({ error:'An account with this email already exists.' });

    const hash = bcrypt.hashSync(password, 12);
    const user = await db.users.insertAsync({
      first_name: first_name.trim(),
      last_name:  last_name.trim(),
      email:      email.toLowerCase().trim(),
      password_hash: hash,
      role:       ['student','staff'].includes(role) ? role : 'student',
      student_number: student_number || '',
      phone:      phone || '',
      is_active:  true,
      created_at: new Date().toISOString(),
    });
    sendToken(user, 201, res);
  } catch(err) { next(err); }
});

// POST /api/auth/login
router.post('/login', async (req, res, next) => {
  try {
    const { email, password } = req.body;
    if (!email || !password)
      return res.status(400).json({ error:'Email and password are required.' });

    const user = await db.users.findOneAsync({ email: email.toLowerCase().trim(), is_active:true });
    if (!user || !bcrypt.compareSync(password, user.password_hash))
      return res.status(401).json({ error:'Incorrect email or password.' });

    sendToken(user, 200, res);
  } catch(err) { next(err); }
});

// POST /api/auth/logout
router.post('/logout', (req, res) => {
  res.cookie('token', '', { expires: new Date(0), httpOnly:true });
  res.json({ success:true });
});

// GET /api/auth/me
router.get('/me', protect, (req, res) => {
  res.json({ success:true, user:req.user });
});

// PUT /api/auth/profile
router.put('/profile', protect, async (req, res, next) => {
  try {
    const { first_name, last_name, phone, student_number } = req.body;
    await db.users.updateAsync(
      { _id: req.user._id },
      { $set: { first_name, last_name, phone: phone||'', student_number: student_number||'' } }
    );
    const updated = await db.users.findOneAsync({ _id: req.user._id });
    delete updated.password_hash;
    res.json({ success:true, user:updated });
  } catch(err) { next(err); }
});

// PUT /api/auth/change-password
router.put('/change-password', protect, async (req, res, next) => {
  try {
    const { current_password, new_password } = req.body;
    if (!new_password || new_password.length < 6)
      return res.status(400).json({ error:'New password must be at least 6 characters.' });

    const user = await db.users.findOneAsync({ _id: req.user._id });
    if (!bcrypt.compareSync(current_password, user.password_hash))
      return res.status(401).json({ error:'Current password is incorrect.' });

    const hash = bcrypt.hashSync(new_password, 12);
    await db.users.updateAsync({ _id: req.user._id }, { $set: { password_hash: hash } });
    res.json({ success:true, message:'Password updated successfully.' });
  } catch(err) { next(err); }
});

module.exports = router;
