// server/middleware/validate.js
const validateRegister = (req, res, next) => {
  const { first_name, last_name, email, password } = req.body;
  if (!first_name?.trim() || first_name.trim().length < 2)
    return res.status(400).json({ error:'First name must be at least 2 characters.' });
  if (!last_name?.trim() || last_name.trim().length < 2)
    return res.status(400).json({ error:'Last name must be at least 2 characters.' });
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
    return res.status(400).json({ error:'A valid email address is required.' });
  if (!password || password.length < 6)
    return res.status(400).json({ error:'Password must be at least 6 characters.' });
  next();
};

const validateBooking = (req, res, next) => {
  const { course_id, booking_date, booking_time } = req.body;
  if (!course_id) return res.status(400).json({ error:'Please select a course.' });
  if (!booking_date) return res.status(400).json({ error:'Please select a booking date.' });
  if (!booking_time) return res.status(400).json({ error:'Please select a time slot.' });
  next();
};

const validateEnquiry = (req, res, next) => {
  const { name, email, message } = req.body;
  if (!name?.trim() || name.trim().length < 2)
    return res.status(400).json({ error:'Please provide your name.' });
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
    return res.status(400).json({ error:'A valid email is required.' });
  if (!message?.trim() || message.trim().length < 10)
    return res.status(400).json({ error:'Message must be at least 10 characters.' });
  next();
};

const errorHandler = (err, req, res, next) => {
  console.error('\x1b[31m[ERROR]\x1b[0m', err.message);
  res.status(err.status || 500).json({ error: err.message || 'Internal server error.' });
};

module.exports = { validateRegister, validateBooking, validateEnquiry, errorHandler };
