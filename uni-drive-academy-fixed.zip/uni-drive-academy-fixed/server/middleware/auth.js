// server/middleware/auth.js
const jwt = require('jsonwebtoken');
const db  = require('../../database/db');

const SECRET = process.env.JWT_SECRET || 'uni-drive-secret-2026';

const protect = async (req, res, next) => {
  const token = req.cookies?.token || req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error:'Not authorised. Please log in.' });
  try {
    const decoded = jwt.verify(token, SECRET);
    const user = await db.users.findOneAsync({ _id: decoded.id, is_active:true });
    if (!user) return res.status(401).json({ error:'User not found.' });
    delete user.password_hash;
    req.user = user;
    next();
  } catch {
    return res.status(401).json({ error:'Invalid or expired token.' });
  }
};

const restrictTo = (...roles) => (req, res, next) => {
  if (!roles.includes(req.user.role))
    return res.status(403).json({ error:'Access denied.' });
  next();
};

const optionalAuth = async (req, res, next) => {
  const token = req.cookies?.token || req.headers.authorization?.split(' ')[1];
  if (token) {
    try {
      const decoded = jwt.verify(token, SECRET);
      const user = await db.users.findOneAsync({ _id: decoded.id, is_active:true });
      if (user) { delete user.password_hash; req.user = user; }
    } catch {}
  }
  next();
};

module.exports = { protect, restrictTo, optionalAuth };
