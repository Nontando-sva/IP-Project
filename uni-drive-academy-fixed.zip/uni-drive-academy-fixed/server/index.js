// server/index.js
// ═══════════════════════════════════════════════════════════════
//  UNI-DRIVE ACADEMY — Express Server
//  Middleware: logger, body parsing, cookie, cors, rate limiting
//  Routes: /api/auth, /api (courses, bookings, faq, admin)
//  SPA fallback: serves index.html for all non-API routes
// ═══════════════════════════════════════════════════════════════
require('dotenv').config();

const express      = require('express');
const cookieParser = require('cookie-parser');
const rateLimit    = require('express-rate-limit');
const cors         = require('cors');
const path         = require('path');

const authRoutes       = require('./routes/auth');
const apiRoutes        = require('./routes/api');
const { errorHandler } = require('./middleware/validate');

const app = express();

// ── 1. REQUEST LOGGER ─────────────────────────────────────────
// Logs every API request: method, path, status, response time
app.use((req, res, next) => {
  const start = Date.now();
  res.on('finish', () => {
    if (!req.path.startsWith('/api')) return;
    const ms  = Date.now() - start;
    const col = res.statusCode >= 400 ? '\x1b[31m' : '\x1b[32m';
    console.log(`${col}[${new Date().toLocaleTimeString()}] ${req.method} ${req.path} → ${res.statusCode} (${ms}ms)\x1b[0m`);
  });
  next();
});

// ── 2. BODY PARSING ────────────────────────────────────────────
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

// ── 3. CORS ────────────────────────────────────────────────────
app.use(cors({ origin: true, credentials: true }));

// ── 4. RATE LIMITING ───────────────────────────────────────────
// General API limit: 200 requests per 15 minutes
const generalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 200,
  message: { error: 'Too many requests. Please try again later.' }
});
// Strict limit for login/register to prevent brute-force
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 15,
  message: { error: 'Too many attempts. Please try again in 15 minutes.' }
});
app.use('/api/', generalLimiter);
app.use('/api/auth/login',    authLimiter);
app.use('/api/auth/register', authLimiter);

// ── 5. STATIC FILES ────────────────────────────────────────────
app.use(express.static(path.join(__dirname, '..', 'public')));

// ── 6. API ROUTES ──────────────────────────────────────────────
app.use('/api/auth', authRoutes);   // auth: register, login, logout, profile
app.use('/api',      apiRoutes);    // courses, bookings, faq, enquiries, admin

// ── 7. SPA FALLBACK ────────────────────────────────────────────
// Any non-API route serves index.html (Single Page Application)
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

// ── 8. GLOBAL ERROR HANDLER (must be last) ────────────────────
app.use(errorHandler);

// ── START ──────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log('\n╔══════════════════════════════════════════════╗');
  console.log(`║  🚗  Uni-Drive Academy                       ║`);
  console.log(`║      http://localhost:${PORT}                   ║`);
  console.log('╠══════════════════════════════════════════════╣');
  console.log('║  Demo Accounts:                              ║');
  console.log('║  admin@unidrive.ac.za  / admin123            ║');
  console.log('║  thabo@mut.ac.za       / student123          ║');
  console.log('║  naledi@mut.ac.za      / staff123            ║');
  console.log('╚══════════════════════════════════════════════╝\n');
});

module.exports = app;
