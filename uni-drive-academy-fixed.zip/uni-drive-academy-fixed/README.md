# 🚗 Uni-Drive Academy
### Internet Programming 2 — Assessment 3 | ITNP300/ITPR300
**Mangosuthu University of Technology — ICT Department**

---

## 👥 Group Members
| Name | Role |
|---|---|
| Cele B.X | External Stakeholders & Frontend |
| Gumbi M.P | Human Resources & Backend Auth |
| Hlongwane N | Finance & Database Design |
| Phungula L | Maintenance & API Routes |
| Makhathini P.S | Marketing & AI/FAQ Feature |

---

## 🚀 Quick Start (Windows, Mac, Linux)

### Step 1 — Install Node.js
Download from https://nodejs.org (version 18 or higher)

### Step 2 — Open Terminal in the project folder
```
cd uni-drive-academy
```

### Step 3 — Install dependencies
```
npm install
```

### Step 4 — Start the server
```
npm run dev
```

### Step 5 — Open your browser
```
http://localhost:3000
```

> **No database setup needed.** The database creates itself automatically on first run.

---

## 🔑 Demo Accounts

| Role    | Email                      | Password    |
|---------|----------------------------|-------------|
| Admin   | admin@unidrive.ac.za       | admin123    |
| Student | thabo@mut.ac.za            | student123  |
| Staff   | naledi@mut.ac.za           | staff123    |

---

## 📁 Project Structure

```
uni-drive-academy/
├── server/
│   ├── index.js                ← Express server + all middleware
│   ├── routes/
│   │   ├── auth.js             ← Register, Login, Logout, Profile
│   │   └── api.js              ← Courses, Bookings, FAQ AI, Admin
│   └── middleware/
│       ├── auth.js             ← JWT protect + role checks
│       └── validate.js         ← Input validation + error handler
├── database/
│   ├── db.js                   ← NeDB setup + seed data
│   └── data/                   ← Auto-created JSON data files
├── public/
│   ├── index.html              ← Single Page Application
│   ├── css/style.css           ← Complete responsive stylesheet
│   └── js/app.js               ← All frontend JavaScript
├── .env.example                ← Environment variables template
├── package.json
└── README.md
```

---

## 🌐 Pages & Features

| Page | What It Does |
|---|---|
| Home | Hero section, course previews, testimonials, why us |
| Courses | All 7 programmes with student/staff pricing toggle |
| Instructors | Instructor profiles with licence codes |
| Book a Lesson | Date picker, time slots, booking confirmation |
| FAQ | AI-powered NLP search + accordion of all FAQs |
| Contact | Enquiry form with validation |
| Dashboard | Student/staff bookings, profile, leave a review |
| Admin | Stats, manage bookings/users/enquiries/reviews |

---

## 🤖 AI Feature — NLP FAQ Search

The FAQ search uses **keyword scoring** — a rule-based NLP approach:

1. User types a natural language question
2. Query is tokenised into individual words
3. Each FAQ entry is scored:
   - **+3 points** per keyword match
   - **+2 points** per question text match
   - **+1 point** per answer text match
   - **+10 points** for exact phrase match
4. Top 3 results returned ranked by relevance score
5. Fallback message with contact info if no match found

**Endpoint:** `POST /api/faq/search`

---

## 🔒 Security Features

| Feature | Implementation |
|---|---|
| Password Hashing | bcryptjs with 12 salt rounds |
| Authentication | JWT stored in httpOnly cookie (7 day expiry) |
| Rate Limiting | 200 req/15min general, 15 req/15min for auth |
| Input Validation | Custom validators on all POST/PUT routes |
| Role-Based Access | student / staff / admin middleware guards |
| Error Handling | Global error handler catches all unhandled errors |

---

## 📡 REST API Endpoints

```
Authentication
  POST   /api/auth/register           Create new account
  POST   /api/auth/login              Login
  POST   /api/auth/logout             Logout
  GET    /api/auth/me                 Get current user
  PUT    /api/auth/profile            Update profile
  PUT    /api/auth/change-password    Change password

Courses
  GET    /api/courses                 List all active courses
  GET    /api/courses/:id             Get single course

Bookings
  GET    /api/bookings                My bookings (admin = all)
  POST   /api/bookings                Create booking
  PATCH  /api/bookings/:id/status     Update status (admin)
  DELETE /api/bookings/:id            Cancel booking

FAQ
  GET    /api/faq                     All FAQs
  POST   /api/faq/search              AI-powered NLP search

Enquiries
  POST   /api/enquiries               Submit contact form
  GET    /api/enquiries               All enquiries (admin)
  PATCH  /api/enquiries/:id/status    Mark read (admin)

Testimonials
  GET    /api/testimonials            Approved testimonials
  GET    /api/testimonials/all        All testimonials (admin)
  POST   /api/testimonials            Submit review
  PATCH  /api/admin/testimonials/:id/approve  Approve (admin)

Admin
  GET    /api/admin/stats             Dashboard statistics
  GET    /api/admin/users             All users
  PATCH  /api/admin/users/:id/toggle  Activate/deactivate user
```

---

## 🎓 Assessment 3 Learning Units Covered

| Learning Unit | Implementation |
|---|---|
| Node.js & Server-side | Express server, async routing, middleware chain |
| RESTful APIs | GET/POST/PUT/PATCH/DELETE with proper HTTP codes |
| UX Design | Responsive SPA, MUT-branded, accessible, mobile-ready |
| Full-stack Integration | Frontend ↔ REST API ↔ NeDB database seamlessly |
| Database & CRUD | NeDB with full Create/Read/Update/Delete on all models |
| AI / Intelligent Feature | NLP keyword scoring for FAQ instant search |
| Security | JWT auth, bcrypt hashing, rate limiting, validation |
| Deployment Readiness | .env config, error handling, production-ready structure |

---

## 💡 Entrepreneurship Reflection

Uni-Drive Academy solves a real problem at MUT — students struggle to access affordable, convenient driving licences that improve employment prospects after graduation.

**Scaling opportunities:**
- Expand to other universities (UKZN, DUT, TUT)
- Mobile app for lesson tracking and progress
- Online payment integration (PayFast, SnapScan)
- Automated DLTC appointment booking
- WhatsApp booking via Twilio API

**GitHub Collaborator:** xpiyose (xpiyose@gmail.com)
