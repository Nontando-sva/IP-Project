// public/js/app.js — Uni-Drive Academy Frontend
'use strict';

// ── STATE ─────────────────────────────────────────────────────
let currentUser   = null;
let allCourses    = [];
let allBookings   = [];      // cached for filtering
let allUsers      = [];      // cached for admin user search
let selectedRating = 5;
let currentBookingFilter = 'all';

// ── INIT ──────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  await checkAuth();
  setMinDate();
  if (!currentUser) {
    goto('login');
  } else {
    goto(currentUser.role === 'admin' ? 'admin' : 'dashboard');
  }
});

// ── ROUTER ────────────────────────────────────────────────────
function goto(page) {
  const publicPages = ['login', 'register'];
  if (!currentUser && !publicPages.includes(page)) {
    page = 'login';
    toast('Please login to access the site.', 'info');
  }

  document.querySelectorAll('.pg').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nl[data-p]').forEach(l => l.classList.toggle('active', l.dataset.p === page));

  const el = document.getElementById('pg-' + page);
  if (el) el.classList.add('active');

  window.scrollTo({ top: 0, behavior: 'smooth' });
  document.getElementById('navLinks').classList.remove('open');

  const loaders = {
    home:        loadHome,
    courses:     loadCourses,
    instructors: loadInstructors,
    book:        loadBookPage,
    faq:         loadFaq,
    dashboard:   loadDashboard,
    admin:       loadAdmin,
  };
  if (loaders[page]) loaders[page]();
}

function toggleNav() {
  document.getElementById('navLinks').classList.toggle('open');
}

// ── API HELPER ────────────────────────────────────────────────
async function api(url, opts = {}) {
  const cfg = { headers:{'Content-Type':'application/json'}, credentials:'include', ...opts };
  if (opts.body && typeof opts.body === 'object') cfg.body = JSON.stringify(opts.body);
  const res  = await fetch(url, cfg);
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

// ── AUTH ──────────────────────────────────────────────────────
async function checkAuth() {
  try {
    const { user } = await api('/api/auth/me');
    currentUser = user;
  } catch { currentUser = null; }
  renderNav();
}

function renderNav() {
  const area = document.getElementById('authArea');
  const mobileLogout = document.querySelector('.logout-link.mobile-only');
  if (!currentUser) {
    area.innerHTML = `<a class="nl nav-cta" onclick="goto('login')">Login</a>`;
    if (mobileLogout) mobileLogout.style.display = 'none';
    return;
  }
  const initials = (currentUser.first_name[0] + currentUser.last_name[0]).toUpperCase();
  const dash = currentUser.role === 'admin' ? 'admin' : 'dashboard';
  area.innerHTML = `
    <a class="nl" onclick="goto('${dash}')" style="display:flex;align-items:center;gap:.5rem">
      <span class="nav-avatar">${initials}</span>
      <span>${currentUser.first_name}</span>
    </a>
    <a class="nl logout-link desktop-only" onclick="doLogout()">Logout</a>`;
  if (mobileLogout) mobileLogout.style.display = 'block';
}

async function doLogin(e) {
  e.preventDefault();
  const msgEl = document.getElementById('loginMsg');
  clearMsg(msgEl);
  try {
    const { user } = await api('/api/auth/login', { method:'POST', body:{
      email:    document.getElementById('loginEmail').value,
      password: document.getElementById('loginPw').value,
    }});
    currentUser = user;
    renderNav();
    toast(`Welcome back, ${user.first_name}! 🚗`, 'success');
    goto(user.role === 'admin' ? 'admin' : 'dashboard');
  } catch(err) { showMsg(msgEl, err.message, 'error'); }
}

async function doRegister(e) {
  e.preventDefault();
  const msgEl = document.getElementById('regMsg');
  clearMsg(msgEl);
  try {
    const { user } = await api('/api/auth/register', { method:'POST', body:{
      first_name:    document.getElementById('regFirst').value,
      last_name:     document.getElementById('regLast').value,
      email:         document.getElementById('regEmail').value,
      password:      document.getElementById('regPw').value,
      role:          document.getElementById('regRole').value,
      student_number:document.getElementById('regSn').value,
      phone:         document.getElementById('regPhone').value,
    }});
    currentUser = user;
    renderNav();
    toast(`Account created! Welcome, ${user.first_name}! 🎉`, 'success');
    goto('dashboard');
  } catch(err) { showMsg(msgEl, err.message, 'error'); }
}

async function doLogout() {
  try { await api('/api/auth/logout', { method:'POST' }); } catch {}
  currentUser = null;
  allBookings  = [];
  allUsers     = [];
  renderNav();
  goto('login');
  toast('Logged out successfully.', 'info');
}

function toggleStudentFields() {
  const role = document.getElementById('regRole').value;
  const el   = document.getElementById('regSnGroup');
  el.style.display = role === 'student' ? 'flex' : 'none';
}

// ── HOME ──────────────────────────────────────────────────────
async function loadHome() {
  loadHomeCourses();
  loadTestimonials();
}

async function loadHomeCourses() {
  try {
    if (!allCourses.length) {
      const { courses } = await api('/api/courses');
      allCourses = courses;
    }
    const icons  = {LEARNERS:'📋',CODE_A:'🏍️',CODE_8:'🚗',CODE_10:'🚛',CODE_10_ADV:'🚛',CODE_14:'🚚',CODE_14_ADV:'🚚'};
    const colors = {LEARNERS:'#7a5a00',CODE_A:'#1a2744',CODE_8:'#1a6b3a',CODE_10:'#2d3a2d',CODE_10_ADV:'#1d4a1d',CODE_14:'#1a2744',CODE_14_ADV:'#0e1a33'};
    const main = allCourses.filter(c => ['LEARNERS','CODE_A','CODE_8','CODE_14'].includes(c.code));
    document.getElementById('homeCourses').innerHTML =
      main.map(c => `
        <div class="course-card" onclick="goto('book')">
          <div class="cc-top" style="background:${colors[c.code]||'#1a6b3a'}">
            <div class="cc-icon">${icons[c.code]||'🚗'}</div>
            <div class="cc-name">${c.name}</div>
            <div class="cc-dur">${c.duration}</div>
          </div>
          <div class="cc-body">
            <p class="cc-desc">${c.desc.substring(0,90)}…</p>
            <div class="cc-price">R ${c.price_student.toLocaleString()}</div>
            <div class="cc-price-sub">Student price</div>
          </div>
        </div>`).join('') +
      `<div class="course-card add-more" onclick="goto('courses')">
         <div style="font-size:2rem;margin-bottom:.5rem">➕</div>
         <div style="font-weight:700">View All Courses</div>
       </div>`;
  } catch { document.getElementById('homeCourses').innerHTML = '<p class="text-muted">Could not load courses.</p>'; }
}

async function loadTestimonials() {
  try {
    const { testimonials } = await api('/api/testimonials');
    const el = document.getElementById('homeTestimonials');
    if (!testimonials.length) { el.innerHTML = '<p class="text-muted">No testimonials yet.</p>'; return; }
    el.innerHTML = testimonials.map(t => `
      <div class="test-card">
        <div class="test-stars">${'★'.repeat(t.rating)}</div>
        <p class="test-msg">"${t.msg}"</p>
        <div class="test-name">— ${t.name}</div>
      </div>`).join('');
  } catch {}
}

// ── COURSES ───────────────────────────────────────────────────
let priceMode = 'student';
async function loadCourses() {
  try {
    if (!allCourses.length) {
      const { courses } = await api('/api/courses');
      allCourses = courses;
    }
    renderCourses();
  } catch { document.getElementById('coursesGrid').innerHTML = '<p class="text-muted">Could not load courses.</p>'; }
}

function setPriceMode(mode) {
  priceMode = mode;
  document.getElementById('ptStudent').classList.toggle('active', mode === 'student');
  document.getElementById('ptStaff').classList.toggle('active', mode === 'staff');
  renderCourses();
}

function renderCourses() {
  const icons  = {LEARNERS:'📋',CODE_A:'🏍️',CODE_8:'🚗',CODE_10:'🚛',CODE_10_ADV:'🚛',CODE_14:'🚚',CODE_14_ADV:'🚚'};
  const colors = {LEARNERS:'#7a5a00',CODE_A:'#1a2744',CODE_8:'#1a6b3a',CODE_10:'#2d3a2d',CODE_10_ADV:'#1d4a1d',CODE_14:'#1a2744',CODE_14_ADV:'#0e1a33'};
  document.getElementById('coursesGrid').innerHTML = allCourses.map(c => `
    <div class="cdc-card">
      <div class="cdc-header" style="background:${colors[c.code]||'#1a6b3a'}">
        <div>
          <div class="cdc-code">${c.code}</div>
          <h3>${icons[c.code]||'🚗'} ${c.name}</h3>
          <span class="vehicle-tag">${c.vehicle}</span>
        </div>
        <span class="dur-badge">📅 ${c.duration}</span>
      </div>
      <div class="cdc-body">
        <p class="cdc-desc">${c.desc}</p>
        <div class="price-table">
          <div class="price-row"><span>Student</span><strong>R ${c.price_student.toLocaleString()}</strong></div>
          <div class="price-row"><span>Staff</span><strong>R ${c.price_staff.toLocaleString()}</strong></div>
        </div>
        <div>
          <button class="btn btn-primary btn-sm" onclick="goto('book')">Book Now</button>
        </div>
      </div>
    </div>`).join('');
}

// ── INSTRUCTORS ───────────────────────────────────────────────
async function loadInstructors() {
  try {
    const { instructors } = await api('/api/instructors');
    document.getElementById('instructorsGrid').innerHTML = instructors.map(i => {
      const initials = i.full_name.split(' ').filter(w=>w.length>1).map(w=>w[0]).join('').substring(0,2).toUpperCase();
      return `
      <div class="inst-card">
        <div class="inst-avatar">${initials}</div>
        <h4>${i.full_name}</h4>
        <div class="inst-codes">Licences: ${i.licence_codes}</div>
        <p>${i.bio}</p>
      </div>`;
    }).join('');
  } catch { document.getElementById('instructorsGrid').innerHTML = '<p class="text-muted">Could not load instructors.</p>'; }
}

// ── BOOK PAGE ─────────────────────────────────────────────────
async function loadBookPage() {
  if (!currentUser) {
    document.getElementById('bookGate').classList.remove('hidden');
    document.getElementById('bookContent').classList.add('hidden');
    return;
  }
  document.getElementById('bookGate').classList.add('hidden');
  document.getElementById('bookContent').classList.remove('hidden');
  await loadBookingCourses();
  loadMyBookings();
}

async function loadBookingCourses() {
  try {
    if (!allCourses.length) {
      const { courses } = await api('/api/courses');
      allCourses = courses;
    }
    const sel = document.getElementById('bkCourse');
    sel.innerHTML = '<option value="">Choose a course…</option>' +
      allCourses.map(c => `<option value="${c._id}">${c.name} — R${(currentUser.role==='staff'?c.price_staff:c.price_student).toLocaleString()}</option>`).join('');
  } catch {}
}

function setMinDate() {
  const inp = document.getElementById('bkDate');
  if (inp) {
    const today = new Date();
    inp.min = today.toISOString().split('T')[0];
  }
}

function updateBookingPrice() {
  const cid = document.getElementById('bkCourse').value;
  const box = document.getElementById('bkPriceBox');
  if (!cid || !allCourses.length) { box.classList.add('hidden'); return; }
  const c = allCourses.find(x => x._id === cid);
  if (!c) { box.classList.add('hidden'); return; }
  const price = currentUser.role === 'staff' ? c.price_staff : c.price_student;
  document.getElementById('bkPriceAmt').textContent = `R ${price.toLocaleString()}`;
  box.classList.remove('hidden');
}

function loadTimeSlots() {
  const date = document.getElementById('bkDate').value;
  const wrap = document.getElementById('slotsWrapper');
  const grid = document.getElementById('slotsGrid');
  const hiddenTime = document.getElementById('bkTime');
  if (!date) { wrap.style.display = 'none'; return; }
  wrap.style.display = 'flex';
  hiddenTime.value = '';
  const times = ['07:30','08:30','09:00','09:30','10:00','10:30','11:00','11:30','12:00','13:00','14:00','14:30','15:00','15:30','16:00','16:30','17:00','17:30'];
  grid.innerHTML = times.map(t => `<button type="button" class="slot-btn" onclick="selectTime('${t}',this)">${t}</button>`).join('');
}

function selectTime(t, btn) {
  document.querySelectorAll('.slot-btn').forEach(b => b.classList.remove('selected'));
  btn.classList.add('selected');
  document.getElementById('bkTime').value = t;
}

async function submitBooking(e) {
  e.preventDefault();
  const msgEl = document.getElementById('bookMsg');
  clearMsg(msgEl);
  const time = document.getElementById('bkTime').value;
  if (!time) { showMsg(msgEl, 'Please select a time slot.', 'error'); return; }
  try {
    await api('/api/bookings', { method:'POST', body:{
      course_id:    document.getElementById('bkCourse').value,
      booking_date: document.getElementById('bkDate').value,
      booking_time: time,
      notes:        document.getElementById('bkNotes').value,
    }});
    showMsg(msgEl, '✅ Booking confirmed! Check your bookings below.', 'success');
    e.target.reset();
    document.getElementById('bkPriceBox').classList.add('hidden');
    document.getElementById('slotsWrapper').style.display = 'none';
    document.getElementById('bkTime').value = '';
    toast('Booking confirmed!', 'success');
    allBookings = []; // invalidate cache
    loadMyBookings();
    // also refresh dashboard stats if loaded
    if (document.getElementById('pg-dashboard').classList.contains('active')) {
      loadDashboardStats();
    }
  } catch(err) { showMsg(msgEl, err.message, 'error'); }
}

async function fetchBookings() {
  const { bookings } = await api('/api/bookings');
  allBookings = bookings;
  return bookings;
}

async function loadMyBookings() {
  const list = document.getElementById('myBookingsList');
  if (!list) return;
  try {
    const bookings = allBookings.length ? allBookings : await fetchBookings();
    renderBookingList(list, bookings);
  } catch { list.innerHTML = '<p class="text-muted">Could not load bookings.</p>'; }
}

function renderBookingList(container, bookings) {
  const filtered = currentBookingFilter === 'all' ? bookings : bookings.filter(b => b.status === currentBookingFilter);
  if (!filtered.length) {
    container.innerHTML = '<p class="text-muted" style="font-size:14px;padding:.5rem 0">No bookings found.</p>';
    return;
  }
  container.innerHTML = filtered.map(b => `
    <div class="bk-item">
      <div class="bk-hdr">
        <div class="bk-course">${b.course_name}</div>
        <span class="badge badge-${b.status}">${b.status}</span>
      </div>
      <div class="bk-meta">📅 ${b.booking_date} &nbsp; 🕐 ${b.booking_time} &nbsp; 💰 R${b.total_price.toLocaleString()}</div>
      ${b.notes ? `<div class="bk-meta">📝 ${b.notes}</div>` : ''}
      ${['pending','confirmed'].includes(b.status) ? `
        <div style="margin-top:.65rem">
          <button class="btn btn-sm btn-red" onclick="cancelBooking('${b._id}')">Cancel</button>
        </div>` : ''}
    </div>`).join('');
}

function filterBookings(status, btn) {
  currentBookingFilter = status;
  document.querySelectorAll('.bfilter').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  const list = document.getElementById('myBookingsList');
  renderBookingList(list, allBookings);
}

async function cancelBooking(id) {
  if (!confirm('Cancel this booking?')) return;
  try {
    await api(`/api/bookings/${id}`, { method:'DELETE' });
    toast('Booking cancelled.', 'info');
    allBookings = []; // invalidate
    loadMyBookings();
    loadDashboardStats();
  } catch(err) { toast(err.message, 'error'); }
}

// ── FAQ ───────────────────────────────────────────────────────
async function loadFaq() {
  try {
    const { faqs } = await api('/api/faq');
    document.getElementById('faqAccordion').innerHTML = faqs.map((f, i) => `
      <div class="acc-item">
        <button class="acc-q" onclick="toggleAcc(${i},this)">
          <span>${f.q}</span><span class="acc-arr">▼</span>
        </button>
        <div class="acc-a" id="acc-${i}">${f.a}</div>
      </div>`).join('');
  } catch { document.getElementById('faqAccordion').innerHTML = '<p class="text-muted">Could not load FAQs.</p>'; }
}

function toggleAcc(i, btn) {
  btn.classList.toggle('open');
  const ans = document.getElementById('acc-' + i);
  ans.classList.toggle('show');
}

async function searchFaq() {
  const q = document.getElementById('faqInput').value.trim();
  const resDiv = document.getElementById('faqResults');
  if (!q) return;
  resDiv.classList.remove('hidden');
  resDiv.innerHTML = '<div class="faq-result-card" style="opacity:.6;color:#fff">Searching…</div>';
  try {
    const { results, suggestion } = await api('/api/faq/search', { method:'POST', body:{ question:q } });
    if (!results.length) {
      resDiv.innerHTML = `<div class="faq-no-result">🤖 ${suggestion}</div>`;
    } else {
      resDiv.innerHTML = results.map(r => `
        <div class="faq-result-card">
          <div class="faq-rq">❓ ${r.q}</div>
          <div class="faq-ra">✅ ${r.a}</div>
        </div>`).join('');
    }
  } catch { resDiv.innerHTML = '<div class="faq-no-result">Search unavailable. Please try again.</div>'; }
}

// ── CONTACT ───────────────────────────────────────────────────
async function submitEnquiry(e) {
  e.preventDefault();
  const msgEl = document.getElementById('contactMsg');
  clearMsg(msgEl);
  try {
    await api('/api/enquiries', { method:'POST', body:{
      name:    document.getElementById('cName').value,
      email:   document.getElementById('cEmail').value,
      phone:   document.getElementById('cPhone').value,
      message: document.getElementById('cMsg').value,
    }});
    showMsg(msgEl, '✅ Message sent! We will respond within 1-2 business days.', 'success');
    e.target.reset();
    toast('Message sent!', 'success');
  } catch(err) { showMsg(msgEl, err.message, 'error'); }
}

// ── CUSTOMER DASHBOARD ────────────────────────────────────────
async function loadDashboard() {
  if (!currentUser) { goto('login'); return; }

  const initials = (currentUser.first_name[0] + currentUser.last_name[0]).toUpperCase();
  document.getElementById('dashAvatar').textContent   = initials;
  document.getElementById('dashTitle').textContent    = `Welcome, ${currentUser.first_name}!`;
  document.getElementById('dashSub').textContent      = `${currentUser.role === 'staff' ? 'Staff' : 'Student'} Portal`;
  document.getElementById('dashEmail').textContent    = currentUser.email;

  await loadDashboardStats();
  loadDashOverview();
  // default tab is overview — also pre-load profile form
  loadProfileForm();
}

async function loadDashboardStats() {
  try {
    const bookings = allBookings.length ? allBookings : await fetchBookings();
    const total     = bookings.length;
    const upcoming  = bookings.filter(b => ['pending','confirmed'].includes(b.status)).length;
    const completed = bookings.filter(b => b.status === 'completed').length;
    document.getElementById('dhsTotalBookings').textContent = total;
    document.getElementById('dhsUpcoming').textContent      = upcoming;
    document.getElementById('dhsCompleted').textContent     = completed;
  } catch {}
}

async function loadDashOverview() {
  // Upcoming lessons
  const ovList = document.getElementById('ovUpcomingList');
  try {
    const bookings = allBookings.length ? allBookings : await fetchBookings();
    const upcoming = bookings.filter(b => ['pending','confirmed'].includes(b.status)).slice(0,3);
    if (!upcoming.length) {
      ovList.innerHTML = '<p class="text-muted" style="font-size:13px">No upcoming lessons. <a onclick="goto(\'book\')">Book one now →</a></p>';
    } else {
      ovList.innerHTML = upcoming.map(b => `
        <div class="ov-upcoming-item">
          <div>
            <div style="font-weight:700;font-size:13px">${b.course_name}</div>
            <div class="tbl-sub">${b.booking_date} at ${b.booking_time}</div>
          </div>
          <span class="badge badge-${b.status}">${b.status}</span>
        </div>`).join('');
    }
  } catch { ovList.innerHTML = '<p class="text-muted" style="font-size:13px">Could not load.</p>'; }

  // Available courses
  const ovCourses = document.getElementById('ovCourseList');
  try {
    if (!allCourses.length) {
      const { courses } = await api('/api/courses');
      allCourses = courses;
    }
    ovCourses.innerHTML = allCourses.slice(0,4).map(c => `
      <div class="ov-course-item">
        <span style="font-size:13px">${c.name}</span>
        <strong style="color:var(--green);font-size:13px">R${(currentUser.role==='staff'?c.price_staff:c.price_student).toLocaleString()}</strong>
      </div>`).join('') + `<div style="margin-top:.5rem"><a onclick="goto('courses')" style="font-size:12px;color:var(--green)">View all courses →</a></div>`;
  } catch {}
}

function loadProfileForm() {
  if (!currentUser) return;
  document.getElementById('pFirst').value = currentUser.first_name   || '';
  document.getElementById('pLast').value  = currentUser.last_name    || '';
  document.getElementById('pEmail').value = currentUser.email        || '';
  document.getElementById('pPhone').value = currentUser.phone        || '';
  document.getElementById('pSn').value    = currentUser.student_number || '';
  if (currentUser.role !== 'student')
    document.getElementById('pSnGroup').style.display = 'none';

  // Role badge
  const badges = document.getElementById('profileBadgeRow');
  if (badges) {
    badges.innerHTML = `
      <span class="role-badge role-${currentUser.role}">${currentUser.role}</span>
      <span class="badge badge-confirmed">Active Account</span>
      ${currentUser.student_number ? `<span class="badge badge-completed">SN: ${currentUser.student_number}</span>` : ''}`;
  }
}

async function updateProfile(e) {
  e.preventDefault();
  const msgEl = document.getElementById('profileMsg');
  clearMsg(msgEl);
  try {
    const { user } = await api('/api/auth/profile', { method:'PUT', body:{
      first_name:     document.getElementById('pFirst').value,
      last_name:      document.getElementById('pLast').value,
      phone:          document.getElementById('pPhone').value,
      student_number: document.getElementById('pSn').value,
    }});
    currentUser = user;
    renderNav();
    document.getElementById('dashTitle').textContent = `Welcome, ${user.first_name}!`;
    document.getElementById('dashAvatar').textContent = (user.first_name[0] + user.last_name[0]).toUpperCase();
    loadProfileForm();
    showMsg(msgEl, 'Profile updated successfully!', 'success');
    toast('Profile saved!', 'success');
  } catch(err) { showMsg(msgEl, err.message, 'error'); }
}

async function changePassword(e) {
  e.preventDefault();
  const msgEl = document.getElementById('pwMsg');
  clearMsg(msgEl);
  const nw = document.getElementById('pwNew').value;
  const cf = document.getElementById('pwConf').value;
  if (nw !== cf) { showMsg(msgEl, 'Passwords do not match.', 'error'); return; }
  try {
    await api('/api/auth/change-password', { method:'PUT', body:{
      current_password: document.getElementById('pwCur').value,
      new_password: nw,
    }});
    showMsg(msgEl, '✅ Password updated successfully!', 'success');
    e.target.reset();
  } catch(err) { showMsg(msgEl, err.message, 'error'); }
}

function dashTab(name, btn) {
  document.querySelectorAll('.dtab').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.dtab-panel').forEach(p => p.classList.add('hidden'));
  btn.classList.add('active');
  document.getElementById('dtab-' + name).classList.remove('hidden');
  if (name === 'bookings') {
    allBookings = [];
    currentBookingFilter = 'all';
    document.querySelectorAll('.bfilter').forEach((b,i) => b.classList.toggle('active', i===0));
    loadMyBookings();
  }
  if (name === 'overview') loadDashOverview();
}

function setRating(r) {
  selectedRating = r;
  document.querySelectorAll('.star').forEach((s, i) => s.classList.toggle('active', i < r));
}

async function submitReview(e) {
  e.preventDefault();
  const msgEl = document.getElementById('reviewStatus');
  clearMsg(msgEl);
  try {
    await api('/api/testimonials', { method:'POST', body:{
      message: document.getElementById('reviewMsg').value,
      rating:  selectedRating,
    }});
    showMsg(msgEl, '✅ Thank you! Your review is pending approval.', 'success');
    e.target.reset();
    setRating(5);
  } catch(err) { showMsg(msgEl, err.message, 'error'); }
}

// ── ADMIN DASHBOARD ───────────────────────────────────────────
async function loadAdmin() {
  if (!currentUser || currentUser.role !== 'admin') { goto('login'); return; }

  // Set date in admin hero
  const dateEl = document.getElementById('adminHeroDate');
  if (dateEl) {
    const now = new Date();
    dateEl.textContent = now.toLocaleDateString('en-ZA', { weekday:'long', year:'numeric', month:'long', day:'numeric' });
  }

  loadAdminStats();
  loadAdminBookings();
}

async function loadAdminStats() {
  try {
    const { stats } = await api('/api/admin/stats');
    document.getElementById('adminStats').innerHTML = [
      ['Total Users',    stats.total_users,        '#1a6b3a', '👥'],
      ['Students',       stats.total_students,     '#1a2744', '🎓'],
      ['Staff',          stats.total_staff,        '#5a6b5a', '👤'],
      ['Pending',        stats.pending_bookings,   '#c8a030', '⏳'],
      ['Confirmed',      stats.confirmed_bookings, '#1a6b3a', '✅'],
      ['All Bookings',   stats.total_bookings,     '#1a2744', '📋'],
      ['New Enquiries',  stats.new_enquiries,      '#dc2626', '✉️'],
      ['Revenue',        'R '+stats.total_revenue.toLocaleString(), '#1a6b3a', '💰'],
    ].map(([l,v,c,ic]) => `
      <div class="ast">
        <div class="ast-label">${ic} ${l}</div>
        <div class="ast-val" style="color:${c}">${v}</div>
      </div>`).join('');
  } catch {}
}

let allAdminBookings = [];
async function loadAdminBookings() {
  try {
    const { bookings } = await api('/api/bookings');
    allAdminBookings = bookings;
    document.getElementById('adminBkCount').textContent = `(${bookings.length} total)`;
    renderAdminBookingTable(bookings);
  } catch {}
}

function renderAdminBookingTable(bookings) {
  const tbody = document.getElementById('adminBkBody');
  if (!bookings.length) { tbody.innerHTML = '<tr><td colspan="8" class="tbl-empty">No bookings.</td></tr>'; return; }
  tbody.innerHTML = bookings.map(b => `
    <tr>
      <td>${b._id.substring(0,8)}…</td>
      <td><strong>${b.student_name}</strong><br/><span class="tbl-sub">${b.student_email}</span></td>
      <td>${b.course_name}</td>
      <td>${b.booking_date}</td>
      <td>${b.booking_time}</td>
      <td>R${b.total_price.toLocaleString()}</td>
      <td><span class="badge badge-${b.status}">${b.status}</span></td>
      <td class="tbl-actions">
        ${b.status==='pending'    ? `<button class="btn btn-xs btn-green" onclick="adminBkStatus('${b._id}','confirmed')">✅ Confirm</button>` : ''}
        ${['pending','confirmed'].includes(b.status) ? `<button class="btn btn-xs btn-red" onclick="adminBkStatus('${b._id}','cancelled')">❌ Cancel</button>` : ''}
        ${b.status==='confirmed'  ? `<button class="btn btn-xs btn-ghost" onclick="adminBkStatus('${b._id}','completed')">✔ Done</button>` : ''}
      </td>
    </tr>`).join('');
}

function filterAdminBookings(status) {
  const filtered = status ? allAdminBookings.filter(b => b.status === status) : allAdminBookings;
  renderAdminBookingTable(filtered);
}

async function loadAdminAppointments() {
  try {
    const { bookings } = await api('/api/bookings');
    const appts = bookings.filter(b => !b.course_name.toLowerCase().includes('learner'));
    const tbody = document.getElementById('adminApptBody');
    if (!appts.length) { tbody.innerHTML = '<tr><td colspan="6" class="tbl-empty">No driving appointments.</td></tr>'; return; }
    tbody.innerHTML = appts.map(b => `
      <tr>
        <td>${b._id.substring(0,8)}…</td>
        <td><strong>${b.student_name}</strong></td>
        <td>${b.course_name}</td>
        <td>${b.booking_date}</td>
        <td>${b.booking_time}</td>
        <td><span class="badge badge-${b.status}">${b.status}</span></td>
      </tr>`).join('');
  } catch {}
}

async function loadAdminClasses() {
  try {
    const { bookings } = await api('/api/bookings');
    const classes = bookings.filter(b => b.course_name.toLowerCase().includes('learner'));
    const tbody = document.getElementById('adminClassBody');
    if (!classes.length) { tbody.innerHTML = '<tr><td colspan="6" class="tbl-empty">No learner\'s classes.</td></tr>'; return; }
    tbody.innerHTML = classes.map(b => `
      <tr>
        <td>${b._id.substring(0,8)}…</td>
        <td><strong>${b.student_name}</strong></td>
        <td>${b.course_name}</td>
        <td>${b.booking_date}</td>
        <td>${b.booking_time}</td>
        <td><span class="badge badge-${b.status}">${b.status}</span></td>
      </tr>`).join('');
  } catch {}
}

async function adminBkStatus(id, status) {
  try {
    await api(`/api/bookings/${id}/status`, { method:'PATCH', body:{ status } });
    toast(`Booking ${status}.`, 'success');
    loadAdminBookings();
    loadAdminStats();
  } catch(err) { toast(err.message, 'error'); }
}

async function loadAdminUsers() {
  try {
    const { users } = await api('/api/admin/users');
    allUsers = users;
    renderUserTable(users);
  } catch {}
}

function renderUserTable(users) {
  const tbody = document.getElementById('adminUsersBody');
  if (!users.length) { tbody.innerHTML = '<tr><td colspan="7" class="tbl-empty">No users found.</td></tr>'; return; }
  tbody.innerHTML = users.map(u => `
    <tr>
      <td><strong>${u.first_name} ${u.last_name}</strong></td>
      <td>${u.email}</td>
      <td><span class="role-badge role-${u.role}">${u.role}</span></td>
      <td>${u.student_number || '—'}</td>
      <td class="tbl-sub">${(u.created_at||'').substring(0,10)}</td>
      <td>${u.is_active ? '✅' : '❌'}</td>
      <td>${u.role !== 'admin' ? `<button class="btn btn-xs btn-ghost" onclick="toggleUser('${u._id}')">${u.is_active ? 'Deactivate':'Activate'}</button>` : '—'}</td>
    </tr>`).join('');
}

function filterUserTable() {
  const q = (document.getElementById('userSearch').value || '').toLowerCase();
  const filtered = allUsers.filter(u =>
    `${u.first_name} ${u.last_name}`.toLowerCase().includes(q) ||
    (u.email || '').toLowerCase().includes(q)
  );
  renderUserTable(filtered);
}

async function toggleUser(id) {
  try { await api(`/api/admin/users/${id}/toggle`, { method:'PATCH' }); loadAdminUsers(); }
  catch(err) { toast(err.message, 'error'); }
}

async function loadAdminEnquiries() {
  try {
    const { enquiries } = await api('/api/enquiries');
    const el = document.getElementById('adminEnqList');
    if (!enquiries.length) { el.innerHTML = '<p class="text-muted">No enquiries yet.</p>'; return; }
    el.innerHTML = enquiries.map(eq => `
      <div class="enq-card">
        <div class="enq-hdr">
          <div>
            <strong>${eq.name}</strong>
            <span class="tbl-sub">${eq.email}${eq.phone ? ' · '+eq.phone : ''}</span>
          </div>
          <div style="display:flex;gap:.5rem;align-items:center">
            <span class="badge badge-${eq.status==='new'?'pending':'confirmed'}">${eq.status}</span>
            ${eq.status==='new' ? `<button class="btn btn-xs btn-ghost" onclick="markEnquiry('${eq._id}','read')">Mark Read</button>` : ''}
          </div>
        </div>
        <p style="font-size:14px;color:#5a6b5a">${eq.message}</p>
        <div class="tbl-sub" style="margin-top:.4rem">${(eq.created_at||'').substring(0,10)}</div>
      </div>`).join('');
  } catch {}
}

async function markEnquiry(id, status) {
  try { await api(`/api/enquiries/${id}/status`, { method:'PATCH', body:{ status } }); loadAdminEnquiries(); loadAdminStats(); }
  catch {}
}

async function loadAdminReviews() {
  try {
    const { testimonials } = await api('/api/testimonials/all');
    const el = document.getElementById('adminRevList');
    if (!testimonials.length) { el.innerHTML = '<p class="text-muted">No reviews yet.</p>'; return; }
    el.innerHTML = testimonials.map(t => `
      <div class="bk-item">
        <div class="bk-hdr">
          <strong>${t.name}</strong>
          <span style="color:#c8a030">${'★'.repeat(t.rating)}</span>
        </div>
        <p style="font-size:14px;color:#5a6b5a;margin-top:.25rem">${t.msg}</p>
        <div style="margin-top:.65rem">
          ${!t.is_approved
            ? `<button class="btn btn-sm btn-primary" onclick="approveReview('${t._id}')">✅ Approve</button>`
            : `<span style="color:#1a6b3a;font-size:13px;font-weight:700">✅ Approved</span>`}
        </div>
      </div>`).join('');
  } catch {}
}

async function approveReview(id) {
  try { await api(`/api/admin/testimonials/${id}/approve`, { method:'PATCH' }); loadAdminReviews(); }
  catch {}
}

function adminTab(name, btn) {
  document.querySelectorAll('.dtab').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.dtab-panel').forEach(p => p.classList.add('hidden'));
  btn.classList.add('active');
  document.getElementById('atab-' + name).classList.remove('hidden');
  const loaders = {
    bookings:     loadAdminBookings,
    appointments: loadAdminAppointments,
    classes:      loadAdminClasses,
    users:        loadAdminUsers,
    enquiries:    loadAdminEnquiries,
    reviews:      loadAdminReviews,
  };
  if (loaders[name]) loaders[name]();
}

// ── UI HELPERS ────────────────────────────────────────────────
function showMsg(el, msg, type) {
  el.className = `msg-box msg-${type}`;
  el.textContent = msg;
}
function clearMsg(el) {
  el.className = 'msg-box hidden';
  el.textContent = '';
}
function toast(msg, type = 'success') {
  const wrap = document.getElementById('toastWrap');
  const el   = document.createElement('div');
  el.className = `toast-item toast-${type}`;
  el.textContent = msg;
  wrap.appendChild(el);
  setTimeout(() => el.remove(), 4000);
}
