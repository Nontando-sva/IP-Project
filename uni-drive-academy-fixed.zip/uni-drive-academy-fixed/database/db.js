// database/db.js
// ═══════════════════════════════════════════════════════════════
//  DATABASE LAYER — Uses NeDB (pure JavaScript, no build tools)
//  NeDB stores data as flat JSON files — works on ALL platforms
//  including Windows without Visual Studio C++ toolset.
// ═══════════════════════════════════════════════════════════════
const Datastore = require('nedb');
const bcrypt    = require('bcryptjs');
const path      = require('path');
const fs        = require('fs');

// Ensure data directory exists
const DATA_DIR = path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

// ── Create collections (like SQL tables) ──────────────────────
const db = {
  users:        new Datastore({ filename: path.join(DATA_DIR, 'users.db'),        autoload: true }),
  courses:      new Datastore({ filename: path.join(DATA_DIR, 'courses.db'),      autoload: true }),
  bookings:     new Datastore({ filename: path.join(DATA_DIR, 'bookings.db'),     autoload: true }),
  instructors:  new Datastore({ filename: path.join(DATA_DIR, 'instructors.db'),  autoload: true }),
  faqs:         new Datastore({ filename: path.join(DATA_DIR, 'faqs.db'),         autoload: true }),
  enquiries:    new Datastore({ filename: path.join(DATA_DIR, 'enquiries.db'),    autoload: true }),
  testimonials: new Datastore({ filename: path.join(DATA_DIR, 'testimonials.db'), autoload: true }),
};

// ── Promisify NeDB methods for cleaner async/await usage ──────
const promisify = (collection, method) => (...args) =>
  new Promise((resolve, reject) =>
    collection[method](...args, (err, result) => err ? reject(err) : resolve(result))
  );

// Attach promise-based wrappers to each collection
Object.values(db).forEach(col => {
  col.findAsync    = promisify(col, 'find');
  col.findOneAsync = promisify(col, 'findOne');
  col.insertAsync  = promisify(col, 'insert');
  col.updateAsync  = promisify(col, 'update');
  col.removeAsync  = promisify(col, 'remove');
  col.countAsync   = promisify(col, 'count');
});

// ── Seed data (only runs if collections are empty) ────────────
async function seedDatabase() {
  const userCount = await db.users.countAsync({});
  if (userCount > 0) return;

  console.log('🌱 Seeding database with initial data...');

  // ── Users ────────────────────────────────────────────────────
  const adminHash   = bcrypt.hashSync('admin123',   10);
  const studentHash = bcrypt.hashSync('student123', 10);
  const staffHash   = bcrypt.hashSync('staff123',   10);

  await db.users.insertAsync([
    { _id:'user_admin',   first_name:'Admin',  last_name:'UniDrive', email:'admin@unidrive.ac.za',  password_hash:adminHash,   role:'admin',   student_number:'', phone:'', is_active:true, created_at:new Date().toISOString() },
    { _id:'user_student', first_name:'Thabo',  last_name:'Mokoena',  email:'thabo@mut.ac.za',        password_hash:studentHash, role:'student', student_number:'220123456', phone:'0821234567', is_active:true, created_at:new Date().toISOString() },
    { _id:'user_staff',   first_name:'Naledi', last_name:'Dlamini',  email:'naledi@mut.ac.za',       password_hash:staffHash,   role:'staff',   student_number:'', phone:'0731234567', is_active:true, created_at:new Date().toISOString() },
  ]);

  // ── Courses ───────────────────────────────────────────────────
  await db.courses.insertAsync([
    { _id:'c1', code:'LEARNERS',    name:'Learners Licence',               desc:'Full K53 theory preparation including road signs, rules of the road, and a practice exam simulator.',                                                   duration:'1 session',  vehicle:'N/A',              price_student:250,  price_staff:300,  is_active:true },
    { _id:'c2', code:'CODE_A',      name:'Code A – Motorcycle',            desc:'Professional motorcycle riding from basics to road-ready. Covers balance, emergency braking, and K53 road test preparation.',                           duration:'25 lessons', vehicle:'Motorcycle',       price_student:2000, price_staff:2500, is_active:true },
    { _id:'c3', code:'CODE_8',      name:'Code 8 – Light Motor Vehicle',   desc:'Standard car driving lessons for your Code 8 licence. 25 structured lessons covering all K53 manoeuvres and road skills.',                             duration:'25 lessons', vehicle:'Light Vehicle',    price_student:2300, price_staff:3000, is_active:true },
    { _id:'c4', code:'CODE_10',     name:'Code 10 – Heavy Motor (Std)',    desc:'Standard heavy vehicle driving ideal for logistics employment. Covers load management, defensive driving, and road test preparation.',                   duration:'25 lessons', vehicle:'Heavy Vehicle',    price_student:2500, price_staff:3200, is_active:true },
    { _id:'c5', code:'CODE_10_ADV', name:'Code 10 – Heavy Motor (Adv)',    desc:'Advanced heavy vehicle programme with extended on-road training, night driving, and long-haul simulation scenarios.',                                    duration:'25 lessons', vehicle:'Heavy Vehicle',    price_student:4000, price_staff:4700, is_active:true },
    { _id:'c6', code:'CODE_14',     name:'Code 14 – Extra Heavy (Std)',    desc:'Standard extra-heavy truck driving for a Code 14 licence. Covers articulated vehicle handling and K53 requirements.',                                   duration:'25 lessons', vehicle:'Extra Heavy Truck', price_student:4500, price_staff:6000, is_active:true },
    { _id:'c7', code:'CODE_14_ADV', name:'Code 14 – Extra Heavy (Adv)',    desc:'Advanced truck driving with night-driving, long-haul simulation, and advanced load balancing techniques.',                                               duration:'25 lessons', vehicle:'Extra Heavy Truck', price_student:6500, price_staff:8000, is_active:true },
  ]);

  // ── Instructors ───────────────────────────────────────────────
  await db.instructors.insertAsync([
    { _id:'i1', full_name:'Mr. S. Dube',  licence_codes:'A, 8',    bio:'Experienced motorcycle and light vehicle instructor with 8 years of professional teaching. Over 120 students licensed.', is_active:true },
    { _id:'i2', full_name:'Mrs. T. Zulu', licence_codes:'8, 10',   bio:'Specialist in Code 8 and Code 10 training. Known for building student confidence quickly and thoroughly.',               is_active:true },
    { _id:'i3', full_name:'Mr. K. Ntuli', licence_codes:'10, 14',  bio:'Heavy vehicle expert trained in advanced logistics and long-haul truck driving. 10+ years industry experience.',         is_active:true },
  ]);

  // ── FAQs ──────────────────────────────────────────────────────
  await db.faqs.insertAsync([
    { q:'What documents do I need to register?',    a:'You need your student card or staff ID, a South African ID document, and proof of payment. For learners licence you also need 2 passport photos.', keywords:'documents register requirements id' },
    { q:'How do I book a lesson?',                  a:'Log in to the portal, go to "Book a Lesson", choose your course and preferred time slot, then confirm your booking.',                              keywords:'book schedule lesson appointment how' },
    { q:'What are the prices for students?',        a:'Learners: R250 | Code A: R2 000 | Code 8: R2 300 | Code 10 Std: R2 500 / Adv: R4 000 | Code 14 Std: R4 500 / Adv: R6 500',                     keywords:'price cost fees student how much' },
    { q:'What are the prices for staff?',           a:'Learners: R300 | Code A: R2 500 | Code 8: R3 000 | Code 10 Std: R3 200 / Adv: R4 700 | Code 14 Std: R6 000 / Adv: R8 000',                     keywords:'price cost staff fees' },
    { q:'Can I cancel a booking?',                  a:'Yes. You can cancel a booking up to 24 hours before your lesson without a penalty. Log in and go to My Bookings to cancel.',                     keywords:'cancel reschedule refund' },
    { q:'Do you cater for disabled students?',      a:'Yes! Uni-Drive Academy specifically caters for disabled students. Please mention requirements when booking so we can make arrangements.',          keywords:'disabled wheelchair special needs accessible' },
    { q:'What hours do you operate?',               a:'Monday – Friday 07:30–17:30 and Saturday 08:00–13:00. Evening slots up to 19:00 are available on request.',                                     keywords:'hours times when operating open' },
    { q:'Where are you located?',                   a:'511 Griffiths Mxenge Road, Mangosuthu University of Technology, Umlazi, Durban.',                                                               keywords:'where location address campus find' },
    { q:'How long does it take to get my licence?', a:'Most students complete Code 8 within 3 months. We offer 25 structured lessons and guide you through the DLTC booking process.',                  keywords:'long time duration months how' },
    { q:'Do you offer refresher courses?',          a:'Yes, we offer refresher courses for people who already have a licence but want to improve skills or confidence.',                                keywords:'refresher experienced improve skills existing' },
  ]);

  // ── Testimonials ──────────────────────────────────────────────
  await db.testimonials.insertAsync([
    { name:'Thabo M.',   msg:'I got my Code 8 licence within 3 months. The instructors are patient and professional. Highly recommended for all MUT students!', rating:5, is_approved:true,  created_at:new Date().toISOString() },
    { name:'Sipho N.',   msg:'The online booking system makes it so easy to fit lessons around my class schedule. No more missing lectures!',                   rating:5, is_approved:true,  created_at:new Date().toISOString() },
    { name:'Zanele K.',  msg:'Affordable prices and excellent instructors. I passed my learners on the first try thanks to their K53 preparation sessions.',    rating:5, is_approved:true,  created_at:new Date().toISOString() },
    { name:'Bongani D.', msg:'Best decision I made at MUT. Got my Code 14 and now I have a job lined up before I even graduate!',                              rating:5, is_approved:true,  created_at:new Date().toISOString() },
  ]);

  // ── Sample booking ────────────────────────────────────────────
  await db.bookings.insertAsync([
    { user_id:'user_student', course_id:'c3', course_name:'Code 8 – Light Motor Vehicle', student_name:'Thabo Mokoena', student_email:'thabo@mut.ac.za', booking_date:'2026-06-15', booking_time:'09:00', notes:'', total_price:2300, status:'confirmed', payment_status:'unpaid', created_at:new Date().toISOString() },
    { user_id:'user_student', course_id:'c1', course_name:'Learners Licence',             student_name:'Thabo Mokoena', student_email:'thabo@mut.ac.za', booking_date:'2026-06-01', booking_time:'10:00', notes:'', total_price:250,  status:'completed', payment_status:'paid',   created_at:new Date().toISOString() },
  ]);

  console.log('✅ Database seeded successfully');
}

// Run seed
seedDatabase().catch(err => console.error('Seed error:', err));

module.exports = db;
