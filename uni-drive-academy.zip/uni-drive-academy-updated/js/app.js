// public/js/app.js — Uni-Drive Academy (Standalone / VS Code preview)
// No server required — uses localStorage for persistence
'use strict';

// ══════════════════════════════════════════════════════════════
//  MOCK DATA & IN-MEMORY DATABASE
//  Simulates a real backend — replace with actual API calls when
//  your Node.js server is running.
// ══════════════════════════════════════════════════════════════

const DB_KEY = 'unidrive_db';

function getDB() {
  const raw = localStorage.getItem(DB_KEY);
  if (raw) return JSON.parse(raw);
  // Seed initial data on first load
  const seed = {
    users: [
      {
        id: 'user_admin',
        first_name: 'Admin', last_name: 'UniDrive',
        email: 'admin@unidrive.ac.za', password: 'admin123',
        role: 'admin', student_number: '', phone: '031 907 7111',
        is_active: true, created_at: '2026-01-01T08:00:00.000Z'
      },
      {
        id: 'user_thabo',
        first_name: 'Thabo', last_name: 'Mokoena',
        email: 'thabo@mut.ac.za', password: 'student123',
        role: 'student', student_number: '220123456', phone: '0821234567',
        is_active: true, created_at: '2026-01-15T09:00:00.000Z'
      },
      {
        id: 'user_naledi',
        first_name: 'Naledi', last_name: 'Dlamini',
        email: 'naledi@mut.ac.za', password: 'staff123',
        role: 'staff', student_number: '', phone: '0731234567',
        is_active: true, created_at: '2026-01-20T10:00:00.000Z'
      },
    ],
    bookings: [
      {
        id: 'bk001', user_id: 'user_thabo',
        student_name: 'Thabo Mokoena', student_email: 'thabo@mut.ac.za',
        course_id: 'code8', course_name: 'Code 8 — Light Motor Vehicle',
        booking_date: '2026-06-10', booking_time: '09:00',
        total_price: 2300, status: 'confirmed', notes: '',
        created_at: '2026-05-20T08:00:00.000Z'
      },
      {
        id: 'bk002', user_id: 'user_thabo',
        student_name: 'Thabo Mokoena', student_email: 'thabo@mut.ac.za',
        course_id: 'learners', course_name: "Learner's Licence Prep",
        booking_date: '2026-06-03', booking_time: '10:00',
        total_price: 800, status: 'pending', notes: 'Morning preferred',
        created_at: '2026-05-22T11:00:00.000Z'
      },
      {
        id: 'bk003', user_id: 'user_naledi',
        student_name: 'Naledi Dlamini', student_email: 'naledi@mut.ac.za',
        course_id: 'code8', course_name: 'Code 8 — Light Motor Vehicle',
        booking_date: '2026-06-05', booking_time: '14:00',
        total_price: 2800, status: 'pending', notes: '',
        created_at: '2026-05-23T09:00:00.000Z'
      },
    ],
    enquiries: [
      {
        id: 'enq001', name: 'Siphamandla Ngcobo',
        email: 'sngcobo@mut.ac.za', phone: '0798765432',
        message: 'I would like to know more about the Code 10 programme and available payment plans.',
        status: 'new', created_at: '2026-05-25T14:00:00.000Z'
      },
      {
        id: 'enq002', name: 'Zanele Buthelezi',
        email: 'z.buthelezi@gmail.com', phone: '',
        message: 'Do you offer lessons on weekends? I have classes on weekdays.',
        status: 'read', created_at: '2026-05-24T10:30:00.000Z'
      },
    ],
    testimonials: [
      {
        id: 'rev001', user_id: 'user_thabo', name: 'Thabo Mokoena',
        msg: 'Passed my Code 8 first time! The instructors are patient and thorough.',
        rating: 5, is_approved: true, created_at: '2026-04-10T12:00:00.000Z'
      },
      {
        id: 'rev002', user_id: 'user_naledi', name: 'Naledi Dlamini',
        msg: 'Very affordable and so convenient being on campus. Highly recommended!',
        rating: 5, is_approved: true, created_at: '2026-04-15T14:00:00.000Z'
      },
      {
        id: 'rev003', user_id: 'user_naledi', name: 'Naledi Dlamini',
        msg: 'Great experience overall, my only feedback is more time slots on Fridays.',
        rating: 4, is_approved: false, created_at: '2026-05-01T09:00:00.000Z'
      },
    ],
  };
  saveDB(seed);
  return seed;
}

function saveDB(db) {
  localStorage.setItem(DB_KEY, JSON.stringify(db));
}

const COURSES = {
  learners: { id:'learners', name:"Learner's Licence Prep",    price_student:800,  price_staff:1000 },
  code8:    { id:'code8',    name:'Code 8 — Light Motor Vehicle', price_student:2300, price_staff:2800 },
  codeA:    { id:'codeA',    name:'Code A — Motorcycle',       price_student:2000, price_staff:2400 },
  code10:   { id:'code10',   name:'Code 10 — Heavy Vehicle',   price_student:2500, price_staff:3000 },
  code14:   { id:'code14',   name:'Code 14 — Extra Heavy',     price_student:3000, price_staff:3500 },
  adaptive: { id:'adaptive', name:'Adaptive Driving',          price_student:1500, price_staff:1800 },
};

// ══════════════════════════════════════════════════════════════
//  STATE
// ══════════════════════════════════════════════════════════════
let currentUser     = null;
let selectedRating  = 5;
let priceMode       = 'student';
let adminBookingsCache = [];
let adminUsersCache    = [];

const SESSION_KEY = 'unidrive_session';

// ══════════════════════════════════════════════════════════════
//  INIT
// ══════════════════════════════════════════════════════════════
document.addEventListener('DOMContentLoaded', () => {
  checkAuth();
  setMinDate();
  goto('home');
});

// ══════════════════════════════════════════════════════════════
//  ROUTER
// ══════════════════════════════════════════════════════════════
function goto(page) {
  document.querySelectorAll('.pg').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nl[data-p]').forEach(l =>
    l.classList.toggle('active', l.dataset.p === page));
  const el = document.getElementById('pg-' + page);
  if (el) el.classList.add('active');
  window.scrollTo({ top: 0, behavior: 'smooth' });
  const nav = document.getElementById('navLinks');
  if (nav) nav.classList.remove('open');

  const loaders = {
    home:        loadHome,
    courses:     loadCourses,
    instructors: loadInstructors,
    book:        loadBookPage,
    faq:         loadFaq,
    dashboard:   loadDashboard,
    admin:       loadAdmin,
    learn:       loadLearn,
    sessions:    loadSessions,
    mocktest:    loadMocktest,
    testbooking: loadTestBooking,
  };
  if (loaders[page]) loaders[page]();
}

function toggleNav() {
  document.getElementById('navLinks').classList.toggle('open');
}

// ══════════════════════════════════════════════════════════════
//  AUTH (localStorage-based)
// ══════════════════════════════════════════════════════════════
function checkAuth() {
  const sess = localStorage.getItem(SESSION_KEY);
  if (sess) {
    try { currentUser = JSON.parse(sess); } catch { currentUser = null; }
  }
  renderNav();
}

function renderNav() {
  const area = document.getElementById('authArea');
  if (!currentUser) {
    area.innerHTML = `<a class="nl nav-cta" onclick="goto('login')">Login</a>`;
    return;
  }
  const initials = (currentUser.first_name[0] + currentUser.last_name[0]).toUpperCase();
  const dash = currentUser.role === 'admin' ? 'admin' : 'dashboard';
  area.innerHTML = `
    <a class="nl" onclick="goto('${dash}')" style="display:flex;align-items:center;gap:.5rem">
      <span class="nav-avatar">${initials}</span>
      <span>${currentUser.first_name}</span>
    </a>
    <a class="nl logout-link" onclick="doLogout()">Logout</a>`;
}

function doLogin(e) {
  e.preventDefault();
  const msgEl = document.getElementById('loginMsg');
  clearMsg(msgEl);
  const email = document.getElementById('loginEmail').value.trim().toLowerCase();
  const pw    = document.getElementById('loginPw').value;

  const db   = getDB();
  const user = db.users.find(u => u.email.toLowerCase() === email && u.password === pw);
  if (!user) { showMsg(msgEl, 'Invalid email or password.', 'error'); return; }
  if (!user.is_active) { showMsg(msgEl, 'This account has been deactivated. Contact admin.', 'error'); return; }

  currentUser = { ...user };
  delete currentUser.password;
  localStorage.setItem(SESSION_KEY, JSON.stringify(currentUser));
  renderNav();
  toast(`Welcome back, ${user.first_name}! 🚗`, 'success');
  goto(user.role === 'admin' ? 'admin' : 'dashboard');
}

function doRegister(e) {
  e.preventDefault();
  const msgEl = document.getElementById('regMsg');
  clearMsg(msgEl);

  const first = document.getElementById('regFirst').value.trim();
  const last  = document.getElementById('regLast').value.trim();
  const email = document.getElementById('regEmail').value.trim().toLowerCase();
  const pw    = document.getElementById('regPw').value;
  const role  = document.getElementById('regRole').value;
  const sn    = document.getElementById('regSn').value.trim();
  const phone = document.getElementById('regPhone').value.trim();

  if (!first || !last || !email || !pw) { showMsg(msgEl, 'Please fill in all required fields.', 'error'); return; }
  if (pw.length < 6) { showMsg(msgEl, 'Password must be at least 6 characters.', 'error'); return; }

  const db = getDB();
  if (db.users.find(u => u.email.toLowerCase() === email)) {
    showMsg(msgEl, 'An account with this email already exists.', 'error'); return;
  }

  const newUser = {
    id: 'user_' + Date.now(),
    first_name: first, last_name: last, email,
    password: pw, role, student_number: sn, phone,
    is_active: true, created_at: new Date().toISOString()
  };
  db.users.push(newUser);
  saveDB(db);

  currentUser = { ...newUser }; delete currentUser.password;
  localStorage.setItem(SESSION_KEY, JSON.stringify(currentUser));
  renderNav();
  toast(`Account created! Welcome, ${first}! 🎉`, 'success');
  goto('dashboard');
}

function doLogout() {
  currentUser = null;
  localStorage.removeItem(SESSION_KEY);
  renderNav();
  goto('home');
  toast('Logged out successfully.', 'info');
}

function fillLogin(email, pw) {
  document.getElementById('loginEmail').value = email;
  document.getElementById('loginPw').value    = pw;
}

function togglePw(id, btn) {
  const input = document.getElementById(id);
  const isText = input.type === 'text';
  input.type = isText ? 'password' : 'text';
  btn.textContent = isText ? '👁' : '🙈';
}

function toggleStudentFields() {
  const role = document.getElementById('regRole').value;
  document.getElementById('regSnGroup').style.display = role === 'student' ? 'flex' : 'none';
}

// ══════════════════════════════════════════════════════════════
//  HOME
// ══════════════════════════════════════════════════════════════
function loadHome() {
  // Testimonials are already seeded in HTML, re-render from DB
  const db = getDB();
  const approved = db.testimonials.filter(t => t.is_approved);
  const el = document.getElementById('homeTestimonials');
  if (el && approved.length) {
    el.innerHTML = approved.map(t => `
      <div class="test-card">
        <div class="test-stars">${'★'.repeat(t.rating)}</div>
        <p class="test-msg">"${t.msg}"</p>
        <div class="test-name">— ${t.name}</div>
      </div>`).join('');
  }
}

// ══════════════════════════════════════════════════════════════
//  COURSES
// ══════════════════════════════════════════════════════════════
function loadCourses() { /* HTML is pre-rendered, price toggle handles updates */ }

function setPriceMode(mode) {
  priceMode = mode;
  document.getElementById('ptStudent').classList.toggle('active', mode === 'student');
  document.getElementById('ptStaff').classList.toggle('active',   mode === 'staff');
  // Update price displays
  const map = {
    learners: { student: 'R 800',  staff: 'R 1 000' },
    code8:    { student: 'R 2 300', staff: 'R 2 800' },
    codeA:    { student: 'R 2 000', staff: 'R 2 400' },
    code10:   { student: 'R 2 500', staff: 'R 3 000' },
    code14:   { student: 'R 3 000', staff: 'R 3 500' },
    adaptive: { student: 'R 1 500', staff: 'R 1 800' },
  };
  document.querySelectorAll('.price-row strong').forEach((el, i) => {
    const keys = Object.keys(map);
    const cIdx = Math.floor(i / 2);
    const isStaff = i % 2 === 1;
    const key = keys[cIdx];
    if (key && map[key]) {
      el.textContent = isStaff ? map[key].staff : map[key][mode];
    }
  });
}

// ══════════════════════════════════════════════════════════════
//  INSTRUCTORS
// ══════════════════════════════════════════════════════════════
function loadInstructors() { /* Pre-rendered in HTML */ }

// ══════════════════════════════════════════════════════════════
//  BOOKING PAGE (public)
// ══════════════════════════════════════════════════════════════
function loadBookPage() {
  if (!currentUser) {
    document.getElementById('bookGate').classList.remove('hidden');
    document.getElementById('bookContent').classList.add('hidden');
    return;
  }
  document.getElementById('bookGate').classList.add('hidden');
  document.getElementById('bookContent').classList.remove('hidden');
  loadMyBookings();
}

function updateBookingPrice() {
  const sel = document.getElementById('bkCourse');
  const opt = sel.options[sel.selectedIndex];
  const box = document.getElementById('bkPriceBox');
  if (!sel.value) { box.classList.add('hidden'); return; }
  const isStaff = currentUser?.role === 'staff';
  const price = isStaff ? parseFloat(opt.dataset.pp) : parseFloat(opt.dataset.ps);
  document.getElementById('bkPriceAmt').textContent = `R ${price.toLocaleString()}`;
  box.classList.remove('hidden');
}

function setMinDate() {
  ['bkDate','dbkDate'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.min = new Date().toISOString().split('T')[0];
  });
}

function loadTimeSlots() { buildSlots('bkDate','slotsWrapper','slotsGrid','bkTime'); }
function loadDashSlots() { buildSlots('dbkDate','dbkSlotsWrapper','dbkSlotsGrid','dbkTime'); }

function buildSlots(dateId, wrapperId, gridId, hiddenId) {
  const date = document.getElementById(dateId).value;
  const wrap = document.getElementById(wrapperId);
  const grid = document.getElementById(gridId);
  document.getElementById(hiddenId).value = '';
  if (!date) { wrap.style.display = 'none'; return; }
  const slots = [];
  for (let h = 8; h <= 17; h++) {
    slots.push(`${String(h).padStart(2,'0')}:00`);
    if (h < 17) slots.push(`${String(h).padStart(2,'0')}:30`);
  }
  grid.innerHTML = slots.map(t =>
    `<button type="button" class="slot-btn" onclick="selectSlot('${t}',this,'${hiddenId}')">${t}</button>`
  ).join('');
  wrap.style.display = 'block';
}

function selectSlot(time, btn, hiddenId) {
  btn.closest('.slots-grid').querySelectorAll('.slot-btn').forEach(b => b.classList.remove('selected'));
  btn.classList.add('selected');
  document.getElementById(hiddenId).value = time;
}

function submitBooking(e) { makeBooking(e, 'bkCourse','bkDate','bkTime','bkNotes','bookMsg', loadMyBookings); }
function submitDashBooking(e) { makeBooking(e, 'dbkCourse','dbkDate','dbkTime','dbkNotes','dbkMsg', () => { toast('Booking confirmed! 🎉','success'); dashTab('bookings', document.getElementById('dtab-btn-bookings')); }); }

function makeBooking(e, courseId, dateId, timeId, notesId, msgId, onSuccess) {
  e.preventDefault();
  const msgEl   = document.getElementById(msgId);
  clearMsg(msgEl);
  const time    = document.getElementById(timeId).value;
  const course  = document.getElementById(courseId).value;
  const date    = document.getElementById(dateId).value;
  const notes   = document.getElementById(notesId).value;

  if (!course) { showMsg(msgEl, 'Please select a course.', 'error'); return; }
  if (!date)   { showMsg(msgEl, 'Please select a date.', 'error'); return; }
  if (!time)   { showMsg(msgEl, 'Please select a time slot.', 'error'); return; }
  if (!currentUser) { showMsg(msgEl, 'Please login first.', 'error'); return; }

  const today = new Date().toISOString().split('T')[0];
  if (date < today) { showMsg(msgEl, 'Booking date cannot be in the past.', 'error'); return; }

  const db       = getDB();
  const courseObj = COURSES[course] || { name: course, price_student: 0, price_staff: 0 };
  const price    = currentUser.role === 'staff' ? courseObj.price_staff : courseObj.price_student;

  // Check duplicate
  const dup = db.bookings.find(b =>
    b.user_id === currentUser.id && b.course_id === course &&
    b.booking_date === date && b.booking_time === time &&
    ['pending','confirmed'].includes(b.status)
  );
  if (dup) { showMsg(msgEl, 'You already have a booking for this slot.', 'error'); return; }

  const booking = {
    id: 'bk_' + Date.now(),
    user_id: currentUser.id,
    student_name:  `${currentUser.first_name} ${currentUser.last_name}`,
    student_email: currentUser.email,
    course_id: course, course_name: courseObj.name,
    booking_date: date, booking_time: time,
    total_price: price, status: 'pending', notes,
    created_at: new Date().toISOString()
  };
  db.bookings.push(booking);
  saveDB(db);
  showMsg(msgEl, '✅ Booking confirmed! Check your bookings below.', 'success');
  e.target.reset();
  ['bkPriceBox','dbkPriceBox'].forEach(id => { const el = document.getElementById(id); if(el) el.classList.add('hidden'); });
  ['slotsWrapper','dbkSlotsWrapper'].forEach(id => { const el = document.getElementById(id); if(el) el.style.display='none'; });
  onSuccess();
}

function loadMyBookings() {
  const containers = ['myBookingsList','dashBookingsList'];
  const db       = getDB();
  const bookings = db.bookings
    .filter(b => b.user_id === currentUser?.id)
    .sort((a,b) => new Date(b.created_at) - new Date(a.created_at));

  const html = bookings.length
    ? bookings.map(b => `
        <div class="bk-item">
          <div class="bk-hdr">
            <div class="bk-course">${b.course_name}</div>
            <span class="badge badge-${b.status}">${b.status}</span>
          </div>
          <div class="bk-meta">📅 ${b.booking_date} &nbsp; 🕐 ${b.booking_time} &nbsp; 💰 R${b.total_price.toLocaleString()}</div>
          ${b.notes ? `<div class="bk-meta">📝 ${b.notes}</div>` : ''}
          ${['pending','confirmed'].includes(b.status) ? `
            <div style="margin-top:.65rem">
              <button class="btn btn-sm btn-red" onclick="cancelBooking('${b.id}')">Cancel</button>
            </div>` : ''}
        </div>`).join('')
    : '<p class="text-muted">No bookings yet. <a onclick="goto(\'book\')" style="color:var(--green);font-weight:700;cursor:pointer">Book a lesson →</a></p>';

  containers.forEach(id => {
    const el = document.getElementById(id);
    if (el) el.innerHTML = html;
  });
  updateDashStats();
}

function cancelBooking(id) {
  if (!confirm('Cancel this booking?')) return;
  const db = getDB();
  const bk = db.bookings.find(b => b.id === id);
  if (bk) { bk.status = 'cancelled'; saveDB(db); }
  toast('Booking cancelled.', 'info');
  loadMyBookings();
}

function updateDashStats() {
  if (!currentUser) return;
  const db = getDB();
  const mine = db.bookings.filter(b => b.user_id === currentUser.id);
  const set = (id, val) => { const el = document.getElementById(id); if(el) el.textContent = val; };
  set('stat-total',     mine.length);
  set('stat-pending',   mine.filter(b => b.status === 'pending').length);
  set('stat-confirmed', mine.filter(b => b.status === 'confirmed').length);
  set('stat-completed', mine.filter(b => b.status === 'completed').length);

  const recent = document.getElementById('dashRecentBookings');
  if (!recent) return;
  const last3 = mine.slice(0, 3);
  recent.innerHTML = last3.length
    ? last3.map(b => `
        <div class="bk-item">
          <div class="bk-hdr"><div class="bk-course">${b.course_name}</div><span class="badge badge-${b.status}">${b.status}</span></div>
          <div class="bk-meta">📅 ${b.booking_date} &nbsp; 🕐 ${b.booking_time}</div>
        </div>`).join('')
    : '<p class="text-muted">No bookings yet.</p>';
}

// ══════════════════════════════════════════════════════════════
//  FAQ
// ══════════════════════════════════════════════════════════════
function loadFaq() { /* Pre-rendered in HTML */ }

function toggleAcc(i, btn) {
  btn.classList.toggle('open');
  document.getElementById('acc-' + i).classList.toggle('show');
}

function searchFaq() {
  const q = document.getElementById('faqInput').value.trim().toLowerCase();
  const resDiv = document.getElementById('faqResults');
  if (!q) { resDiv.classList.add('hidden'); return; }
  resDiv.classList.remove('hidden');

  const faqs = [
    { q:'How do I register for a course?', a:'Create an account on our portal, log in, then navigate to "Book a Lesson" and select your preferred course and time slot.' },
    { q:'What documents do I need?', a:'You need a valid ID document (or passport), your student card if you\'re a MUT student, and any existing licence if upgrading.' },
    { q:'Can I cancel a booking?', a:'Yes, you can cancel a booking up to 24 hours before your scheduled lesson from your dashboard without penalty.' },
    { q:'Do you offer payment plans?', a:'Yes! We offer flexible payment plans for students. Contact us to arrange a payment schedule that works with your budget.' },
    { q:'How long does it take to get a licence?', a:'Code 8 training takes approximately 25 lessons (typically 3–6 months). The full timeline depends on your availability and progress.' },
    { q:'Are there classes for disabled students?', a:'Yes! Our Adaptive Driving programme caters specifically for students with physical disabilities.' },
  ];

  const results = faqs.filter(f =>
    f.q.toLowerCase().includes(q) || f.a.toLowerCase().includes(q)
  );

  if (!results.length) {
    resDiv.innerHTML = `<div class="faq-no-result">🤖 No results found for "<strong>${q}</strong>". Try searching for "cancel", "payment", "documents", or "register".</div>`;
  } else {
    resDiv.innerHTML = results.map(r => `
      <div class="faq-result-card">
        <div class="faq-rq">❓ ${r.q}</div>
        <div class="faq-ra">✅ ${r.a}</div>
      </div>`).join('');
  }
}

// ══════════════════════════════════════════════════════════════
//  CONTACT
// ══════════════════════════════════════════════════════════════
function submitEnquiry(e) {
  e.preventDefault();
  const msgEl = document.getElementById('contactMsg');
  clearMsg(msgEl);
  const db = getDB();
  db.enquiries.push({
    id: 'enq_' + Date.now(),
    name:    document.getElementById('cName').value,
    email:   document.getElementById('cEmail').value,
    phone:   document.getElementById('cPhone').value,
    message: document.getElementById('cMsg').value,
    status: 'new', created_at: new Date().toISOString()
  });
  saveDB(db);
  showMsg(msgEl, '✅ Message sent! We will respond within 1–2 business days.', 'success');
  e.target.reset();
  toast('Message sent!', 'success');
}

// ══════════════════════════════════════════════════════════════
//  CUSTOMER DASHBOARD
// ══════════════════════════════════════════════════════════════
function loadDashboard() {
  if (!currentUser) { goto('login'); return; }
  const set = (id, val) => { const el = document.getElementById(id); if(el) el.textContent = val; };
  set('dashTitle', `Welcome, ${currentUser.first_name}!`);
  set('dashSub',   `${currentUser.role === 'staff' ? 'Staff' : 'Student'} Portal`);

  const dsUser = document.getElementById('dsUserInfo');
  if (dsUser) {
    const initials = (currentUser.first_name[0] + currentUser.last_name[0]).toUpperCase();
    dsUser.innerHTML = `
      <div style="display:flex;align-items:center;gap:.6rem;margin-bottom:.25rem">
        <div class="nav-avatar" style="width:36px;height:36px;font-size:.9rem">${initials}</div>
        <div>
          <div class="du-name">${currentUser.first_name} ${currentUser.last_name}</div>
          <div class="du-role">${currentUser.role}</div>
        </div>
      </div>
      ${currentUser.student_number ? `<div style="font-size:.75rem;color:rgba(255,255,255,.4)">SN: ${currentUser.student_number}</div>` : ''}`;
  }
  loadMyBookings();
  loadProfileForm();
  setMinDate();
  // Render quick actions including new feature buttons
  const qa = document.querySelector('.qa-grid');
  if (qa) {
    qa.innerHTML = `
      <button class="qa-btn" onclick="goto('book')">📅 Book a Lesson</button>
      <button class="qa-btn" onclick="goto('courses')">📚 View Courses</button>
      <button class="qa-btn" onclick="goto('learn')">📖 Study Materials</button>
      <button class="qa-btn" onclick="goto('sessions')">🎓 Online Sessions</button>
      <button class="qa-btn" onclick="goto('mocktest')">📝 Mock Test</button>
      <button class="qa-btn" onclick="goto('testbooking')">🏛️ Book Official Test</button>
      <button class="qa-btn" onclick="goto('faq')">❓ FAQ</button>
      <button class="qa-btn" onclick="goto('contact')">📞 Contact Us</button>`;
  }
}

function loadProfileForm() {
  if (!currentUser) return;
  const set = (id, val) => { const el = document.getElementById(id); if(el) el.value = val||''; };
  set('pFirst', currentUser.first_name);
  set('pLast',  currentUser.last_name);
  set('pEmail', currentUser.email);
  set('pPhone', currentUser.phone);
  set('pSn',    currentUser.student_number);
  if (currentUser.role !== 'student') {
    const g = document.getElementById('pSnGroup'); if(g) g.style.display = 'none';
  }
}

function updateProfile(e) {
  e.preventDefault();
  const msgEl = document.getElementById('profileMsg');
  clearMsg(msgEl);
  const db   = getDB();
  const user = db.users.find(u => u.id === currentUser.id);
  if (!user) { showMsg(msgEl,'User not found.','error'); return; }
  user.first_name     = document.getElementById('pFirst').value.trim();
  user.last_name      = document.getElementById('pLast').value.trim();
  user.phone          = document.getElementById('pPhone').value.trim();
  user.student_number = document.getElementById('pSn').value.trim();
  saveDB(db);
  currentUser = { ...user }; delete currentUser.password;
  localStorage.setItem(SESSION_KEY, JSON.stringify(currentUser));
  renderNav();
  showMsg(msgEl, 'Profile updated successfully! ✅', 'success');
  toast('Profile saved!', 'success');
}

function changePassword(e) {
  e.preventDefault();
  const msgEl = document.getElementById('pwMsg');
  clearMsg(msgEl);
  const cur  = document.getElementById('pwCur').value;
  const nw   = document.getElementById('pwNew').value;
  const conf = document.getElementById('pwConf').value;
  if (nw !== conf) { showMsg(msgEl,'Passwords do not match.','error'); return; }
  if (nw.length < 6) { showMsg(msgEl,'New password must be at least 6 characters.','error'); return; }
  const db   = getDB();
  const user = db.users.find(u => u.id === currentUser.id);
  if (!user || user.password !== cur) { showMsg(msgEl,'Current password is incorrect.','error'); return; }
  user.password = nw;
  saveDB(db);
  showMsg(msgEl,'✅ Password updated successfully!','success');
  e.target.reset();
}

function dashTab(name, btn) {
  document.querySelectorAll('.dash-sidebar .dtab').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('#pg-dashboard .dtab-panel').forEach(p => p.classList.add('hidden'));
  if(btn) btn.classList.add('active');
  const panel = document.getElementById('dtab-' + name);
  if(panel) panel.classList.remove('hidden');
  if (name === 'bookings')  loadMyBookings();
  if (name === 'book-new')  setMinDate();
}

function setRating(r) {
  selectedRating = r;
  document.querySelectorAll('.star').forEach((s, i) => s.classList.toggle('active', i < r));
}

function submitReview(e) {
  e.preventDefault();
  const msgEl = document.getElementById('reviewStatus');
  clearMsg(msgEl);
  const msg = document.getElementById('reviewMsg').value.trim();
  if (!msg) { showMsg(msgEl,'Please write a review.','error'); return; }
  const db = getDB();
  db.testimonials.push({
    id: 'rev_' + Date.now(),
    user_id: currentUser.id,
    name: `${currentUser.first_name} ${currentUser.last_name}`,
    msg, rating: selectedRating, is_approved: false,
    created_at: new Date().toISOString()
  });
  saveDB(db);
  showMsg(msgEl, '✅ Thank you! Your review is pending admin approval.', 'success');
  e.target.reset();
  setRating(5);
}

function updateDashPrice() {
  const sel = document.getElementById('dbkCourse');
  const opt = sel.options[sel.selectedIndex];
  const box = document.getElementById('dbkPriceBox');
  if (!sel.value) { box.classList.add('hidden'); return; }
  const isStaff = currentUser?.role === 'staff';
  const price = isStaff ? parseFloat(opt.dataset.pp) : parseFloat(opt.dataset.ps);
  document.getElementById('dbkPriceAmt').textContent = `R ${price.toLocaleString()}`;
  box.classList.remove('hidden');
}

// ══════════════════════════════════════════════════════════════
//  ADMIN DASHBOARD
// ══════════════════════════════════════════════════════════════
function loadAdmin() {
  if (!currentUser || currentUser.role !== 'admin') { goto('login'); return; }
  const dsUser = document.getElementById('adminUserInfo');
  if (dsUser) {
    dsUser.innerHTML = `
      <div class="du-name">${currentUser.first_name} ${currentUser.last_name}</div>
      <div class="du-role" style="color:var(--gold)">Administrator</div>`;
  }
  loadAdminStats();
  loadAdminBookings();
}

function loadAdminStats() {
  const db = getDB();
  const stats = {
    total_users:        db.users.length,
    total_students:     db.users.filter(u=>u.role==='student').length,
    total_staff:        db.users.filter(u=>u.role==='staff').length,
    total_admins:       db.users.filter(u=>u.role==='admin').length,
    total_bookings:     db.bookings.length,
    pending_bookings:   db.bookings.filter(b=>b.status==='pending').length,
    confirmed_bookings: db.bookings.filter(b=>b.status==='confirmed').length,
    completed_bookings: db.bookings.filter(b=>b.status==='completed').length,
    new_enquiries:      db.enquiries.filter(e=>e.status==='new').length,
    total_revenue:      db.bookings.filter(b=>['confirmed','completed'].includes(b.status)).reduce((s,b)=>s+b.total_price,0),
  };

  document.getElementById('adminStats').innerHTML = [
    ['Total Users',    stats.total_users,            '#1a2744', 'sc-blue'],
    ['Students',       stats.total_students,          '#1a6b3a', 'sc-green'],
    ['Staff',          stats.total_staff,             '#5a6b5a', 'sc-dark'],
    ['Pending',        stats.pending_bookings,        '#c8a030', 'sc-gold'],
    ['Confirmed',      stats.confirmed_bookings,      '#1a6b3a', 'sc-green'],
    ['All Bookings',   stats.total_bookings,          '#1a2744', 'sc-blue'],
    ['New Enquiries',  stats.new_enquiries,           '#dc2626', 'sc-red'],
    ['Revenue',        'R '+stats.total_revenue.toLocaleString(), '#1a6b3a', 'sc-green'],
  ].map(([l,v,c,cls]) => `
    <div class="ast">
      <div class="ast-label">${l}</div>
      <div class="ast-val" style="color:${c}">${v}</div>
    </div>`).join('');

  // Recent bookings chart area
  const recent = db.bookings.slice(-5).reverse();
  document.getElementById('adminRecentBk').innerHTML = recent.length
    ? `<div class="table-wrap"><table class="data-table">
        <thead><tr><th>Student</th><th>Course</th><th>Date</th><th>Status</th><th>Price</th></tr></thead>
        <tbody>${recent.map(b=>`
          <tr>
            <td><strong>${b.student_name}</strong></td>
            <td>${b.course_name}</td>
            <td>${b.booking_date}</td>
            <td><span class="badge badge-${b.status}">${b.status}</span></td>
            <td>R${b.total_price.toLocaleString()}</td>
          </tr>`).join('')}
        </tbody></table></div>`
    : '<p class="text-muted">No bookings yet.</p>';
}

function loadAdminBookings() {
  const db = getDB();
  adminBookingsCache = [...db.bookings].sort((a,b) => new Date(b.created_at)-new Date(a.created_at));
  renderAdminBookings(adminBookingsCache);
}

function renderAdminBookings(bookings) {
  const tbody = document.getElementById('adminBkBody');
  if (!bookings.length) { tbody.innerHTML = '<tr><td colspan="8" class="tbl-empty">No bookings found.</td></tr>'; return; }
  tbody.innerHTML = bookings.map(b => `
    <tr>
      <td style="font-family:monospace;font-size:.78rem">${b.id.slice(-6)}</td>
      <td><strong>${b.student_name}</strong><span class="tbl-sub">${b.student_email}</span></td>
      <td>${b.course_name}</td>
      <td>${b.booking_date}</td>
      <td>${b.booking_time}</td>
      <td>R${b.total_price.toLocaleString()}</td>
      <td><span class="badge badge-${b.status}">${b.status}</span></td>
      <td class="tbl-actions">
        ${b.status==='pending'    ? `<button class="btn btn-xs btn-green" onclick="adminBkStatus('${b.id}','confirmed')" title="Confirm">✅</button>` : ''}
        ${['pending','confirmed'].includes(b.status) ? `<button class="btn btn-xs btn-red" onclick="adminBkStatus('${b.id}','cancelled')" title="Cancel">❌</button>` : ''}
        ${b.status==='confirmed'  ? `<button class="btn btn-xs btn-ghost" onclick="adminBkStatus('${b.id}','completed')" title="Mark done">✔</button>` : ''}
      </td>
    </tr>`).join('');
}

function filterAdminBookings() {
  const q = document.getElementById('bkSearch').value.toLowerCase();
  const filtered = adminBookingsCache.filter(b =>
    b.student_name.toLowerCase().includes(q) ||
    b.course_name.toLowerCase().includes(q) ||
    b.status.includes(q) ||
    b.booking_date.includes(q)
  );
  renderAdminBookings(filtered);
}

function adminBkStatus(id, status) {
  const db = getDB();
  const bk = db.bookings.find(b => b.id === id);
  if (bk) { bk.status = status; saveDB(db); }
  toast(`Booking ${status}.`, 'success');
  loadAdminBookings();
  loadAdminStats();
}

function loadAdminUsers() {
  const db = getDB();
  adminUsersCache = [...db.users].sort((a,b) => new Date(b.created_at)-new Date(a.created_at));
  renderAdminUsers(adminUsersCache);
}

function renderAdminUsers(users) {
  const tbody = document.getElementById('adminUsersBody');
  if (!users.length) { tbody.innerHTML = '<tr><td colspan="7" class="tbl-empty">No users found.</td></tr>'; return; }
  tbody.innerHTML = users.map(u => `
    <tr>
      <td><strong>${u.first_name} ${u.last_name}</strong></td>
      <td>${u.email}</td>
      <td><span class="role-badge role-${u.role}">${u.role}</span></td>
      <td>${u.student_number || '—'}</td>
      <td class="tbl-sub">${(u.created_at||'').substring(0,10)}</td>
      <td>${u.is_active ? '<span style="color:var(--green);font-weight:700">Active</span>' : '<span style="color:var(--red);font-weight:700">Inactive</span>'}</td>
      <td>${u.role !== 'admin'
        ? `<button class="btn btn-xs btn-ghost" onclick="toggleUser('${u.id}')">${u.is_active?'Deactivate':'Activate'}</button>`
        : '—'}</td>
    </tr>`).join('');
}

function filterAdminUsers() {
  const q = document.getElementById('userSearch').value.toLowerCase();
  const filtered = adminUsersCache.filter(u =>
    `${u.first_name} ${u.last_name}`.toLowerCase().includes(q) ||
    u.email.toLowerCase().includes(q) ||
    u.role.includes(q)
  );
  renderAdminUsers(filtered);
}

function toggleUser(id) {
  const db = getDB();
  const user = db.users.find(u => u.id === id);
  if (user) { user.is_active = !user.is_active; saveDB(db); }
  toast(`User ${user.is_active ? 'activated' : 'deactivated'}.`, 'info');
  loadAdminUsers();
}

function loadAdminEnquiries() {
  const db = getDB();
  const el = document.getElementById('adminEnqList');
  const enquiries = [...db.enquiries].sort((a,b) => new Date(b.created_at)-new Date(a.created_at));
  if (!enquiries.length) { el.innerHTML = '<p class="text-muted">No enquiries yet.</p>'; return; }
  el.innerHTML = enquiries.map(eq => `
    <div class="enq-card">
      <div class="enq-hdr">
        <div>
          <strong>${eq.name}</strong>
          <span class="tbl-sub">${eq.email}${eq.phone?' · '+eq.phone:''}</span>
        </div>
        <div style="display:flex;gap:.5rem;align-items:center">
          <span class="badge badge-${eq.status==='new'?'pending':'confirmed'}">${eq.status}</span>
          ${eq.status==='new'?`<button class="btn btn-xs btn-ghost" onclick="markEnquiry('${eq.id}','read')">Mark Read</button>`:''}
        </div>
      </div>
      <p style="font-size:.88rem;color:var(--gray-700);margin:.5rem 0">${eq.message}</p>
      <div class="tbl-sub">${(eq.created_at||'').substring(0,10)}</div>
    </div>`).join('');
}

function markEnquiry(id, status) {
  const db = getDB();
  const eq = db.enquiries.find(e => e.id === id);
  if (eq) { eq.status = status; saveDB(db); }
  loadAdminEnquiries();
  loadAdminStats();
}

function loadAdminReviews() {
  const db = getDB();
  const el = document.getElementById('adminRevList');
  const all = [...db.testimonials].sort((a,b) => new Date(b.created_at)-new Date(a.created_at));
  if (!all.length) { el.innerHTML = '<p class="text-muted">No reviews yet.</p>'; return; }
  el.innerHTML = all.map(t => `
    <div class="bk-item">
      <div class="bk-hdr">
        <strong>${t.name}</strong>
        <div style="display:flex;align-items:center;gap:.75rem">
          <span style="color:var(--gold)">${'★'.repeat(t.rating)}</span>
          ${t.is_approved?`<span style="color:var(--green);font-size:.8rem;font-weight:700">✅ Approved</span>`:
            `<span style="background:#fef3c7;color:#92400e;padding:.2rem .6rem;border-radius:999px;font-size:.73rem;font-weight:700">Pending</span>`}
        </div>
      </div>
      <p style="font-size:.88rem;color:var(--gray-700);margin:.5rem 0">${t.msg}</p>
      <div style="display:flex;gap:.5rem;margin-top:.65rem;flex-wrap:wrap">
        ${!t.is_approved?`<button class="btn btn-sm btn-primary" onclick="approveReview('${t.id}')">✅ Approve</button>`:''}
        <button class="btn btn-sm btn-red" onclick="deleteReview('${t.id}')">🗑 Delete</button>
      </div>
    </div>`).join('');
}

function approveReview(id) {
  const db = getDB();
  const t  = db.testimonials.find(r => r.id === id);
  if (t) { t.is_approved = true; saveDB(db); }
  toast('Review approved!', 'success');
  loadAdminReviews();
  loadHome();
}

function deleteReview(id) {
  if (!confirm('Delete this review?')) return;
  const db = getDB();
  db.testimonials = db.testimonials.filter(r => r.id !== id);
  saveDB(db);
  toast('Review deleted.', 'info');
  loadAdminReviews();
}

function adminTab(name, btn) {
  document.querySelectorAll('.admin-sidebar .dtab').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('#pg-admin .dtab-panel').forEach(p => p.classList.add('hidden'));
  if(btn) btn.classList.add('active');
  const panel = document.getElementById('atab-' + name);
  if(panel) panel.classList.remove('hidden');
  const loaders = {
    stats:     loadAdminStats,
    bookings:  loadAdminBookings,
    users:     loadAdminUsers,
    enquiries: loadAdminEnquiries,
    reviews:   loadAdminReviews,
  };
  if (loaders[name]) loaders[name]();
}

// ══════════════════════════════════════════════════════════════
//  UI HELPERS
// ══════════════════════════════════════════════════════════════
function showMsg(el, msg, type) {
  if (!el) return;
  el.className = `msg-box msg-${type}`;
  el.textContent = msg;
}
function clearMsg(el) {
  if (!el) return;
  el.className = 'msg-box hidden';
  el.textContent = '';
}
function toast(msg, type = 'success') {
  const wrap = document.getElementById('toastWrap');
  const el   = document.createElement('div');
  el.className = `toast-item toast-${type}`;
  el.textContent = msg;
  wrap.appendChild(el);
  setTimeout(() => el.remove(), 4000);
}

// ══════════════════════════════════════════════════════════════
//  STUDY MATERIALS
// ══════════════════════════════════════════════════════════════
function loadLearn() {
  learnTab('signs', document.querySelector('.ltab'));
}

function learnTab(name, btn) {
  document.querySelectorAll('.ltab').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.ltab-content').forEach(c => c.classList.add('hidden'));
  if (btn) btn.classList.add('active');
  const el = document.getElementById('lc-' + name);
  if (el) el.classList.remove('hidden');
}

// ══════════════════════════════════════════════════════════════
//  SESSION DATA
// ══════════════════════════════════════════════════════════════
const SESSIONS_DATA = [
  {
    id: 'sess_signs_reg',
    title: 'Regulatory Signs',
    icon: '🔴',
    color: '#fee2e2',
    sub: '6 signs · ~15 min',
    desc: 'Learn all red regulatory signs — STOP, NO ENTRY, speed limits, and restrictions.',
    content: [
      { point: '🛑 STOP Sign', text: 'You must come to a complete stop. Wait until it is safe before proceeding. This sign has no exceptions — a rolling stop is illegal.' },
      { point: '⛔ NO ENTRY', text: 'You may not enter the road in this direction. This appears at one-way roads and contraflow lanes.' },
      { point: '🔢 Speed Limits', text: '60 km/h in urban areas, 100 km/h on rural roads, 120 km/h on freeways. Posted signs always override the general limit.' },
      { point: '🚫 NO OVERTAKING', text: 'You may not overtake any moving vehicle in this zone. The sign applies to the entire marked section.' },
      { point: '⬇️ YIELD (Give Way)', text: 'You must slow down and yield right of way to all traffic on the major road. Only proceed when safe.' },
      { point: '🅿️ PARKING RESTRICTIONS', text: 'Red prohibitory signs indicate where and when you cannot park or stop. Always check for time restrictions.' },
    ],
    quiz: { q: 'At a STOP sign, when may you proceed?', opts: ['After slowing to 10km/h', 'After coming to a complete stop and yielding to all traffic', 'After 3 seconds', 'When no cars are visible from 50m away'], answer: 1, explanation: 'A STOP sign requires a COMPLETE stop (zero speed) and you must yield to ALL approaching traffic before proceeding safely.' }
  },
  {
    id: 'sess_signs_warn',
    title: 'Warning Signs',
    icon: '⚠️',
    color: '#fef3c7',
    sub: '6 signs · ~15 min',
    desc: 'Yellow diamond-shaped signs that warn of hazards ahead — bends, crossings, and more.',
    content: [
      { point: '⚠️ Purpose of Warning Signs', text: 'Warning signs are yellow/black diamond-shaped signs that alert drivers to potential hazards ahead. They do not restrict action but require extra caution.' },
      { point: '🚸 Pedestrian Crossing Ahead', text: 'Warns of a pedestrian crossing. Reduce speed and watch for pedestrians who may be crossing or about to cross.' },
      { point: '⛰️ Steep Gradient', text: 'Indicates a steep slope ahead. Select a lower gear before descending. Never switch off the engine on a downhill.' },
      { point: '🌊 Slippery Road', text: 'The road surface may be slippery, especially in wet conditions. Reduce speed and avoid harsh braking or steering.' },
      { point: '🚂 Level Crossing', text: 'A railway crossing is ahead. Slow down, look both ways for trains. Do not cross if a train is approaching or the boom is lowered.' },
      { point: '🦓 Zebra Crossing Warning', text: 'A marked pedestrian crossing is ahead. Pedestrians have the right of way once on the crossing.' },
    ],
    quiz: { q: 'What shape are warning signs in South Africa?', opts: ['Round with a red border', 'Diamond-shaped', 'Rectangular', 'Octagonal'], answer: 1, explanation: 'Warning signs are yellow/black diamond-shaped signs. This shape is internationally recognised for hazard warnings.' }
  },
  {
    id: 'sess_rules_row',
    title: 'Right of Way',
    icon: '🛣️',
    color: '#dbeafe',
    sub: '5 rules · ~20 min',
    desc: 'Understand right of way at intersections, 4-way stops, roundabouts, and more.',
    content: [
      { point: '🔵 Uncontrolled Intersections', text: 'Yield to the vehicle approaching from your RIGHT. If you are on the minor road, always yield to traffic on the major road.' },
      { point: '🔵 4-Way Stop', text: 'The first vehicle to stop has right of way. If two vehicles stop simultaneously, yield to the one on your RIGHT. If directly opposite, yield to the turning vehicle.' },
      { point: '🔵 Roundabouts', text: 'Traffic already inside the roundabout has right of way. Enter only when there is a safe gap. Indicate right when entering, left when exiting.' },
      { point: '🔵 Emergency Vehicles', text: 'Yield immediately to ambulances, fire trucks, and police vehicles displaying flashing lights and sirens. Pull left and stop until they pass.' },
      { point: '🔵 Pedestrians', text: 'Pedestrians on a crossing have right of way. At driveways and exits from parking areas, yield to pedestrians on the pavement.' },
    ],
    quiz: { q: 'At an uncontrolled intersection, you must yield to traffic coming from:', opts: ['Your left', 'Your right', 'Straight ahead only', 'No one — first come, first served'], answer: 1, explanation: 'At an uncontrolled intersection, you must yield to the vehicle approaching from your RIGHT. This is the fundamental right-of-way rule in South Africa.' }
  },
  {
    id: 'sess_rules_speed',
    title: 'Speed & Following Distance',
    icon: '🚀',
    color: '#dcfce7',
    sub: '4 topics · ~15 min',
    desc: 'Speed limits, the 2-second rule, and safe following distances explained.',
    content: [
      { point: '⚡ Speed Limits (General)', text: 'Urban areas: 60 km/h. Rural roads: 100 km/h. Freeways: 120 km/h. Posted signs always override. School zones: 40 km/h.' },
      { point: '⏱️ The 2-Second Rule', text: 'In good conditions, maintain a 2-second gap behind the vehicle in front. Pick a fixed point — when they pass it, count "one-thousand-and-one, one-thousand-and-two". You should only reach it at "two".' },
      { point: '🌧️ Wet Weather Distance', text: 'Double your following distance to 4 seconds in wet conditions. Stopping distances increase significantly on wet roads.' },
      { point: '🚛 Heavy Vehicles', text: 'Heavy vehicles require at least 3–4 seconds following distance due to longer braking distances. Never cut in front of a heavy vehicle after overtaking.' },
    ],
    quiz: { q: 'The minimum following distance in good conditions is:', opts: ['1 second', '2 seconds', '3 seconds', '4 seconds'], answer: 1, explanation: 'The 2-second rule is the minimum safe following distance in dry, good-visibility conditions. Always increase this distance in poor weather.' }
  },
  {
    id: 'sess_controls',
    title: 'Vehicle Controls & K53 Manoeuvres',
    icon: '🎛️',
    color: '#ede9fe',
    sub: '6 topics · ~25 min',
    desc: 'MSM routine, mirror checks, moving off, and key K53 manoeuvres.',
    content: [
      { point: '👁️ MSM Routine', text: 'Mirror → Signal → Manoeuvre. Check mirrors BEFORE every signal, speed change, or manoeuvre. This sequence must be applied consistently during your driving test.' },
      { point: '🔍 Blind Spot Check', text: 'Before moving off, changing lanes, or turning, perform a shoulder check (look over your shoulder) to check the blind spot that mirrors cannot cover.' },
      { point: '🏁 Moving Off on a Hill', text: 'Use the handbrake technique: clutch to biting point → accelerate slightly → release handbrake → release clutch smoothly. The car must not roll back.' },
      { point: '🔄 Three-Point Turn', text: 'Signal left → turn hard left and stop. Reverse right while checking mirrors and blind spot → turn hard left and drive forward. Must be completed safely without mounting the kerb.' },
      { point: '🅿️ Parallel Parking', text: 'Signal → move past the space → reverse diagonally into gap → straighten → adjust. Your vehicle must end within 30cm of the kerb.' },
      { point: '🚦 Robot (Traffic Light) Procedure', text: 'Green: proceed if safe. Amber: stop if safe to do so — do not speed up. Red: stop before the stop line. Red + Amber: prepare to move but do not proceed until green.' },
    ],
    quiz: { q: 'What does MSM stand for in the K53 driving system?', opts: ['Move, Stop, Manoeuvre', 'Mirror, Signal, Manoeuvre', 'Mirror, Steer, Move', 'Monitor, Signal, Manoeuvre'], answer: 1, explanation: 'MSM stands for Mirror → Signal → Manoeuvre. This routine must be applied before every significant driving action during your K53 test.' }
  },
  {
    id: 'sess_licence_codes',
    title: 'Understanding Licence Codes',
    icon: '📋',
    color: '#fce7f3',
    sub: '5 topics · ~10 min',
    desc: 'All South African driving licence codes, vehicle categories, and the upgrade path.',
    content: [
      { point: '🏍️ Code A / A1', text: 'Motorcycle licence. A1 is for motorcycles up to 125cc. Code A covers all motorcycles. You can obtain this independently of car licences.' },
      { point: '🚗 Code 8 / EB', text: 'Light motor vehicle — up to 3500kg. This is the standard car licence. Code EB is the modern equivalent covering both manual and automatic vehicles.' },
      { point: '🚛 Code 10 / C', text: 'Heavy motor vehicle — up to 16000kg. Required for trucks and buses. You must hold Code 8 (EB) first before applying for Code 10.' },
      { point: '🚚 Code 14 / EC', text: 'Extra-heavy vehicle — over 16000kg. Articulated trucks, tankers. Required: Code 10 first. Highest standard licence category.' },
      { point: '📈 Upgrade Path', text: 'Learner\'s Licence → Code 8 → Code 10 → Code 14. You must pass each level before attempting the next. Your Learner\'s Licence is valid for 24 months to complete the driving test.' },
    ],
    quiz: { q: 'Which licence do you need BEFORE applying for Code 10?', opts: ['Code A', 'Code 8 (EB)', 'Code 14', 'No prior licence needed'], answer: 1, explanation: 'You must hold a valid Code 8 (EB) licence before you can apply to upgrade to Code 10 (heavy motor vehicle).' }
  },
];

// ══════════════════════════════════════════════════════════════
//  SESSIONS PAGE
// ══════════════════════════════════════════════════════════════
function loadSessions() {
  const gate = document.getElementById('sessionsGate');
  const content = document.getElementById('sessionsContent');
  if (!currentUser) {
    gate.classList.remove('hidden');
    content.classList.add('hidden');
    return;
  }
  gate.classList.add('hidden');
  content.classList.remove('hidden');
  renderSessions();
}

function getSessionProgress() {
  const raw = localStorage.getItem('unidrive_sessions_' + (currentUser?.id || ''));
  return raw ? JSON.parse(raw) : {};
}
function saveSessionProgress(prog) {
  localStorage.setItem('unidrive_sessions_' + currentUser.id, JSON.stringify(prog));
}

function renderSessions() {
  const prog = getSessionProgress();
  const completed = Object.values(prog).filter(Boolean).length;
  const pct = Math.round((completed / SESSIONS_DATA.length) * 100);

  const pctEl = document.getElementById('sessProgressPct');
  const fillEl = document.getElementById('sessProgressFill');
  if (pctEl) pctEl.textContent = pct + '%';
  if (fillEl) fillEl.style.width = pct + '%';

  const grid = document.getElementById('sessionsGrid');
  if (!grid) return;
  grid.innerHTML = SESSIONS_DATA.map(s => {
    const done = prog[s.id];
    return `
      <div class="sess-card ${done ? 'completed' : ''}" onclick="openSession('${s.id}')">
        <div class="sess-hdr">
          <div class="sess-icon" style="background:${s.color}">${s.icon}</div>
          <div class="sess-meta">
            <div class="sess-title">${s.title}</div>
            <div class="sess-sub">${s.sub}</div>
          </div>
          <span class="sess-status ${done ? 'done' : 'todo'}">${done ? '✅ Done' : '⬜ To Do'}</span>
        </div>
        <div class="sess-body">
          <div class="sess-progress"><div class="sess-pbar" style="width:${done ? 100 : 0}%"></div></div>
          <p class="sess-desc">${s.desc}</p>
          <button class="btn btn-primary sess-btn">${done ? '🔄 Review Again' : '▶ Start Session'}</button>
        </div>
      </div>`;
  }).join('');
}

function openSession(id) {
  const s = SESSIONS_DATA.find(x => x.id === id);
  if (!s) return;
  document.getElementById('sessionModalTitle').textContent = s.icon + ' ' + s.title;

  const body = document.getElementById('sessionModalBody');
  body.innerHTML = `
    <div class="session-modal-content">
      <div class="smc-section">
        <h4>📖 Key Learning Points</h4>
        ${s.content.map(c => `
          <div class="smc-point">
            <div class="smc-point-icon">${c.point.split(' ')[0]}</div>
            <p><strong>${c.point.replace(/^[^\s]+\s/,'')}</strong> — ${c.text}</p>
          </div>`).join('')}
      </div>
      <div class="smc-section">
        <h4>🧠 Quick Quiz</h4>
        <div class="smc-quiz">
          <div class="smc-quiz-q">${s.quiz.q}</div>
          <div class="smc-options">
            ${s.quiz.opts.map((o, i) => `
              <button class="smc-opt" onclick="answerSessionQuiz('${id}',${i},${s.quiz.answer},'${s.quiz.explanation.replace(/'/g,"\\'")}',this)">${o}</button>
            `).join('')}
          </div>
          <div id="smc-feedback-${id}" style="display:none" class="smc-feedback"></div>
        </div>
      </div>
      <button class="btn btn-gold smc-complete-btn" onclick="markSessionComplete('${id}')">
        ✅ Mark as Complete &amp; Continue
      </button>
    </div>`;

  document.getElementById('sessionModal').classList.remove('hidden');
  document.body.style.overflow = 'hidden';
}

function answerSessionQuiz(sessId, chosen, correct, explanation, btn) {
  const opts = btn.closest('.smc-options').querySelectorAll('.smc-opt');
  opts.forEach(o => o.disabled = true);
  const isCorrect = chosen === correct;
  btn.classList.add(isCorrect ? 'correct' : 'wrong');
  opts[correct].classList.add('correct');
  const fb = document.getElementById('smc-feedback-' + sessId);
  fb.style.display = 'block';
  fb.className = 'smc-feedback ' + (isCorrect ? 'correct' : 'wrong');
  fb.textContent = (isCorrect ? '✅ Correct! ' : '❌ Incorrect. ') + explanation;
  if (isCorrect) markSessionComplete(sessId);
}

function markSessionComplete(id) {
  const prog = getSessionProgress();
  prog[id] = true;
  saveSessionProgress(prog);
  renderSessions();
  toast('Session completed! 🎉', 'success');
}

function closeSessionModal() {
  document.getElementById('sessionModal').classList.add('hidden');
  document.body.style.overflow = '';
}

// ══════════════════════════════════════════════════════════════
//  MOCK TEST DATA (68 Questions — K53 Learner's)
// ══════════════════════════════════════════════════════════════
const MOCK_QUESTIONS = [
  // --- ROAD SIGNS (22 questions) ---
  { cat:'Road Signs', q:'A red octagonal sign with white letters STOP means:', opts:['Slow down and look both ways','Come to a complete stop and yield to all traffic','Stop only if other vehicles are present','Reduce speed to 20 km/h'], a:1 },
  { cat:'Road Signs', q:'A red circle with a white horizontal bar means:', opts:['Maximum speed limit','No entry for vehicles','No stopping','Yield to oncoming traffic'], a:1 },
  { cat:'Road Signs', q:'A yellow diamond-shaped sign generally indicates:', opts:['A mandatory instruction','A warning of a hazard ahead','The speed limit','An information guide'], a:1 },
  { cat:'Road Signs', q:'A round blue sign with a white arrow pointing right means:', opts:['You may turn right if clear','You MUST turn right','No right turn ahead','Right lane ends'], a:1 },
  { cat:'Road Signs', q:'What colour are regulatory signs in South Africa?', opts:['Yellow and black','Blue and white','Red, white, and black','Green and white'], a:2 },
  { cat:'Road Signs', q:'A sign showing a motorcycle with a red cross through it means:', opts:['Motorcycles may park here','Motorcycles are prohibited','Motorcycle lane ahead','Motorcycle warning zone'], a:1 },
  { cat:'Road Signs', q:'A triangular sign (pointing up) with a red border is a:', opts:['Regulatory sign','Warning sign','Yield sign','Information sign'], a:2 },
  { cat:'Road Signs', q:'What does a sign with "80" inside a red circle mean?', opts:['Minimum speed 80 km/h','Maximum speed 80 km/h','Advisory speed 80 km/h','End of speed restriction'], a:1 },
  { cat:'Road Signs', q:'A "No Overtaking" sign applies until:', opts:['You have passed 5 vehicles','The next traffic light','You see an end-of-restriction sign or change in road markings','It has been 2km'], a:2 },
  { cat:'Road Signs', q:'A level crossing sign warns you of:', opts:['A steep hill','A railway line crossing the road','A pedestrian crossing','A sharp bend'], a:1 },
  { cat:'Road Signs', q:'What does a pedestrian crossing (zebra crossing) sign look like?', opts:['Blue rectangle with a walking person','Yellow diamond with walking figure','Red octagon','Green rectangle'], a:1 },
  { cat:'Road Signs', q:'A broken white line in the centre of the road means:', opts:['No overtaking at all','You may overtake if safe','Road is ending','Pedestrian zone'], a:1 },
  { cat:'Road Signs', q:'A solid yellow line on your side of the road means:', opts:['Advisory caution: slow down','You may NOT cross or overtake','End of speed restriction','Bicycle lane ahead'], a:1 },
  { cat:'Road Signs', q:'An inverted triangle (point down) sign means:', opts:['Stop completely','Yield to all approaching traffic','Warning of danger','One-way road ahead'], a:1 },
  { cat:'Road Signs', q:'What do green direction signs indicate?', opts:['Major hazards ahead','Mandatory turns','Routes and directions on national roads','No-go zones'], a:2 },
  { cat:'Road Signs', q:'A sign showing two opposing arrows on a narrow road means:', opts:['Overtaking is permitted','Two-way traffic ahead — prepare for oncoming vehicles','Road narrows','High speed zone'], a:1 },
  { cat:'Road Signs', q:'A "No Stopping" sign means:', opts:['You may stop for 5 minutes','You may not stop at all in that zone','You may stop to drop passengers','Parking is restricted to 30 minutes'], a:1 },
  { cat:'Road Signs', q:'What is the shape of a STOP sign?', opts:['Triangle','Circle','Octagon','Diamond'], a:2 },
  { cat:'Road Signs', q:'A sign with children and a school building means:', opts:['Maximum speed 40 km/h applies in this area','Children may cross anywhere','School buses have priority','No children under 18 admitted'], a:0 },
  { cat:'Road Signs', q:'When you see a "Slippery Road" sign, you should:', opts:['Increase speed to maintain momentum','Reduce speed and avoid harsh braking or steering','Switch to neutral gear','Brake firmly and quickly'], a:1 },
  { cat:'Road Signs', q:'A blue rectangular sign with a "P" means:', opts:['Parking is prohibited','Parking is permitted','Police checkpoint ahead','Pedestrian priority zone'], a:1 },
  { cat:'Road Signs', q:'A sign with a torch/flashlight icon warns of:', opts:['Tunnel ahead','Low visibility zone','No lights zone','Emergency vehicles ahead'], a:0 },

  // --- RULES OF THE ROAD (26 questions) ---
  { cat:'Rules of the Road', q:'At an uncontrolled intersection you must yield to:', opts:['Vehicles on your left','Vehicles on your right','Vehicles coming from straight ahead','No one — first to arrive proceeds'], a:1 },
  { cat:'Rules of the Road', q:'At a 4-way stop, if two vehicles arrive simultaneously, who has right of way?', opts:['The heavier vehicle','The vehicle on the left yields to the one on the right','The faster vehicle','The vehicle going straight'], a:1 },
  { cat:'Rules of the Road', q:'The general speed limit on a freeway in South Africa is:', opts:['100 km/h','110 km/h','120 km/h','140 km/h'], a:2 },
  { cat:'Rules of the Road', q:'The legal blood alcohol limit for a driver in South Africa is:', opts:['0.02g per 100ml blood','0.05g per 100ml blood','0.08g per 100ml blood','0.10g per 100ml blood'], a:1 },
  { cat:'Rules of the Road', q:'You should use the 2-second rule to maintain:', opts:['The correct speed','A safe following distance','Your lane position','Correct mirror use frequency'], a:1 },
  { cat:'Rules of the Road', q:'When may you use a cell phone while driving?', opts:['At a red traffic light','Only to make calls','Only if you use a hands-free system','Never — any use is illegal while the vehicle is moving'], a:3 },
  { cat:'Rules of the Road', q:'In wet conditions, your following distance should be:', opts:['The same as dry conditions','Halved','Doubled to at least 4 seconds','Tripled to 6 seconds'], a:2 },
  { cat:'Rules of the Road', q:'You are approaching a yellow traffic light. You should:', opts:['Speed up to clear the intersection','Stop if it is safe to do so','Always proceed — yellow means caution','Flash your lights'], a:1 },
  { cat:'Rules of the Road', q:'When must headlights be used?', opts:['Only in fog','30 minutes after sunset to 30 minutes before sunrise','Only on freeways at night','Whenever speed exceeds 100 km/h'], a:1 },
  { cat:'Rules of the Road', q:'On which side may you overtake in South Africa?', opts:['The left side only','The right side only','Either side if safe','Only on a freeway'], a:1 },
  { cat:'Rules of the Road', q:'You must NOT overtake when:', opts:['On a straight road with good visibility','Near the crest of a hill or blind rise','The vehicle in front is travelling at 60 km/h','On a dual carriageway'], a:1 },
  { cat:'Rules of the Road', q:'Are all vehicle occupants required to wear seat belts?', opts:['Only the driver','Driver and front-seat passenger','All occupants','Only adults over 18'], a:2 },
  { cat:'Rules of the Road', q:'Who is responsible for ensuring passengers under 14 are buckled?', opts:['The passenger themselves','The parent regardless of where they sit','The driver','It is voluntary'], a:2 },
  { cat:'Rules of the Road', q:'A learner licence holder\'s blood alcohol limit is:', opts:['0.05g/100ml (same as licensed drivers)','0.02g/100ml','0.00g/100ml (zero tolerance)','0.08g/100ml'], a:2 },
  { cat:'Rules of the Road', q:'When approaching an emergency vehicle with sirens on, you must:', opts:['Speed up and get out of its way','Pull to the left and stop until it has passed','Continue at the same speed','Flash your lights and continue'], a:1 },
  { cat:'Rules of the Road', q:'What is the urban speed limit in South Africa?', opts:['50 km/h','60 km/h','70 km/h','80 km/h'], a:1 },
  { cat:'Rules of the Road', q:'You must NOT use your hooter (horn):', opts:['To warn of danger on an open road','Between 21:00 and 06:00 in a built-up area','In an emergency situation','When a pedestrian steps into the road'], a:1 },
  { cat:'Rules of the Road', q:'When parking on a hill facing uphill, you should turn your wheels:', opts:['Straight ahead','Toward the kerb (right)','Away from the kerb (left)','Position does not matter'], a:2 },
  { cat:'Rules of the Road', q:'What is the minimum tread depth for vehicle tyres?', opts:['1mm','1.6mm','2.5mm','3mm'], a:1 },
  { cat:'Rules of the Road', q:'In a roundabout, who has right of way?', opts:['Vehicles entering the roundabout','Vehicles already inside the roundabout','The largest vehicle','Vehicles on the left'], a:1 },
  { cat:'Rules of the Road', q:'A double solid centre line means:', opts:['Overtaking is allowed for faster vehicles','No vehicle may cross or overtake','The road is ending','Speed limit doubles'], a:1 },
  { cat:'Rules of the Road', q:'At a pedestrian (zebra) crossing, you must:', opts:['Hoot to warn pedestrians','Yield to pedestrians already on the crossing','Only stop if pedestrians are in your lane','Flash lights and proceed slowly'], a:1 },
  { cat:'Rules of the Road', q:'How far before a turn should you signal?', opts:['At least 20m','At least 30m','At least 50m','At the turn itself'], a:1 },
  { cat:'Rules of the Road', q:'You are involved in an accident. What should you do FIRST?', opts:['Leave the scene and report it later','Stop, warn other traffic, assist injured persons, and report to police','Take photos and leave','Move all vehicles off the road immediately'], a:1 },
  { cat:'Rules of the Road', q:'Is it legal to make a U-turn at a traffic light?', opts:['Yes, always','No, never','Yes, unless a sign prohibits it','Only on a green arrow'], a:2 },
  { cat:'Rules of the Road', q:'What does a broken yellow line separating lanes mean?', opts:['You may NOT overtake','You may change lanes if safe','The road is about to end','Bus lane ahead'], a:1 },

  // --- VEHICLE CONTROLS (20 questions) ---
  { cat:'Vehicle Controls', q:'The MSM routine stands for:', opts:['Move, Stop, Manoeuvre','Mirror, Signal, Manoeuvre','Monitor, Steer, Move','Mirror, Speed, Move'], a:1 },
  { cat:'Vehicle Controls', q:'Before moving off, you should perform a blind spot check by:', opts:['Checking only the interior mirror','Looking over your shoulder in the direction of travel','Sounding the hooter','Checking only the door mirror'], a:1 },
  { cat:'Vehicle Controls', q:'The clutch pedal on a manual vehicle is located:', opts:['On the far right','In the middle','On the far left','On the steering column'], a:2 },
  { cat:'Vehicle Controls', q:'To prevent a manual car from rolling back on a hill start, use:', opts:['The accelerator only','The footbrake and left-foot clutch technique or handbrake method','High gear','Neutral gear with foot on brake'], a:1 },
  { cat:'Vehicle Controls', q:'When should you check your mirrors?', opts:['Only when turning','Only when changing lanes','Before every signal, speed change, or manoeuvre','Only when reversing'], a:2 },
  { cat:'Vehicle Controls', q:'Coasting (travelling in neutral downhill) is dangerous because:', opts:['It increases tyre wear','You have no engine braking and less steering control','It improves fuel economy too much','It overheats the clutch'], a:1 },
  { cat:'Vehicle Controls', q:'What is the "biting point" on a clutch?', opts:['When the clutch pedal is fully pressed','The point where the clutch starts to engage and the car moves forward','When the gear is fully engaged','When the car is in first gear only'], a:1 },
  { cat:'Vehicle Controls', q:'In an emergency stop on a vehicle WITHOUT ABS brakes:', opts:['Pump the brakes rapidly','Apply steady, firm pressure to the brake pedal','Press the brake as hard as possible and hold','Use the handbrake first'], a:0 },
  { cat:'Vehicle Controls', q:'In an emergency stop on a vehicle WITH ABS brakes:', opts:['Pump the brakes rapidly','Press the brake hard and hold — the ABS prevents wheel lock','Use the handbrake simultaneously','Apply both clutch and brake at once'], a:1 },
  { cat:'Vehicle Controls', q:'Low beam headlights should be switched to high beam when:', opts:['In fog','Approaching oncoming traffic within 150m','On an open dark road with no oncoming traffic','In heavy rain'], a:2 },
  { cat:'Vehicle Controls', q:'When should you NOT use the handbrake as your primary stopping device?', opts:['When parking','When stopped on a hill','While the vehicle is moving at speed','Before leaving the vehicle'], a:2 },
  { cat:'Vehicle Controls', q:'The correct sequence when stopping the vehicle is:', opts:['Brake → Clutch → Handbrake → Neutral','Clutch → Brake → Neutral → Handbrake','Neutral → Brake → Clutch → Handbrake','Handbrake → Neutral → Clutch → Brake'], a:0 },
  { cat:'Vehicle Controls', q:'Before a right turn, which mirrors do you check in order?', opts:['Right door mirror only','Interior mirror, then right door mirror','Right door mirror, then interior mirror','Only check blind spot'], a:1 },
  { cat:'Vehicle Controls', q:'Power steering failure is most noticeable:', opts:['At high speeds','At low speeds and while parking','Only during reversing','When the engine is cold'], a:1 },
  { cat:'Vehicle Controls', q:'Which light symbol on the dashboard indicates low oil pressure?', opts:['A battery with a lightning bolt','An engine outline','An oil can symbol','A thermometer'], a:2 },
  { cat:'Vehicle Controls', q:'When parallel parking, your vehicle should end up within __ of the kerb:', opts:['15 cm','30 cm','50 cm','1 metre'], a:1 },
  { cat:'Vehicle Controls', q:'A three-point turn must be completed:', opts:['In exactly 3 moves always','Without mounting the kerb and only when safe to do so','At speeds under 10 km/h','On roads with a painted centreline only'], a:1 },
  { cat:'Vehicle Controls', q:'To signal a right turn, which control do you use?', opts:['Left turn signal lever','Right turn signal lever (indicator)','Flash the headlights','Use the horn'], a:1 },
  { cat:'Vehicle Controls', q:'The rear-view (interior) mirror shows:', opts:['The front of the vehicle','Directly behind the vehicle through the rear window','Both side blind spots','The road ahead through cameras'], a:1 },
  { cat:'Vehicle Controls', q:'Before getting into a vehicle, a driver should:', opts:['Start the engine immediately','Do a walk-around check of the vehicle for defects or hazards','Adjust the seat first','Check fuel gauge on the dashboard'], a:1 },
];

// ══════════════════════════════════════════════════════════════
//  MOCK TEST ENGINE
// ══════════════════════════════════════════════════════════════
let mtQuestions = [];
let mtCurrent   = 0;
let mtAnswers   = {};
let mtTimer     = null;
let mtSecsLeft  = 1800; // 30 minutes

function loadMocktest() {
  const gate = document.getElementById('mocktestGate');
  const content = document.getElementById('mocktestContent');
  if (!currentUser) {
    gate.classList.remove('hidden');
    content.classList.add('hidden');
    return;
  }
  gate.classList.add('hidden');
  content.classList.remove('hidden');
  showMtHistory();
  showSection('mt-start');
}

function showMtHistory() {
  const key = 'unidrive_mt_' + (currentUser?.id || '');
  const raw = localStorage.getItem(key);
  const hist = raw ? JSON.parse(raw) : [];
  const el = document.getElementById('mt-history');
  if (!el || !hist.length) return;
  el.innerHTML = `
    <div class="mt-history-wrap">
      <div class="mt-history-title">📊 Your Previous Results (last 5)</div>
      ${hist.slice(-5).reverse().map(h => `
        <div class="mt-hist-row">
          <span>${h.date}</span>
          <span>${h.score}/${h.total} (${Math.round(h.score/h.total*100)}%)</span>
          <span class="badge badge-${h.passed ? 'confirmed' : 'cancelled'}">${h.passed ? 'PASS' : 'FAIL'}</span>
        </div>`).join('')}
    </div>`;
}

function startMockTest() {
  // Shuffle and pick 68 questions across categories
  const signs = shuffle(MOCK_QUESTIONS.filter(q=>q.cat==='Road Signs')).slice(0,22);
  const rules = shuffle(MOCK_QUESTIONS.filter(q=>q.cat==='Rules of the Road')).slice(0,26);
  const ctrls = shuffle(MOCK_QUESTIONS.filter(q=>q.cat==='Vehicle Controls')).slice(0,20);
  mtQuestions = shuffle([...signs, ...rules, ...ctrls]);
  mtCurrent = 0;
  mtAnswers = {};
  mtSecsLeft = 1800;

  showSection('mt-test');
  renderMtQuestion();
  startMtTimer();
}

function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function renderMtQuestion() {
  const q = mtQuestions[mtCurrent];
  const total = mtQuestions.length;
  document.getElementById('mt-q-counter').textContent = `Question ${mtCurrent + 1} of ${total}`;
  document.getElementById('mtPbarFill').style.width = ((mtCurrent + 1) / total * 100) + '%';
  document.getElementById('mt-prev-btn').disabled = mtCurrent === 0;
  document.getElementById('mt-next-btn').textContent = mtCurrent === total - 1 ? '✅ Submit Test' : 'Next →';

  const letters = ['A','B','C','D'];
  const chosen = mtAnswers[mtCurrent];
  document.getElementById('mt-question-wrap').innerHTML = `
    <div class="mt-q-category">${q.cat}</div>
    <div class="mt-q-text">${q.q}</div>
    <div class="mt-options">
      ${q.opts.map((o, i) => `
        <button class="mt-opt ${chosen === i ? 'selected' : ''}"
          onclick="selectMtAnswer(${i}, this)"
          id="mt-opt-${i}">
          <span class="mt-opt-letter">${letters[i]}</span>
          ${o}
        </button>`).join('')}
    </div>`;
}

function selectMtAnswer(idx, btn) {
  mtAnswers[mtCurrent] = idx;
  document.querySelectorAll('.mt-opt').forEach(b => b.classList.remove('selected'));
  btn.classList.add('selected');
}

function mtNext() {
  if (mtCurrent === mtQuestions.length - 1) {
    submitMockTest();
  } else {
    mtCurrent++;
    renderMtQuestion();
  }
}

function mtPrev() {
  if (mtCurrent > 0) {
    mtCurrent--;
    renderMtQuestion();
  }
}

function startMtTimer() {
  clearInterval(mtTimer);
  updateMtTimerDisplay();
  mtTimer = setInterval(() => {
    mtSecsLeft--;
    updateMtTimerDisplay();
    if (mtSecsLeft <= 0) {
      clearInterval(mtTimer);
      toast('⏱️ Time is up! Submitting your test…', 'info');
      submitMockTest();
    }
  }, 1000);
}

function updateMtTimerDisplay() {
  const m = Math.floor(mtSecsLeft / 60);
  const s = mtSecsLeft % 60;
  const el = document.getElementById('mt-timer');
  if (!el) return;
  el.textContent = `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
  el.classList.toggle('urgent', mtSecsLeft <= 120);
}

function submitMockTest() {
  clearInterval(mtTimer);
  let correct = 0;
  const total = mtQuestions.length;
  mtQuestions.forEach((q, i) => {
    if (mtAnswers[i] === q.a) correct++;
  });
  const pct = Math.round(correct / total * 100);
  const passed = correct >= Math.ceil(total * 0.77); // 77% pass mark

  // Save to history
  const key = 'unidrive_mt_' + currentUser.id;
  const raw = localStorage.getItem(key);
  const hist = raw ? JSON.parse(raw) : [];
  hist.push({ date: new Date().toLocaleDateString('en-ZA'), score: correct, total, passed });
  localStorage.setItem(key, JSON.stringify(hist));

  // Results UI
  document.getElementById('mtResultCard').innerHTML = `
    <div class="mt-result-score ${passed ? 'pass' : 'fail'}">${pct}%</div>
    <div class="mt-result-label">${passed ? '🎉 PASS — Well Done!' : '❌ FAIL — Keep Studying!'}</div>
    <div class="mt-result-sub">You scored ${correct} out of ${total} correct.<br>
      ${passed ? 'You are ready for the official K53 test!' : 'You need 77% (≥' + Math.ceil(total*0.77) + ' correct) to pass. Review the materials and try again.'}</div>
    <div class="mt-result-breakdown">
      <div class="mt-rb-item"><div class="mt-rb-num" style="color:var(--green)">${correct}</div><div class="mt-rb-lbl">Correct</div></div>
      <div class="mt-rb-item"><div class="mt-rb-num" style="color:#ef4444">${total - correct}</div><div class="mt-rb-lbl">Wrong</div></div>
      <div class="mt-rb-item"><div class="mt-rb-num">${total}</div><div class="mt-rb-lbl">Total</div></div>
    </div>`;

  // Answer review
  const letters = ['A','B','C','D'];
  document.getElementById('mt-review').innerHTML = `
    <h3 style="font-family:'Syne',sans-serif;margin-bottom:1rem">📋 Answer Review</h3>
    ${mtQuestions.map((q,i) => {
      const chosen = mtAnswers[i];
      const isCorrect = chosen === q.a;
      return `
        <div class="mt-rv-item ${isCorrect ? 'rv-correct' : 'rv-wrong'}">
          <div class="mt-rv-q">${i+1}. ${q.q} <span class="mt-rv-badge ${isCorrect ? 'correct' : 'wrong'}">${isCorrect ? '✅ Correct' : '❌ Wrong'}</span></div>
          <div class="mt-rv-a">
            ${!isCorrect ? `Your answer: <em>${chosen !== undefined ? letters[chosen] + '. ' + q.opts[chosen] : 'Not answered'}</em> · ` : ''}
            Correct answer: <strong>${letters[q.a]}. ${q.opts[q.a]}</strong>
          </div>
        </div>`;
    }).join('')}`;

  showSection('mt-results');
}

function showSection(id) {
  ['mt-start','mt-test','mt-results'].forEach(s => {
    const el = document.getElementById(s);
    if (el) el.classList.toggle('hidden', s !== id);
  });
}

// ══════════════════════════════════════════════════════════════
//  OFFICIAL TEST BOOKING
// ══════════════════════════════════════════════════════════════
function loadTestBooking() {
  const gate    = document.getElementById('testbookGate');
  const content = document.getElementById('testbookContent');
  if (!currentUser) {
    gate.classList.remove('hidden');
    content.classList.add('hidden');
    return;
  }
  gate.classList.add('hidden');
  content.classList.remove('hidden');
  loadMyTestBookings();

  // Set min date (at least 7 days ahead for official tests)
  const el = document.getElementById('tbDate');
  if (el) {
    const minDate = new Date();
    minDate.setDate(minDate.getDate() + 7);
    el.min = minDate.toISOString().split('T')[0];
  }
}

function updateTestInfo() {
  const val = document.getElementById('tbTestType').value;
  const box = document.getElementById('tbTestInfoBox');
  const info = {
    learners_k53: '📋 K53 Theory Test — 68 questions, 30 minutes. You must score at least 77% (53/68) to pass. Bring your ID and R70 test fee.',
    driving_code8: '🚗 Code 8 Driving Test — Includes a yard test and a road test. Bring your Learner\'s Licence card, ID, and R130 test fee.',
    driving_codeA: '🏍️ Code A Motorcycle Test — Requires approved safety gear. Yard circuit + road test. Bring your Learner\'s Licence, ID, and R130 fee.',
    driving_code10: '🚛 Code 10 Heavy Vehicle Test — Must hold Code 8 first. Vehicle must be roadworthy. ID, Code 8 licence, and R200 fee required.',
    driving_code14: '🚚 Code 14 Extra Heavy Test — Must hold Code 10. Articulated vehicle test. ID, Code 10 licence, and R200 fee required.',
  };
  if (val && info[val]) {
    box.textContent = info[val];
    box.classList.remove('hidden');
  } else {
    box.classList.add('hidden');
  }
}

function loadTestSlots() {
  buildSlots('tbDate', 'tbSlotsWrapper', 'tbSlotsGrid', 'tbTime');
  // Official test slots are 30-min intervals, 07:30 to 15:00 only
  const grid = document.getElementById('tbSlotsGrid');
  if (grid) {
    const officialSlots = [];
    for (let h = 7; h <= 14; h++) {
      const h0 = String(h).padStart(2,'0');
      officialSlots.push(`${h0}:00`, `${h0}:30`);
    }
    officialSlots.push('15:00');
    grid.innerHTML = officialSlots.map(t =>
      `<button type="button" class="slot-btn" onclick="selectSlot('${t}',this,'tbTime')">${t}</button>`
    ).join('');
  }
}

function submitTestBooking(e) {
  e.preventDefault();
  const msgEl = document.getElementById('tbMsg');
  clearMsg(msgEl);

  const testType = document.getElementById('tbTestType').value;
  const dltc     = document.getElementById('tbDLTC').value;
  const date     = document.getElementById('tbDate').value;
  const time     = document.getElementById('tbTime').value;
  const idNum    = document.getElementById('tbIdNumber').value.trim();
  const notes    = document.getElementById('tbNotes').value.trim();

  if (!testType) { showMsg(msgEl, 'Please select a test type.', 'error'); return; }
  if (!dltc)     { showMsg(msgEl, 'Please select a DLTC centre.', 'error'); return; }
  if (!date)     { showMsg(msgEl, 'Please select a date.', 'error'); return; }
  if (!time)     { showMsg(msgEl, 'Please select a time slot.', 'error'); return; }
  if (!idNum)    { showMsg(msgEl, 'Please enter your ID number.', 'error'); return; }

  const db = getDB();
  const testNames = {
    learners_k53:  "Learner's Licence (K53 Theory)",
    driving_code8: 'Driving Test — Code 8',
    driving_codeA: 'Driving Test — Code A',
    driving_code10:'Driving Test — Code 10',
    driving_code14:'Driving Test — Code 14',
  };
  const dltcNames = {
    pinetown:     'Pinetown DLTC',
    durban_north: 'Durban North DLTC',
    umlazi:       'Umlazi DLTC',
  };

  if (!db.testBookings) db.testBookings = [];
  const booking = {
    id: 'tb_' + Date.now(),
    user_id: currentUser.id,
    student_name:  `${currentUser.first_name} ${currentUser.last_name}`,
    student_email: currentUser.email,
    test_type: testType,
    test_name: testNames[testType] || testType,
    dltc, dltc_name: dltcNames[dltc] || dltc,
    test_date: date, test_time: time,
    id_number: idNum, notes,
    status: 'pending',
    ref: 'UDA-' + Date.now().toString(36).toUpperCase(),
    created_at: new Date().toISOString(),
  };
  db.testBookings.push(booking);
  saveDB(db);

  showMsg(msgEl, `✅ Test slot reserved! Reference: ${booking.ref}. You will receive a confirmation within 2 business days.`, 'success');
  e.target.reset();
  document.getElementById('tbSlotsWrapper').style.display = 'none';
  document.getElementById('tbTestInfoBox').classList.add('hidden');
  toast('Official test booking submitted! 🏛️', 'success');
  loadMyTestBookings();
}

function loadMyTestBookings() {
  const el = document.getElementById('myTestBookingsList');
  if (!el) return;
  const db = getDB();
  const bookings = (db.testBookings || [])
    .filter(b => b.user_id === currentUser?.id)
    .sort((a,b) => new Date(b.created_at) - new Date(a.created_at));

  if (!bookings.length) {
    el.innerHTML = '<p class="text-muted">No official test bookings yet.</p>';
    return;
  }
  el.innerHTML = bookings.map(b => `
    <div class="tbk-item">
      <div class="tbk-hdr">
        <div class="tbk-type">${b.test_name}</div>
        <span class="badge badge-${b.status === 'confirmed' ? 'confirmed' : b.status === 'cancelled' ? 'cancelled' : 'pending'}">${b.status}</span>
      </div>
      <div class="tbk-meta">
        <span>🏛️ ${b.dltc_name}</span>
        <span>📅 ${b.test_date} · 🕐 ${b.test_time}</span>
        <span>🔖 Ref: ${b.ref}</span>
      </div>
      ${['pending','confirmed'].includes(b.status) ? `
        <div style="margin-top:.5rem">
          <button class="btn btn-sm btn-red" onclick="cancelTestBooking('${b.id}')">Cancel Booking</button>
        </div>` : ''}
    </div>`).join('');
}

function cancelTestBooking(id) {
  if (!confirm('Cancel this official test booking?')) return;
  const db = getDB();
  if (!db.testBookings) return;
  const bk = db.testBookings.find(b => b.id === id);
  if (bk) { bk.status = 'cancelled'; saveDB(db); }
  toast('Test booking cancelled.', 'info');
  loadMyTestBookings();
}
